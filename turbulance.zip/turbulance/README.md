# Social Media App

## Table of Contents
- [Project Overview](#project-overview)
- [System Requirements](#system-requirements)
- [Dependencies](#dependencies)
- [Application Structure](#application-structure)
- [How to Set Up and Run the Project](#how-to-set-up-and-run-the-project)
- [Code Formatting](#code-formatting)
- [Libraries and Tools Used](#libraries-and-tools-used)
- [Support](#support)

## Project Overview
The **Social Media App** is a Flutter project designed to provide a social media platform with features such as image caching, chat UI, responsive design, and more. The project leverages several libraries to make development easier and enhance performance.

## System Requirements
To run the project, ensure the following system requirements are met:

- **Dart SDK**: Version 3.4.0 or greater
- **Flutter SDK**: Version 2.22.0 or greater

## Dependencies
This project includes several dependencies to manage app functionalities effectively:

- **flutter**: The Flutter SDK for building the app.
- **flutter_localizations**: Localization support for different languages.
- **cached_network_image**: Version ^3.3.1 for caching images fetched from the network.
- **flutter_svg**: Version ^2.0.10+1 to support SVG images.
- **flutter_bloc**: Version ^8.1.6 for state management using the BLoC pattern.
- **equatable**: Version ^2.0.5 for easier comparison of objects in Dart.
- **shared_preferences**: Version ^2.3.0 for storing key-value pairs on the device.
- **connectivity_plus**: Version ^6.0.4 for checking network connectivity.
- **responsive_grid_list**: Version ^1.4.0 to create responsive grid layouts.
- **pin_code_fields**: Version ^8.0.1 for implementing pin code input fields.
- **flutter_staggered_grid_view**: Version ^0.7.0 for creating staggered grid views.
- **flutter_chat_ui**: Version ^1.6.15 for creating a chat UI.
- **flutter_chat_types**: Version ^3.6.2 for chat-related data types.
- **flutter_slidable**: Version ^3.1.1 for slide-to-delete functionality in lists.
- **sms_autofill**: Version ^2.4.6 for SMS autofill functionality.

## Application Structure
After a successful build, the directory structure of the application will look like this:

