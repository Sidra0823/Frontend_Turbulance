package turbulance.com.turbulance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
