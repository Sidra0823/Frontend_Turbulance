import 'package:flutter/material.dart';
import 'package:easy_localization/easy_localization.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Initialize EasyLocalization
  await EasyLocalization.ensureInitialized();

  runApp(
    EasyLocalization(
      supportedLocales: [Locale('en', 'US'), Locale('es', 'ES')], // Add more locales if needed
      path: 'assets/lang', // Ensure this path exists and contains JSON files like en-US.json, es-ES.json
      fallbackLocale: Locale('en', 'US'), // Fallback locale in case of errors
      child: MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          titleTextStyle: TextStyle(color: Colors.black),
        ),
      ),
      // Set locale and localizationsDelegates
      locale: context.locale, // To switch the locale dynamically
      supportedLocales: context.supportedLocales,
      localizationsDelegates: context.localizationDelegates,
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("lbl_add_new_card".tr()), // This will use translation
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () {
                // Switch to Spanish locale
                context.setLocale(Locale('es', 'ES'));
              },
              child: Text("Switch to Spanish"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Switch back to English locale
                context.setLocale(Locale('en', 'US'));
              },
              child: Text("Switch to English"),
            ),
          ],
        ),
      ),
    );
  }
}
