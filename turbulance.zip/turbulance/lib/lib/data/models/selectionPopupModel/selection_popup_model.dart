/// SelectionPopupModel is a common model
/// used for setting data into dropdowns

// ignore_for_file: must_be_immutable

class SelectionPopupModel {
  SelectionPopupModel({
    this.id,
    required this.title,
    this.value,
    this.isSelected = false, // Default value should be 'false'
  });

  int? id;
  String title;
  dynamic value;
  bool isSelected;
}