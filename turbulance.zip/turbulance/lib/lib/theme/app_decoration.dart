import 'package:flutter/material.dart';

class AppDecoration {
  // Fill decorations
  static BoxDecoration get fillBlack => BoxDecoration(
    color: appTheme.black900,
  );

  static BoxDecoration get fillBlack900 => BoxDecoration(
    color: appTheme.black900,
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgImage6),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get fillBlack9001 => BoxDecoration(
    color: appTheme.black900,
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgImage6),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get fillBlack9002 => BoxDecoration(
    color: appTheme.black900,
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgImage7),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get fillBlueGray => BoxDecoration(
    color: appTheme.blueGray100,
  );

  static BoxDecoration get fillBlueGray900 => BoxDecoration(
    color: appTheme.blueGray900,
  );

  static BoxDecoration get fillErrorContainer => BoxDecoration(
    color: theme.colorScheme.errorContainer,
  );

  static BoxDecoration get fillGray => BoxDecoration(
    color: appTheme.gray900,
  );

  static BoxDecoration get fillGray50002 => BoxDecoration(
    color: appTheme.gray50002,
  );

  static BoxDecoration get fillGray800 => BoxDecoration(
    color: appTheme.gray800,
  );

  static BoxDecoration get fillGray600B2 => BoxDecoration(
    color: appTheme.gray600B2,
  );

  static BoxDecoration get fillOnPrimary => BoxDecoration(
    color: theme.colorScheme.onPrimary,
  );

  static BoxDecoration get fillOnPrimary1 => BoxDecoration(
    color: theme.colorScheme.onPrimary,
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgImage6888x428),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get fillPrimary => BoxDecoration(
    color: theme.colorScheme.primary,
  );

  static BoxDecoration get fillRedA70001 => BoxDecoration(
    color: appTheme.redA70001,
  );

  // N decorations
  static BoxDecoration get neutral400 => BoxDecoration(
    color: appTheme.gray900,
    border: Border.all(
      color: appTheme.gray100,
      width: 1.h,
    ),
    boxShadow: [
      BoxShadow(
        color: appTheme.black900.withOpacity(0.08),
        spreadRadius: 2.h,
        blurRadius: 2.h,
        offset: Offset(0, 8),
      ),
    ],
  );

  // Outline decorations
  static BoxDecoration get outlineBlack => BoxDecoration(
    color: appTheme.gray900,
    boxShadow: [
      BoxShadow(
        color: appTheme.black900.withOpacity(0.25),
        spreadRadius: 2.h,
        blurRadius: 2.h,
        offset: Offset(0, 4),
      ),
    ],
  );

  static BoxDecoration get outlineGray => BoxDecoration(
    border: Border.all(
      color: appTheme.gray100,
      width: 1.h,
    ),
  );

  static BoxDecoration get outlineGray30001 => BoxDecoration(
    color: appTheme.black900,
    border: Border.all(
      color: appTheme.gray30001,
      width: 1.h,
    ),
    boxShadow: [
      BoxShadow(
        color: appTheme.black900.withOpacity(0.05),
        spreadRadius: 2.h,
        blurRadius: 2.h,
        offset: Offset(0, 4),
      ),
    ],
  );

  static BoxDecoration get outlineOnPrimary => BoxDecoration(
    color: theme.colorScheme.onPrimary,
    border: Border.all(width: 1.h),
  );

  static BoxDecoration get outlineOnPrimary1 => BoxDecoration(
    border: Border.all(
      color: theme.colorScheme.onPrimary,
      width: 1.h,
      strokeAlign: BorderSide.strokeAlignOutside,
    ),
  );

  static BoxDecoration get outlinePrimary => BoxDecoration(
    border: Border.all(
      color: theme.colorScheme.primary,
      width: 5.h,
    ),
  );

  // Column decorations
  static BoxDecoration get column12 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgThunderLogo179x430),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get column17 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgThunderLogo11),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get column19 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgThunderLogo21),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get column20 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgThunderLogo22),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get column24 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgThunderLogo12),
      fit: BoxFit.fill,
    ),
  );

  static BoxDecoration get column7 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgThunderLogo1),
      fit: BoxFit.fill,
    ),
  );

  // Stack decorations
  static BoxDecoration get stack26 => BoxDecoration(
    image: DecorationImage(
      image: AssetImage(ImageConstant.imgRing),
      fit: BoxFit.fill,
    ),
  );
}

class BorderRadiusStyle {
  // Circle borders
  static BorderRadius get circleBorder28 => BorderRadius.circular(28.h);
  static BorderRadius get circleBorder32 => BorderRadius.circular(32.h);
  static BorderRadius get circleBorder40 => BorderRadius.circular(40.h);
  static BorderRadius get circleBorder50 => BorderRadius.circular(50.h);

  // Custom borders
  static BorderRadius get customBorderTL14 => BorderRadius.vertical(
    top: Radius.circular(14.h),
  );

  static BorderRadius get customBorderTL141 => BorderRadius.only(
    topLeft: Radius.circular(14.h),
    topRight: Radius.circular(14.h),
    bottomRight: Radius.circular(14.h),
  );

  static BorderRadius get customBorderTL20 => BorderRadius.vertical(
    top: Radius.circular(20.h),
  );

  static BorderRadius get customBorderTL32 => BorderRadius.vertical(
    top: Radius.circular(32.h),
  );

  // Rounded borders
  static BorderRadius get roundedBorder16 => BorderRadius.circular(16.h);
  static BorderRadius get roundedBorder2 => BorderRadius.circular(2.h);
  static BorderRadius get roundedBorder20 => BorderRadius.circular(20.h);
  static BorderRadius get roundedBorder24 => BorderRadius.circular(24.h);
  static BorderRadius get roundedBorder5 => BorderRadius.circular(5.h);
  static BorderRadius get roundedBorder8 => BorderRadius.circular(8.h);
}
