import 'package:equatable/equatable.dart';

part 'theme_event.dart';
part 'theme_state.dart';

class ThemeBloc extends Bloc<ThemeEvent, ThemeState> {
  /// Constructor for the [ThemeBloc].
  /// Takes the initial [ThemeState] and sets up event handlers.
  ThemeBloc(ThemeState initialState) : super(initialState) {
    on<ThemeChangeEvent>(_changeTheme);
  }

  /// Handler for [ThemeChangeEvent].
  /// Updates the state with the new theme type.
  Future<void> _changeTheme(
      ThemeChangeEvent event,
      Emitter<ThemeState> emit,
      ) async {
    emit(state.copyWith(themeType: event.themeType));
  }
}
