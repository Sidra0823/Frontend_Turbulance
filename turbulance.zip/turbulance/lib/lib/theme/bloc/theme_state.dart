part of 'theme_bloc.dart';

class ThemeState extends Equatable {
  /// Constructor for the [ThemeState], requiring a [themeType].
  const ThemeState({required this.themeType});

  /// The current theme type as a string.
  final String themeType;

  @override
  List<Object?> get props => [themeType];

  /// Returns a copy of the current [ThemeState] with an updated [themeType].
  /// If no [themeType] is provided, the existing value is retained.
  ThemeState copyWith({String? themeType}) {
    return ThemeState(
      themeType: themeType ?? this.themeType,
    );
  }
}
