part of 'theme_bloc.dart';

/// Base class for theme-related events.
abstract class ThemeEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event to handle theme changes.
class ThemeChangeEvent extends ThemeEvent {
  /// Constructor for [ThemeChangeEvent], requiring a [themeType].
  ThemeChangeEvent({required this.themeType}) : super() {
    // Save the selected theme type using preferences utility.
    PrefUtils().setThemeData(themeType);
  }

  /// The selected theme type as a string.
  final String themeType;

  @override
  List<Object?> get props => [themeType];
}
