import 'package:flutter/material.dart';

extension TextStyleExtension on TextStyle {
  TextStyle get inter => copyWith(fontFamily: 'Inter');
  TextStyle get satoshi => copyWith(fontFamily: 'Satoshi');
  TextStyle get roboto => copyWith(fontFamily: 'Roboto');
  TextStyle get mulish => copyWith(fontFamily: 'Mulish');
  TextStyle get ibmPlexSans => copyWith(fontFamily: 'IBM Plex Sans');
  TextStyle get sfProDisplay => copyWith(fontFamily: 'SF Pro Display');
  TextStyle get instrumentSans => copyWith(fontFamily: 'Instrument Sans');
  TextStyle get sfProText => copyWith(fontFamily: 'SF Pro Text');
  TextStyle get urbanist => copyWith(fontFamily: 'Urbanist');
  TextStyle get nunito => copyWith(fontFamily: 'Nunito');
  TextStyle get skModernist => copyWith(fontFamily: 'Sk-Modernist');
  TextStyle get inriaSans => copyWith(fontFamily: 'Inria Sans');
}

/// A collection of pre-defined text styles for customizing text appearance,
/// categorized by different font families and weights.
/// This class includes extensions on [TextStyle] to easily apply specific font families.

class CustomTextStyles {
  // Body text style
  static TextStyle get bodyLarge => theme.textTheme.bodyLarge!.copyWith(fontSize: 18.fSize);
  static TextStyle get bodyLargeBlack900 =>
      theme.textTheme.bodyLarge!.copyWith(color: appTheme.black900, fontSize: 18.fSize);
  static TextStyle get bodyLargeGray50001 =>
      theme.textTheme.bodyLarge!.copyWith(color: appTheme.gray50001);
  static TextStyle get bodyLargeInter =>
      theme.textTheme.bodyLarge!.inter.copyWith(fontSize: 18.fSize);
  static TextStyle get bodyLargeRoboto =>
      theme.textTheme.bodyLarge!.roboto.copyWith(fontSize: 18.fSize);

  // Body Medium
  static TextStyle get bodyMediumNunito =>
      theme.textTheme.bodyMedium!.nunito.copyWith(fontSize: 15.fSize, fontWeight: FontWeight.w200);
  static TextStyle get bodyMediumRoboto =>
      theme.textTheme.bodyMedium!.roboto.copyWith(fontSize: 15.fSize);
  static TextStyle get bodyMediumSkModernist =>
      theme.textTheme.bodyMedium!.skModernist.copyWith(fontSize: 15.fSize);

  // Body Small
  static TextStyle get bodySmallGray50001 =>
      theme.textTheme.bodySmall!.copyWith(color: appTheme.gray50001, fontSize: 12.fSize);
  static TextStyle get bodySmallRoboto =>
      theme.textTheme.bodySmall!.roboto.copyWith(fontSize: 12.fSize);

  // Headline
  static TextStyle get headlineLargeSFProDisplay =>
      theme.textTheme.headlineLarge!.sfProDisplay.copyWith(fontSize: 33.fSize, fontWeight: FontWeight.w600);
  static TextStyle get headlineSmallRoboto =>
      theme.textTheme.headlineSmall!.roboto.copyWith(fontWeight: FontWeight.w400);

  // Label
  static TextStyle get labelLargeBlack900 =>
      theme.textTheme.labelLarge!.copyWith(color: appTheme.black900);
  static TextStyle get labelLargeRoboto =>
      theme.textTheme.labelLarge!.roboto.copyWith(fontSize: 12.fSize, fontWeight: FontWeight.w500);

  // Title
  static TextStyle get titleLarge =>
      theme.textTheme.titleLarge!.copyWith(fontSize: 22.fSize);
  static TextStyle get titleLargeRoboto =>
      theme.textTheme.titleLarge!.roboto.copyWith(fontSize: 22.fSize);
  static TextStyle get titleMedium =>
      theme.textTheme.titleMedium!.copyWith(fontSize: 16.fSize, fontWeight: FontWeight.w700);
  static TextStyle get titleMediumRoboto =>
      theme.textTheme.titleMedium!.roboto.copyWith(fontSize: 16.fSize);
  static TextStyle get titleSmallRoboto =>
      theme.textTheme.titleSmall!.roboto.copyWith(fontSize: 15.fSize);
  static TextStyle get titleSmallNunito =>
      theme.textTheme.titleSmall!.nunito.copyWith(fontSize: 15.fSize, fontWeight: FontWeight.w600);
}
