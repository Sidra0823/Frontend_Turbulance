import 'package:shared_preferences/shared_preferences.dart';

// ignore_for_file: must_be_immutable

class PrefUtils {
  PrefUtils() {
    SharedPreferences.getInstance().then((value) {
      _sharedPreferences = value;
    });
  }

  static SharedPreferences? _sharedPreferences;

  Future<void> init() async {
    _sharedPreferences ??= await SharedPreferences.getInstance();
    print('SharedPreferences Initialized');
  }

  /// Clears all the data stored in preferences
  Future<void> clearPreferencesData() async {
    await _sharedPreferences?.clear();
  }

  /// Stores the theme data in preferences
  Future<void> setThemeData(String value) async {
    await _sharedPreferences?.setString('themeData', value);
  }

  /// Retrieves the theme data from preferences
  Object? Function(String key)? getThemeData() {
    try {
      // Return the stored theme data, or null if not found
      return (key) => _sharedPreferences?.get(key);
    } catch (e) {
      // Handle error
      print("Error retrieving theme data: $e");
      return null;
    }
  }
}
