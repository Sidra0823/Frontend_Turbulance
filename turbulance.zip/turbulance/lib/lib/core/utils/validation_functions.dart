/// Checks if a string is a valid email.
bool isValidEmail(String? inputString, {bool isRequired = false}) {
  bool isInputStringValid = false;

  // Check if input is required and either null or empty
  if (isRequired && (inputString == null || inputString.isEmpty)) {
    return false; // Return false if required but the input is missing
  }

  if (inputString != null && inputString.isNotEmpty) {
    const pattern =
        r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W@#$%^&+\-=])(?=\S)(?!.*\s).{4,}$';
  final regExp = RegExp(pattern);
  isInputStringValid = regExp.hasMatch(inputString);
  }

  return isInputStringValid;
  }

/// Password validation checks:
/// - at least one uppercase letter
/// - at least one lowercase letter
/// - at least one digit
/// - at least one special character [@#$%^&+-]
/// - at least 4 characters in length
/// - no whitespace allowed
bool isValidPassword(String? inputString, {bool isRequired = false}) {
  bool isInputStringValid = false;

  if (isRequired && (inputString == null || inputString.isEmpty)) {
    return false; // Return false if required but the input is missing
  }

  if (inputString != null && inputString.isNotEmpty) {
    const pattern =
        r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W@#$%^&+\-=])(?=\S)(?!.*\s).{4,}$';
    final regExp = RegExp(pattern);
    isInputStringValid = regExp.hasMatch(inputString);
  }

  return isInputStringValid;
}

/// Checks if the string consists of only alphabetic characters (no whitespace).
bool isText(String? inputString, {bool isRequired = false}) {
  bool isInputStringValid = false;

  // Check if input is required and either null or empty
  if (isRequired && (inputString == null || inputString.isEmpty)) {
    return false; // Return false if required but the input is missing
  }

  if (inputString != null && inputString.isNotEmpty) {
    const pattern = r'^[a-zA-Z]+$';
    final regExp = RegExp(pattern);
    isInputStringValid = regExp.hasMatch(inputString);
  }

  return isInputStringValid;
}

/// Checks if the string consists of only numeric characters.
bool isNumeric(String? inputString, {bool isRequired = false}) {
  bool isInputStringValid = false;

  // Check if input is required and either null or empty
  if (isRequired && (inputString == null || inputString.isEmpty)) {
    return false; // Return false if required but the input is missing
  }

  if (inputString != null && inputString.isNotEmpty) {
    const pattern = r'^\d+$';
    final regExp = RegExp(pattern);
    isInputStringValid = regExp.hasMatch(inputString);
  }

  return isInputStringValid;
}
