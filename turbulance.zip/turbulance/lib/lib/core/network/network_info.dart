import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';

/// Abstract interface for network information.
abstract class NetworkInfoI {
  Future<bool> isConnected();
  Future<ConnectivityResult> get connectivityResult;
  Stream<ConnectivityResult> get onConnectivityChanged;
}

/// Implementation of NetworkInfo using `connectivity_plus`.
class NetworkInfo implements NetworkInfoI {
  final Connectivity _connectivity;

  // Singleton instance
  static final NetworkInfo _networkInfo = NetworkInfo._internal(Connectivity());

  factory NetworkInfo() {
    return _networkInfo;
  }

  NetworkInfo._internal(this._connectivity);

  /// Checks if the internet is connected or not.
  @override
  Future<bool> isConnected() async {
    final result = await connectivityResult;
    return result != ConnectivityResult.none;
  }

  /// To check the type of internet connectivity.
  @override
  Future<ConnectivityResult> get connectivityResult async {
    // Returns a single ConnectivityResult
    return await _connectivity.checkConnectivity();
  }

  /// Listen for changes in internet connection type.
  @override
  Stream<ConnectivityResult> get onConnectivityChanged {
    // Returns a stream of ConnectivityResult
    return _connectivity.onConnectivityChanged;
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Connectivity Example')),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            // Example usage of NetworkInfo
            NetworkInfo().isConnected().then((isConnected) {
              print(isConnected ? 'Connected' : 'Not Connected');
            });
          },
          child: Text('Check Connectivity'),
        ),
      ),
    );
  }
}
