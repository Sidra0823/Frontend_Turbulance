import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';

// Import the translations for en_US
import 'en_us/en_us_translations.dart';

extension LocalizationExtension on String {
  String get tr => AppLocalization.of().getString(this);
}

// ignore_for_file: must_be_immutable

class AppLocalization {
  AppLocalization(this.locale);

  final Locale locale;

  // This map will hold the localized values for each language
  static final Map<String, Map<String, String>> _localizedValues = {
    'en': enus,  // enus is your English translations map
  };

  // This function gets the current localization context
  static AppLocalization of() {
    return Localizations.of<AppLocalization>(
        NavigatorService.navigatorKey.currentContext!, AppLocalization
    )!;
  }

  // Returns a list of supported languages
  static List<String> languages() {
    return _localizedValues.keys.toList();
  }

  // Gets the string value for the provided text based on the current locale
  String getString(String text) {
    return _localizedValues[locale.languageCode]![text] ?? text;
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<AppLocalization> {
  const AppLocalizationDelegate();

  @override
  bool isSupported(Locale locale) {
    return AppLocalization.languages().contains(locale.languageCode);
  }

  // Returning a synchronous future here to avoid async load
  @override
  Future<AppLocalization> load(Locale locale) {
    return SynchronousFuture<AppLocalization>(AppLocalization(locale));
  }

  @override
  bool shouldReload(AppLocalizationDelegate old) => false;
}
