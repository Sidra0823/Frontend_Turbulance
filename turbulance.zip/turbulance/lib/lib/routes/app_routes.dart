import 'package:flutter/material.dart';

import '../presentation/add_card_option_one_screen/add_card_option_one_screen.dart';
import '../presentation/approval_screen/approval_screen.dart';
import '../presentation/archived_message_screen/archived_message_screen.dart';
import '../presentation/audio_call_screen/audio_call_screen.dart';
import '../presentation/billing_and_payment_one_screen/billing_and_payment_one_screen.dart';
import '../presentation/billing_and_payment_screen/billing_and_payment_screen.dart';
import '../presentation/billing_and_payment_three_screen/billing_and_payment_three_screen.dart';
import '../presentation/billing_and_payment_two_screen/billing_and_payment_two_screen.dart';
import '../presentation/comment_screen/comment_screen.dart';
import '../presentation/comments_screen/comments_screen.dart';
import '../presentation/create_new_account_screen/create_new_account_screen.dart';
import '../presentation/enable_notification_one_screen/enable_notification_one_screen.dart';
import '../presentation/enable_notification_screen/enable_notification_screen.dart';
import '../presentation/home_go_to_profile_screen/home_go_to_profile_screen.dart';
import '../presentation/home_page_visit_message_screen/home_page_visit_message_screen.dart';
import '../presentation/home_screen/home_screen.dart';
import '../presentation/iphone_14_15_pro_max_100_screen/iphone_14_15_pro_max_100_screen.dart';
import '../presentation/iphone_14_15_pro_max_101_screen/iphone_14_15_pro_max_101_screen.dart';
import '../presentation/iphone_14_15_pro_max_121_screen/iphone_14_15_pro_max_121_screen.dart';
import '../presentation/iphone_14_15_pro_max_eightynine_screen/iphone_14_15_pro_max_eightynine_screen.dart';
import '../presentation/iphone_14_15_pro_max_eightyseven_screen/iphone_14_15_pro_max_eightyseven_screen.dart';
import '../presentation/iphone_14_15_pro_max_ninety_screen/iphone_14_15_pro_max_ninety_screen.dart';
import '../presentation/iphone_14_15_pro_max_ninetyfour_screen/iphone_14_15_pro_max_ninetyfour_screen.dart';
import '../presentation/iphone_14_15_pro_max_ninetynine_screen/iphone_14_15_pro_max_ninetynine_screen.dart';
import '../presentation/iphone_14_15_pro_max_ninetyone_screen/iphone_14_15_pro_max_ninetyone_screen.dart';
import '../presentation/iphone_14_15_pro_max_ninetyseven_screen/iphone_14_15_pro_max_ninetyseven_screen.dart';
import '../presentation/iphone_14_15_pro_max_ninetysix_screen/iphone_14_15_pro_max_ninetysix_screen.dart';
import '../presentation/iphone_14_15_pro_max_ninetytwo_screen/iphone_14_15_pro_max_ninetytwo_screen.dart';
import '../presentation/likes_screen/likes_screen.dart';
import '../presentation/live_one_screen/live_one_screen.dart';
import '../presentation/live_screen/live_screen.dart';
import '../presentation/live_video_screen/live_video_screen.dart';
import '../presentation/login_screen/login_screen.dart';
import '../presentation/message_list_screen/message_list_screen.dart';
import '../presentation/message_screen/message_screen.dart';
import '../presentation/my_account_one_screen/my_account_one_screen.dart';
import '../presentation/my_account_screen/my_account_screen.dart';
import '../presentation/my_account_two_screen/my_account_two_screen.dart';
import '../presentation/new_post_screen/new_post_screen.dart';
import '../presentation/notification_one_screen/notification_one_screen.dart';
import '../presentation/notification_screen/notification_screen.dart';
import '../presentation/post_something_screen/post_something_screen.dart';
import '../presentation/profile_page_photo_post_one_screen/profile_page_photo_post_one_screen.dart';
import '../presentation/search_result_one_screen/search_result_one_screen.dart';
import '../presentation/search_screen/search_screen.dart';
import '../presentation/security_privacy_screen/security_privacy_screen.dart';
import '../presentation/select_people_for_group_screen/select_people_for_group_screen.dart';
import '../presentation/select_the_post_screen/select_the_post_screen.dart';
import '../presentation/settings_screen/settings_screen.dart';
import '../presentation/single_photo_post_screen/single_photo_post_screen.dart';
import '../presentation/single_video_post_screen/single_video_post_screen.dart';
import '../presentation/story_screen/story_screen.dart';
import '../presentation/terms_condition_screen/terms_condition_screen.dart';
import '../presentation/welcome_screen/welcome_screen.dart';

class AppRoutes {
  static const String welcomeScreen = '/welcome_screen';
  static const String loginScreen = '/login_screen';
  static const String createNewAccountScreen = '/create_new_account_screen';
  static const String approvalScreen = '/approval_screen';
  static const String termsConditionScreen = '/terms_condition_screen';
  static const String searchResultPage = '/search_result_page';
  static const String liveScreen = '/live_screen';
  static const String liveOneScreen = '/live_one_screen';
  static const String liveVideoScreen = '/live_video_screen';
  static const String postSomethingScreen = '/post_something_screen';
  static const String postSomethingInitialPage = '/post_something_initial_page';
  static const String newPostScreen = '/new_post_screen';
  static const String selectThePostScreen = '/select_the_post_screen';
  static const String singleVideoPostScreen = '/single_video_post_screen';
  static const String singlePhotoPostScreen = '/single_photo_post_screen';
  static const String commentsScreen = '/comments_screen';
  static const String likesScreen = '/likes_screen';
  static const String homePageVisitMessageScreen = '/home_page_visit_message_screen';
  static const String messageListScreen = '/message_list_screen';
  static const String archivedMessageScreen = '/archived_message_screen';
  static const String selectPeopleForGroupScreen = '/select_people_for_group_screen';
  static const String messageScreen = '/message_screen';
  static const String audioCallScreen = '/audio_call_screen';
  static const String homeGoToProfileScreen = '/home_go_to_profile_screen';
  static const String profilePagePhotoPostOneScreen = '/profile_page_photo_post_one_screen';
  static const String profilePagePhotoPostTwoScreen = '/profile_page_photo_post_two_screen';
  static const String searchResultOneScreen = '/search_result_one_screen';
  static const String settingsScreen = '/settings_screen';
  static const String myAccountScreen = '/my_account_screen';
  static const String notificationScreen = '/notification_screen';
  static const String billingAndPaymentScreen = '/billing_and_payment_screen';
  static const String billingAndPaymentOneScreen = '/billing_and_payment_one_screen';
  static const String addCardOptionScreen = '/add_card_option_screen';
  static const String securityPrivacyScreen = '/security_privacy_screen';
  static const String myAccountOneScreen = '/my_account_one_screen';
  static const String myAccountTwoScreen = '/my_account_two_screen';
  static const String billingAndPaymentTwoScreen = '/billing_and_payment_two_screen';
  static const String billingAndPaymentThreeScreen = '/billing_and_payment_three_screen';
  static const String addCardOptionOneScreen = '/add_card_option_one_screen';
  static const String enableNotificationScreen = '/enable_notification_screen';
  static const String enableNotificationOneScreen = '/enable_notification_one_screen';
  static const String homeScreen = '/home_screen';
  static const String notificationOneScreen = '/notification_one_screen';
  static const String commentScreen = '/comment_screen';
  static const String storyScreen = '/story_screen';
  static const String searchScreen = '/search_screen';
  static const String iphone1415ProMaxEightysevenScreen = '/iphone_14_15_pro_max_eightyseven_screen';
  static const String iphone1415ProMaxEightynineScreen = '/iphone_14_15_pro_max_eightynine_screen';
  static const String iphone1415ProMaxNinetyScreen = '/iphone_14_15_pro_max_ninety_screen';
  static const String iphone1415ProMaxNinetyoneScreen = '/iphone_14_15_pro_max_ninetyone_screen';
  static const String iphone1415ProMaxNinetytwoScreen = '/iphone_14_15_pro_max_ninetytwo_screen';
  static const String iphone1415ProMaxNinetythreeScreen = '/iphone_14_15_pro_max_ninetythree_screen';
  static const String iphone1415ProMaxNinetyfourScreen = '/iphone_14_15_pro_max_ninetyfour_screen';
  static const String iphone1415ProMax121Screen = '/iphone_14_15_pro_max_121_screen';
  static const String iphone1415ProMaxNinetysixScreen = '/iphone_14_15_pro_max_ninetysix_screen';
  static const String iphone1415ProMaxNinetysevenScreen = '/iphone_14_15_pro_max_ninetyseven_screen';
  static const String iphone1415ProMaxNinetyeightScreen = '/iphone_14_15_pro_max_ninetyeight_screen';
  static const String iphone1415ProMaxNinetynineScreen = '/iphone_14_15_pro_max_ninetynine_screen';
  static const String iphone1415ProMax100Screen = '/iphone_14_15_pro_max_100_screen';
  static const String iphone1415ProMax101Screen = '/iphone_14_15_pro_max_101_screen';
  static const String iphone1415ProMax122Screen = '/iphone_14_15_pro_max_122_screen';
  static const String appNavigationScreen = '/app_navigation_screen';
  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
    welcomeScreen: WelcomeScreen.builder,
    loginScreen: LoginScreen.builder,
    createNewAccountScreen: CreateNewAccountScreen.builder,
    approvalScreen: ApprovalScreen.builder,
    termsConditionScreen: TermsConditionScreen.builder,
    liveScreen: LiveScreen.builder,
    liveOneScreen: LiveOneScreen.builder,
    liveVideoScreen: LiveVideoScreen.builder,
    postSomethingScreen: PostSomethingScreen.builder,
    newPostScreen: NewPostScreen.builder,
    selectThePostScreen: SelectThePostScreen.builder,
    singleVideoPostScreen: SingleVideoPostScreen.builder,
    singlePhotoPostScreen: SinglePhotoPostScreen.builder,
    commentsScreen: CommentsScreen.builder,
    likesScreen: LikesScreen.builder,
    homePageVisitMessageScreen: HomePageVisitMessageScreen.builder,
    messageListScreen: MessageListScreen.builder,
    archivedMessageScreen: ArchivedMessageScreen.builder,
    selectPeopleForGroupScreen: SelectPeopleForGroupScreen.builder,
    messageScreen: MessageScreen.builder,
    audioCallScreen: AudioCallScreen.builder,
    homeGoToProfileScreen: HomeGoToProfileScreen.builder,
    profilePagePhotoPostOneScreen: ProfilePagePhotoPostOneScreen.builder,
    profilePagePhotoPostTwoScreen: ProfilePagePhotoPostTwoScreen.builder,
    searchResultOneScreen: SearchResultOneScreen.builder,
    settingsScreen: SettingsScreen.builder,
    myAccountScreen: MyAccountScreen.builder,
    notificationScreen: NotificationScreen.builder,
    billingAndPaymentScreen: BillingAndPaymentScreen.builder,
    billingAndPaymentOneScreen: BillingAndPaymentOneScreen.builder,
    addCardOptionScreen: AddCardOptionScreen.builder,
    securityPrivacyScreen: SecurityPrivacyScreen.builder,
    myAccountOneScreen: MyAccountOneScreen.builder,
    myAccountTwoScreen: MyAccountTwoScreen.builder,
    billingAndPaymentTwoScreen: BillingAndPaymentTwoScreen.builder,
    billingAndPaymentThreeScreen: BillingAndPaymentThreeScreen.builder,
    addCardOptionOneScreen: AddCardOptionOneScreen.builder,
    enableNotificationScreen: EnableNotificationScreen.builder,
    enableNotificationOneScreen: EnableNotificationOneScreen.builder,
    homeScreen: HomeScreen.builder,
    notificationOneScreen: NotificationOneScreen.builder,
    commentScreen: CommentScreen.builder,
    storyScreen: StoryScreen.builder,
    searchScreen: SearchScreen.builder,
    iphone1415ProMaxEightysevenScreen: Iphone1415ProMaxEightysevenScreen.builder,
    iphone1415ProMaxEightynineScreen: Iphone1415ProMaxEightynineScreen.builder,
    iphone1415ProMaxNinetyScreen: Iphone1415ProMaxNinetyScreen.builder,
    iphone1415ProMaxNinetyoneScreen: Iphone1415ProMaxNinetyoneScreen.builder,
    iphone1415ProMaxNinetytwoScreen: Iphone1415ProMaxNinetytwoScreen.builder,
    iphone1415ProMaxNinetythreeScreen: Iphone1415ProMaxNinetythreeScreen.builder,
    iphone1415ProMaxNinetyfourScreen: Iphone1415ProMaxNinetyfourScreen.builder,
    iphone1415ProMax121Screen: Iphone1415ProMax121Screen.builder,
    iphone1415ProMaxNinetysixScreen: Iphone1415ProMaxNinetysixScreen.builder,
    iphone1415ProMaxNinetysevenScreen: Iphone1415ProMaxNinetysevenScreen.builder,
    iphone1415ProMaxNinetyeightScreen: Iphone1415ProMaxNinetyeightScreen.builder,
    iphone1415ProMaxNinetynineScreen: Iphone1415ProMaxNinetynineScreen.builder,
    iphone1415ProMax100Screen: Iphone1415ProMax100Screen.builder,
    iphone1415ProMax101Screen: Iphone1415ProMax101Screen.builder,
    iphone1415ProMax122Screen: Iphone1415ProMax122Screen.builder,
    appNavigationScreen: AppNavigationScreen.builder,
    initialRoute: WelcomeScreen.builder,
  };
}
