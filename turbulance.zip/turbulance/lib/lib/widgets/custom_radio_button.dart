import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class CustomRadioButton extends StatelessWidget {
  CustomRadioButton({
    Key? key,
    required this.onChange,
    this.decoration,
    this.alignment,
    this.isRightCheck,
    this.iconSize,
    this.value,
    this.groupValue,
    this.text,
    this.width,
    this.padding,
    this.textStyle,
    this.overflow,
    this.textAlignment,
    this.gradient,
    this.backgroundColor,
    this.isExpandedText = false,
  }) : super(key: key);

  final BoxDecoration? decoration;
  final Alignment? alignment;
  final bool? isRightCheck;
  final double? iconSize;
  final String? value;
  final String? groupValue;
  final Function(String) onChange;
  final String? text;
  final double? width;
  final EdgeInsetsGeometry? padding;
  final TextStyle? textStyle;
  final TextOverflow? overflow;
  final TextAlign? textAlignment;
  final Gradient? gradient;
  final Color? backgroundColor;
  final bool isExpandedText;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
      alignment: alignment ?? Alignment.center,
      child: _buildRadioButtonWidget(),
    )
        : _buildRadioButtonWidget();
  }

  bool get isGradient => gradient != null;

  BoxDecoration get gradientDecoration => BoxDecoration(gradient: gradient);

  Widget _buildRadioButtonWidget() {
    return GestureDetector(
      onTap: () {
        onChange(value!);
      },
      child: Container(
        width: width,
        decoration: decoration,
        padding: padding,
        child: (isRightCheck ?? false) ? _rightSideRadioButton() : _leftSideRadioButton(),
      ),
    );
  }

  Widget _leftSideRadioButton() {
    return Row(
      children: [
        SizedBox(
          width: text != null && text!.isNotEmpty ? 8.0 : 0.0,
          child: _radioButtonWidget(),
        ),
        isExpandedText ? Expanded(child: _textWidget()) : _textWidget(),
      ],
    );
  }

  Widget _rightSideRadioButton() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        isExpandedText ? Expanded(child: _textWidget()) : _textWidget(),
        SizedBox(
          width: text != null && text!.isNotEmpty ? 8.0 : 0.0,
          child: _radioButtonWidget(),
        ),
      ],
    );
  }

  Widget _textWidget() {
    return Text(
      text ?? "",
      textAlign: textAlignment ?? TextAlign.start,
      overflow: overflow,
      style: textStyle ?? CustomTextStyles.bodySmallRobotoOnPrimary12_1,
    );
  }

  Widget _radioButtonWidget() {
    return SizedBox(
      height: iconSize,
      width: iconSize,
      child: Radio<String>(
        visualDensity: const VisualDensity(
          vertical: -4,
          horizontal: -4,
        ),
        value: value ?? "",
        groupValue: groupValue,
        onChanged: (value) {
          onChange(value!);
        },
      ),
    );
  }

  BoxDecoration get radioButtonDecoration => BoxDecoration(color: backgroundColor);
}
