import 'package:flutter/material.dart';

// Extension for CustomFloatingTextField Styles
extension FloatingTextFormFieldStyleHelper on CustomFloatingTextField {
  static CustomOutlinedInputBorder get outlineOnPrimary => CustomOutlinedInputBorder(
    borderRadius: BorderRadius.vertical(
      top: Radius.circular(12.h),
    ),
    borderSide: BorderSide(
      color: theme.colorScheme.onPrimary,
      width: 1,
    ),
  );

  static OutlineInputBorder get outlineOnPrimaryBL12 => OutlineInputBorder(
    borderRadius: BorderRadius.vertical(
      bottom: Radius.circular(12.h),
    ),
    borderSide: BorderSide(
      color: theme.colorScheme.onPrimary,
      width: 1,
    ),
  );
}

// Custom Floating Text Field
class CustomFloatingTextField extends StatelessWidget {
  CustomFloatingTextField({
    Key? key,
    this.alignment,
    this.width,
    this.boxDecoration,
    this.scrollPadding,
    this.controller,
    this.focusNode,
    this.autofocus = false,
    this.textStyle,
    this.obscureText = false,
    this.readOnly = false,
    this.onTap,
    this.textInputAction = TextInputAction.next,
    this.textInputType = TextInputType.text,
    this.maxLines,
    this.hintText,
    this.hintStyle,
    this.labelText,
    this.labelStyle,
    this.prefix,
    this.prefixConstraints,
    this.suffix,
    this.suffixConstraints,
    this.contentPadding,
    this.borderDecoration,
    this.fillColor,
    this.filled = true,
    this.validator,
  }) : super(key: key);

  final Alignment? alignment;
  final double? width;
  final BoxDecoration? boxDecoration;
  final EdgeInsetsGeometry? scrollPadding;
  final TextEditingController? controller;
  final FocusNode? focusNode;
  final bool autofocus;
  final TextStyle? textStyle;
  final bool obscureText;
  final bool readOnly;
  final VoidCallback? onTap;
  final TextInputAction? textInputAction;
  final TextInputType? textInputType;
  final int? maxLines;
  final String? hintText;
  final TextStyle? hintStyle;
  final String? labelText;
  final TextStyle? labelStyle;
  final Widget? prefix;
  final BoxConstraints? prefixConstraints;
  final Widget? suffix;
  final BoxConstraints? suffixConstraints;
  final EdgeInsets? contentPadding;
  final InputBorder? borderDecoration;
  final Color? fillColor;
  final bool filled;
  final FormFieldValidator<String>? validator;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
      alignment: alignment ?? Alignment.center,
      child: floatingTextFieldWidget(context),
    )
        : floatingTextFieldWidget(context);
  }

  Widget floatingTextFieldWidget(BuildContext context) => Container(
    width: width ?? double.maxFinite,
    decoration: boxDecoration,
    child: TextFormField(
      scrollPadding: scrollPadding ??
          EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom,
          ),
      controller: controller,
      focusNode: focusNode,
      onTapOutside: (event) {
        if (focusNode != null) {
          focusNode?.unfocus();
        } else {
          FocusManager.instance.primaryFocus?.unfocus();
        }
      },
      autofocus: autofocus,
      style: textStyle ?? CustomTextStyles.bodySmallRobotoGray70002,
      obscureText: obscureText,
      readOnly: readOnly,
      onTap: () {
        onTap?.call();
      },
      textInputAction: textInputAction,
      keyboardType: textInputType,
      maxLines: maxLines ?? 1,
      decoration: _inputDecoration,
      validator: validator,
    ),
  );

  InputDecoration get _inputDecoration => InputDecoration(
    hintText: hintText ?? "",
    hintStyle: hintStyle ?? CustomTextStyles.bodyLargeRoboto_2,
    labelText: labelText ?? "",
    labelStyle: labelStyle,
    prefixIcon: prefix,
    prefixIconConstraints: prefixConstraints,
    suffixIcon: suffix,
    suffixIconConstraints: suffixConstraints,
    isDense: true,
    contentPadding: contentPadding ?? EdgeInsets.all(12.h),
    fillColor: fillColor ?? appTheme.gray30001,
    filled: filled,
    border: borderDecoration ??
        CustomOutlinedInputBorder(
          borderSide: BorderSide.none,
        ),
    enabledBorder: borderDecoration ??
        CustomOutlinedInputBorder(
          borderSide: BorderSide.none,
        ),
    focusedBorder: (borderDecoration ?? CustomOutlinedInputBorder()).copyWith(
      borderSide: BorderSide(
        color: theme.colorScheme.primary,
        width: 1,
      ),
    ),
  );
}

// Custom Outlined Input Border
class CustomOutlinedInputBorder extends InputBorder {
  const CustomOutlinedInputBorder({
    BorderSide borderSide = const BorderSide(),
    this.borderRadius = const BorderRadius.all(Radius.circular(4.0)),
    this.borderGradient,
    this.fillGradient,
  }) : super(borderSide: borderSide);

  final BorderRadius borderRadius;
  final Gradient? borderGradient;
  final Gradient? fillGradient;

  @override
  bool get isOutline => true;

  @override
  CustomOutlinedInputBorder copyWith({
    BorderSide? borderSide,
    BorderRadius? borderRadius,
    Gradient? borderGradient,
    Gradient? fillGradient,
  }) {
    return CustomOutlinedInputBorder(
      borderSide: borderSide ?? this.borderSide,
      borderRadius: borderRadius ?? this.borderRadius,
      borderGradient: borderGradient ?? this.borderGradient,
      fillGradient: fillGradient ?? this.fillGradient,
    );
  }

  @override
  EdgeInsetsGeometry get dimensions => EdgeInsets.all(borderSide.width);

  @override
  ShapeBorder scale(double t) => CustomOutlinedInputBorder(
    borderSide: borderSide.scale(t),
    borderRadius: borderRadius,
    borderGradient: borderGradient,
    fillGradient: fillGradient,
  );

  @override
  void paint(Canvas canvas, Rect rect,
      {double? gapStart, double gapExtent = 0, double gapPercentage = 0, TextDirection? textDirection}) {
    final RRect outer = borderRadius.toRRect(rect);
    final RRect center = outer.deflate(borderSide.width / 2.0);

    if (fillGradient != null) {
      final Paint fillPaint = Paint()
        ..shader = fillGradient!.createShader(rect)
        ..style = PaintingStyle.fill;
      canvas.drawRRect(center, fillPaint);
    }

    if (borderGradient != null) {
      final Paint borderPaint = Paint()
        ..shader = borderGradient!.createShader(rect)
        ..style = PaintingStyle.stroke
        ..strokeWidth = borderSide.width;
      canvas.drawRRect(center, borderPaint);
    } else {
      final Paint borderPaint = borderSide.toPaint();
      canvas.drawRRect(center, borderPaint);
    }
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other.runtimeType != runtimeType) return false;
    return other is CustomOutlinedInputBorder &&
        other.borderSide == borderSide &&
        other.borderRadius == borderRadius &&
        other.borderGradient == borderGradient &&
        other.fillGradient == fillGradient;
  }

  @override
  int get hashCode => Object.hash(borderSide, borderRadius, borderGradient, fillGradient);
}
