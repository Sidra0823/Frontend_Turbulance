import 'package:flutter/material.dart';

// Extension for CustomIconButton Styles
extension IconButtonStyleHelper on CustomIconButton {
  static BoxDecoration get fillBlack => BoxDecoration(
    color: appTheme.black900,
    borderRadius: BorderRadius.circular(8.h),
  );

  static BoxDecoration get fillLightBlue => BoxDecoration(
    color: appTheme.lightBlue700,
  );

  static BoxDecoration get outlineOnPrimary => BoxDecoration(
    color: theme.colorScheme.primary,
    borderRadius: BorderRadius.circular(8.h),
    border: Border.all(
      color: theme.colorScheme.onPrimary,
      width: 2.h,
    ),
  );

  static BoxDecoration get fillPrimary => BoxDecoration(
    color: theme.colorScheme.primary,
    borderRadius: BorderRadius.circular(10.h),
  );

  static BoxDecoration get fillGray => BoxDecoration(
    color: appTheme.gray50001,
    borderRadius: BorderRadius.circular(10.h),
  );

  static BoxDecoration get fillRedA => BoxDecoration(
    color: appTheme.redA70001,
    borderRadius: BorderRadius.circular(10.h),
  );

  static BoxDecoration get fillPrimaryTL5 => BoxDecoration(
    color: theme.colorScheme.primary,
    borderRadius: BorderRadius.circular(5.h),
  );

  static BoxDecoration get outlineOnPrimaryTL10 => BoxDecoration(
    borderRadius: BorderRadius.circular(10.h),
    border: Border.all(
      color: theme.colorScheme.onPrimary,
      width: 2.h,
    ),
  );

  static BoxDecoration get outlineOnPrimaryTL16 => BoxDecoration(
    borderRadius: BorderRadius.circular(16.h),
    border: Border.all(
      color: theme.colorScheme.onPrimary,
      width: 1.h,
    ),
  );

  static BoxDecoration get none => BoxDecoration();
}

// CustomIconButton Widget
class CustomIconButton extends StatelessWidget {
  CustomIconButton({
    Key? key,
    this.alignment,
    this.height,
    this.width,
    this.decoration,
    this.padding,
    this.onTap,
    this.child,
  }) : super(key: key);

  final Alignment? alignment;
  final double? height;
  final double? width;
  final BoxDecoration? decoration;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
      alignment: alignment ?? Alignment.center,
      child: _iconButtonWidget,
    )
        : _iconButtonWidget;
  }

  Widget get _iconButtonWidget => SizedBox(
    height: height ?? 0,
    width: width ?? 8,
    child: DecoratedBox(
      decoration: decoration ??
          BoxDecoration(
            color: theme.colorScheme.onPrimary,
            borderRadius: BorderRadius.circular(10.h),
          ),
      child: IconButton(
        padding: padding ?? EdgeInsets.zero,
        onPressed: onTap,
        icon: child ?? Container(),
      ),
    ),
  );
}
