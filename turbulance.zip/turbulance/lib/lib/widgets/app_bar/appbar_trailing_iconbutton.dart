import 'package:flutter/material.dart';
import '../custom_icon_button.dart';

class AppbarTrailingIconbutton extends StatelessWidget {
  // Constructor with required and optional parameters
  const AppbarTrailingIconbutton({
    Key? key,
    this.imagePath,
    this.height,
    this.width,
    this.onTap,
    this.margin,
  }) : super(key: key);

  final double? height;
  final double? width;
  final String? imagePath;
  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero, // Default to zero padding if no margin is provided
      child: GestureDetector(
        onTap: () {
          onTap?.call(); // Call onTap if provided
        },
        child: CustomIconButton(
          height: height ?? 40.h, // Default height to 40.h if not provided
          width: width ?? 40.h, // Default width to 40.h if not provided
          decoration: IconButtonStyleHelper.none, // Assuming style helper is defined
          child: CustomImageView(
            imagePath: imagePath ?? ImageConstant.imgCloseOnPrimary, // Default image if not provided
            height: height ?? 40.h, // Apply height to image
            width: width ?? 40.h, // Apply width to image
            fit: BoxFit.contain, // Fit the image within the container
          ),
        ),
      ),
    );
  }
}
