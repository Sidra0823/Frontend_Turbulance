import 'package:flutter/material.dart';

class AppbarTitleImage extends StatelessWidget {
  // Constructor with required and optional parameters
  const AppbarTitleImage({
    Key? key,
    this.imagePath,
    this.height,
    this.width,
    this.onTap,
    this.margin,
  }) : super(key: key);

  final double? height;
  final double? width;
  final String? imagePath;
  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero, // Default to zero padding if no margin is provided
      child: InkWell(
        onTap: () {
          // Call onTap if provided
          onTap?.call();
        },
        child: CustomImageView(
          imagePath: imagePath, // Fixed the typo "imagePathi" to "imagePath"
          height: height ?? 40.h, // Default height is 40.h if no height is provided
          width: width ?? 40.h, // Default width is 40.h if no width is provided
          fit: BoxFit.contain, // Contain the image within the given space
        ),
      ),
    );
  }
}
