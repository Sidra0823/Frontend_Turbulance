import 'package:flutter/material.dart';
// Corrected the import statement

class AppbarLeadingImageOne extends StatelessWidget {
  final double? height;
  final double? width;
  final String? imagePath;
  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  const AppbarLeadingImageOne({
    Key? key,
    this.imagePath,
    this.height,
    this.width,
    this.onTap,
    this.margin,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero,
      child: InkWell( // Corrected InkWell spelling
        onTap: () {
          onTap?.call(); // Handle tap
        },
        borderRadius: BorderRadius.circular(24), // Corrected usage of borderRadius
        child: CustomImageView(
          imagePath: imagePath!,
          height: height ?? 40.h,
          width: width ?? 48.h,
          fit: BoxFit.contain,
          radius: BorderRadius.circular(24.h), // Corrected border radius
        ),
      ),
    );
  }
}
