import 'package:flutter/material.dart';

class AppbarTrailingImage extends StatelessWidget {
  // Constructor with required and optional parameters
  const AppbarTrailingImage({
    Key? key,
    this.imagePath,
    this.height,
    this.width,
    this.onTap,
    this.margin,
  }) : super(key: key);

  final double? height;
  final double? width;
  final String? imagePath;
  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero, // Default to zero padding if no margin is provided
      child: InkWell(
        onTap: () {
          onTap?.call(); // Call onTap if provided
        },
        child: CustomImageView(
          imagePath: imagePath ?? '', // Provide an empty string if no imagePath is provided
          height: height ?? 40.h, // Default height to 40.h if not provided
          width: width ?? 40.h, // Default width to 40.h if not provided
          fit: BoxFit.contain, // Fit the image within the container without distortion
        ),
      ),
    );
  }
}
