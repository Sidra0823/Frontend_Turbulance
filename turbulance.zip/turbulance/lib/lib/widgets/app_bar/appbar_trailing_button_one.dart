import 'package:flutter/material.dart';
import '../custom_elevated_button.dart';

class AppbarTrailingButtonOne extends StatelessWidget {
  // Constructor with required and optional parameters
  const AppbarTrailingButtonOne({
    Key? key,
    this.onTap,
    this.margin,
  }) : super(key: key);

  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero, // Default to zero padding if no margin is provided
      child: GestureDetector(
        onTap: () {
          onTap?.call(); // Call onTap if provided
        },
        child: SizedBox(
          width: double.infinity, // Use double.infinity to take full available width
          child: CustomElevatedButton(
            height: 30.h, // Assuming 30.h is a scaled value using a utility like ScreenUtil
            text: "1bl 350".tr, // Assuming translation with .tr method
            imagePath: ImageConstant.imgEye, // Image path for icon
            imageHeight: 14.h, // Image height for the icon
          ),
        ),
      ),
    );
  }
}
