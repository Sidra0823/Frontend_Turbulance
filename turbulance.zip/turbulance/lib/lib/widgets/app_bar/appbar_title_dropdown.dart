import 'package:flutter/material.dart';
import '../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../custom_drop_down.dart';

class AppbarTitleDropdown extends StatelessWidget {
  // Constructor with required and optional parameters
  const AppbarTitleDropdown({
    Key? key,
    required this.hintText,
    required this.items,
    required this.onTap,
    this.margin,
  }) : super(key: key);

  final String hintText;
  final List<SelectionPopupModel> items;
  final Function(SelectionPopupModel) onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero, // Default to zero padding if no margin is provided
      child: CustomDropDown(
        width: 112.h, // Assuming 112.h is a scaled value using some utility (like ScreenUtil or similar)
        icon: Container(
          margin: EdgeInsets.only(left: 8.h),
          child: CustomImageView(
            imagePath: ImageConstant.imgArrowdown,
            height: 16.h,
          ),
        ),
        items: items,
        contentPadding: EdgeInsets.only(),
        width: 24.h,
        fit: BoxFit.contain,
        iconSize: 16.h,
        hintText: hintText.tr, // Assuming you want to translate the text
        hintStyle: CustomTextStyles.titleSmallNunitoExtraBold15,
        left: 12.h,
        top: 2.h,
        bottom: 2.h,
        onTap: onTap,
      ),
    );
  }
}
