import 'package:flutter/material.dart';

class AppbarSubtitle extends StatelessWidget {
  // Constructor with required and optional parameters
  const AppbarSubtitle({
    Key? key,
    required this.text,
    this.onTap,
    this.margin,
  }) : super(key: key);

  final String text;
  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero,  // Default to zero padding if no margin is provided
      child: GestureDetector(
        onTap: () {
          // Call onTap if provided
          onTap?.call();
        },
        child: Text(
          text,
          style: CustomTextStyles.titleLargeRoboto.copyWith(
            color: Theme.of(context).colorScheme.onPrimary,  // Use theme for color
          ),
        ),
      ),
    );
  }
}
