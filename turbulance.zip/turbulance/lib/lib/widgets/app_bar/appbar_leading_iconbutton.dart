import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';  // Importing ScreenUtil for scaling
// Ensure ImageConstant is defined in this file
import '../custom_icon_button.dart';

class AppbarLeadingIconbutton extends StatelessWidget {
  final double? height;
  final double? width;
  final String? imagePath;
  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  const AppbarLeadingIconbutton({
    Key? key,
    this.imagePath,
    this.height,
    this.width,
    this.onTap,
    this.margin,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero,  // Use the passed margin or default to EdgeInsets.zero
      child: GestureDetector(
        onTap: () {
          onTap?.call();  // Call the passed function on tap
        },
        child: CustomIconButton(
          height: height ?? 48.h,  // Use ScreenUtil for scaling
          width: width ?? 48.h,    // Use ScreenUtil for scaling
          decoration: IconButtonStyleHelper.none,  // Assuming you have a style helper
          child: CustomImageView(
            imagePath: imagePath ?? ImageConstant.imgCloseOnprimary,  // Use ImageConstant for default image
          ),
        ),
      ),
    );
  }
}
