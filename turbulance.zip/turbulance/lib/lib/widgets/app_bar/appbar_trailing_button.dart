import 'package:flutter/material.dart';
import '../custom_elevated_button.dart';

class AppbarTrailingButton extends StatelessWidget {
  AppbarTrailingButton({Key? key, this.onTap, this.margin}) : super(key: key);

  final Function? onTap;
  final EdgeInsetsGeometry? margin;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin ?? EdgeInsets.zero,
      child: GestureDetector(
        onTap: () {
          onTap?.call();
        },
        child: SizedBox(
          width: double.maxFinite,
          child: CustomElevatedButton(
            height: 30.h,
            text: "lbl_live".tr,
            buttonTextStyle: CustomTextStyles.titleLargeBlack900ExtraBold,
          ),
        ),
      ),
    );
  }
}
