import 'package:flutter/material.dart';

// Enum definition for style types
enum Style { bgFillOnPrimary }

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  // Constructor with required and optional parameters
  const CustomAppBar({
    Key? key,
    this.height,
    this.shape,
    this.styleType,
    this.leadingWidth,
    this.leading,
    this.title,
    this.centerTitle,
    this.actions,
  }) : super(key: key);

  final double? height;
  final ShapeBorder? shape;
  final Style? styleType;
  final double? leadingWidth;
  final Widget? leading;
  final Widget? title;
  final bool? centerTitle;
  final List<Widget>? actions;

  @override
  Widget build(BuildContext context) {
    return AppBar(
      elevation: 0,
      shape: shape,
      toolbarHeight: height ?? 52.h, // Default height if not provided
      automaticallyImplyLeading: false,
      backgroundColor: Colors.transparent,
      flexibleSpace: _getStyle(), // Get the style based on styleType
      leadingWidth: leadingWidth ?? 0,
      leading: leading,
      title: title,
      titleSpacing: 0,
      centerTitle: centerTitle ?? false,
      actions: actions,
    );
  }

  @override
  Size get preferredSize => Size(
    SizeUtils.width, // This is assumed to be part of a utility to get screen width
    height ?? 52.h, // Default height if not provided
  );

  // Method to return style based on styleType
  Widget? _getStyle() {
    switch (styleType) {
      case Style.bgFillOnPrimary:
        return Container(
          height: 1.h, // Assuming 1.h is a scaled value based on screen size
          width: double.maxFinite,
          margin: EdgeInsets.only(top: 77.159996.h),
          decoration: BoxDecoration(
            color: theme.colorScheme.onPrimary, // Assuming 'theme' is defined and provides color scheme
          ),
        );
      default:
        return null;
    }
  }
}
