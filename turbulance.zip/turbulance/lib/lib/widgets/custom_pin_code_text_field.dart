import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

// ignore_for_file: must_be_immutable

class CustomPinCodeTextField extends StatelessWidget {
  CustomPinCodeTextField({
    Key? key,
    required this.context,
    required this.onChanged,
    this.alignment,
    this.controller,
    this.textStyle,
    this.hintStyle,
    this.validator,
  }) : super(key: key);

  final Alignment? alignment;
  final BuildContext context;
  final TextEditingController? controller;
  final TextStyle? textStyle;
  final TextStyle? hintStyle;
  final Function(String) onChanged;
  final FormFieldValidator<String>? validator;

  @override
  Widget build(BuildContext context) {
    return alignment != null
        ? Align(
      alignment: alignment ?? Alignment.center,
      child: _pinCodeTextFieldWidget(),
    )
        : _pinCodeTextFieldWidget();
  }

  Widget _pinCodeTextFieldWidget() {
    return PinCodeTextField(
      appContext: context,
      controller: controller,
      length: 6,
      keyboardType: TextInputType.number,
      textStyle: textStyle,
      hintStyle: hintStyle,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      enableActiveFill: true,
      pinTheme: PinTheme(
        fieldHeight: 44.0,
        fieldWidth: 44.0,
        shape: PinCodeFieldShape.box,
        borderRadius: BorderRadius.circular(12.0),
        inactiveColor: Theme.of(context).colorScheme.onPrimary,
        activeColor: Theme.of(context).colorScheme.onPrimary,
        inactiveFillColor: Colors.transparent,
        activeFillColor: Colors.transparent,
        selectedFillColor: Colors.transparent,
        selectedColor: Theme.of(context).colorScheme.onPrimary,
      ),
      onChanged: onChanged,
      validator: validator,
    );
  }
}
