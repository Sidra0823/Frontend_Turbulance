import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/notification_model.dart';

part 'notification_event.dart';
part 'notification_state.dart';

/// A bloc that manages the state of Notification according to the event that is dispatched.
class NotificationBloc extends Bloc<NotificationEvent, NotificationState> {
  NotificationBloc(NotificationState initialState) : super(initialState) {
    on<NotificationInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
    on<ChangeSwitch1Event>(_changeSwitch1);
    on<ChangeSwitch2Event>(_changeSwitch2);
    on<ChangeSwitch3Event>(_changeSwitch3);
    on<ChangeSwitch4Event>(_changeSwitch4);
    on<ChangeSwitch5Event>(_changeSwitch5);
  }

  void _onInitialize(NotificationInitialEvent event, Emitter<NotificationState> emit) async {
    emit(state.copyWith(
      isSelectedSwitch: false,
      isSelectedSwitch1: false,
      isSelectedSwitch2: false,
      isSelectedSwitch3: false,
      isSelectedSwitch4: false,
      isSelectedSwitch5: false,
    ));
  }

  void _changeSwitch(ChangeSwitchEvent event, Emitter<NotificationState> emit) {
    emit(state.copyWith(isSelectedSwitch: event.value));
  }

  void _changeSwitch1(ChangeSwitch1Event event, Emitter<NotificationState> emit) {
    emit(state.copyWith(isSelectedSwitch1: event.value));
  }

  void _changeSwitch2(ChangeSwitch2Event event, Emitter<NotificationState> emit) {
    emit(state.copyWith(isSelectedSwitch2: event.value));
  }

  void _changeSwitch3(ChangeSwitch3Event event, Emitter<NotificationState> emit) {
    emit(state.copyWith(isSelectedSwitch3: event.value));
  }

  void _changeSwitch4(ChangeSwitch4Event event, Emitter<NotificationState> emit) {
    emit(state.copyWith(isSelectedSwitch4: event.value));
  }

  void _changeSwitch5(ChangeSwitch5Event event, Emitter<NotificationState> emit) {
    emit(state.copyWith(isSelectedSwitch5: event.value));
  }
}
