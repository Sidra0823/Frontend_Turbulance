part of 'notification_bloc.dart';

/// Abstract class for all events.
abstract class NotificationEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event for initialization.
class NotificationInitialEvent extends NotificationEvent {}

/// Event for changing switches.
class ChangeSwitchEvent extends NotificationEvent {
  final bool value;

  ChangeSwitchEvent({required this.value});

  @override
  List<Object?> get props => [value];
}

class ChangeSwitch1Event extends NotificationEvent {
  final bool value;

  ChangeSwitch1Event({required this.value});

  @override
  List<Object?> get props => [value];
}

class ChangeSwitch2Event extends NotificationEvent {
  final bool value;

  ChangeSwitch2Event({required this.value});

  @override
  List<Object?> get props => [value];
}

class ChangeSwitch3Event extends NotificationEvent {
  final bool value;

  ChangeSwitch3Event({required this.value});

  @override
  List<Object?> get props => [value];
}

class ChangeSwitch4Event extends NotificationEvent {
  final bool value;

  ChangeSwitch4Event({required this.value});

  @override
  List<Object?> get props => [value];
}

class ChangeSwitch5Event extends NotificationEvent {
  final bool value;

  ChangeSwitch5Event({required this.value});

  @override
  List<Object?> get props => [value];
}
