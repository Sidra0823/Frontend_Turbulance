part of 'notification_bloc.dart';

/// Represents the state of Notification.
class NotificationState extends Equatable {
  final bool isSelectedSwitch;
  final bool isSelectedSwitch1;
  final bool isSelectedSwitch2;
  final bool isSelectedSwitch3;
  final bool isSelectedSwitch4;
  final bool isSelectedSwitch5;
  final NotificationModel? notificationModelObj;

  NotificationState({
    this.isSelectedSwitch = false,
    this.isSelectedSwitch1 = false,
    this.isSelectedSwitch2 = false,
    this.isSelectedSwitch3 = false,
    this.isSelectedSwitch4 = false,
    this.isSelectedSwitch5 = false,
    this.notificationModelObj,
  });

  NotificationState copyWith({
    bool? isSelectedSwitch,
    bool? isSelectedSwitch1,
    bool? isSelectedSwitch2,
    bool? isSelectedSwitch3,
    bool? isSelectedSwitch4,
    bool? isSelectedSwitch5,
    NotificationModel? notificationModelObj,
  }) {
    return NotificationState(
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      isSelectedSwitch1: isSelectedSwitch1 ?? this.isSelectedSwitch1,
      isSelectedSwitch2: isSelectedSwitch2 ?? this.isSelectedSwitch2,
      isSelectedSwitch3: isSelectedSwitch3 ?? this.isSelectedSwitch3,
      isSelectedSwitch4: isSelectedSwitch4 ?? this.isSelectedSwitch4,
      isSelectedSwitch5: isSelectedSwitch5 ?? this.isSelectedSwitch5,
      notificationModelObj: notificationModelObj ?? this.notificationModelObj,
    );
  }

  @override
  List<Object?> get props => [
    isSelectedSwitch,
    isSelectedSwitch1,
    isSelectedSwitch2,
    isSelectedSwitch3,
    isSelectedSwitch4,
    isSelectedSwitch5,
    notificationModelObj,
  ];
}
