import 'package:equatable/equatable.dart';

/// Model for Notification.
class NotificationModel extends Equatable {
  NotificationModel();

  NotificationModel copyWith() {
    return NotificationModel();
  }

  @override
  List<Object?> get props => [];
}
