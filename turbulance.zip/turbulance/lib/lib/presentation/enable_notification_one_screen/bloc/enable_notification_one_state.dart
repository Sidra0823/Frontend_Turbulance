part of 'enable_notification_one_bloc.dart';

/// Represents the state of EnableNotificationOne in the application.
class EnableNotificationOneState extends Equatable {
  final EnableNotificationOneModel? enableNotificationOneModel;

  EnableNotificationOneState({this.enableNotificationOneModel});

  @override
  List<Object?> get props => [enableNotificationOneModel];

  EnableNotificationOneState copyWith({EnableNotificationOneModel? enableNotificationOneModel}) {
    return EnableNotificationOneState(
      enableNotificationOneModel: enableNotificationOneModel ?? this.enableNotificationOneModel,
    );
  }
}
