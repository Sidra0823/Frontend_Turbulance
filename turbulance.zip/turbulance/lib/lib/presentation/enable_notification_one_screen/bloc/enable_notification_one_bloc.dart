import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/enable_notification_one_model.dart';

part 'enable_notification_one_event.dart';
part 'enable_notification_one_state.dart';

/// A bloc that manages the state of EnableNotificationOne according to events.
class EnableNotificationOneBloc extends Bloc<EnableNotificationOneEvent, EnableNotificationOneState> {
  EnableNotificationOneBloc(EnableNotificationOneState initialState) : super(initialState) {
    on<EnableNotificationOneInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      EnableNotificationOneInitialEvent event, Emitter<EnableNotificationOneState> emit) async {
    emit(state.copyWith(enableNotificationOneModel: EnableNotificationOneModel()));
  }
}
