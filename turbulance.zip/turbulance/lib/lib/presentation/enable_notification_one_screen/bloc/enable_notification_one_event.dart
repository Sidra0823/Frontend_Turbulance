part of 'enable_notification_one_bloc.dart';

/// Abstract class for all events that can be dispatched from EnableNotificationOne.
abstract class EnableNotificationOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event triggered when the EnableNotificationOne widget is initialized.
class EnableNotificationOneInitialEvent extends EnableNotificationOneEvent {}
