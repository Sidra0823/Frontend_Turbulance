import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_subtitle_seven.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/enable_notification_one_bloc.dart';
import 'models/enable_notification_one_model.dart';

class EnableNotificationOneScreen extends StatelessWidget {
  const EnableNotificationOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => EnableNotificationOneBloc(
        EnableNotificationOneState(enableNotificationOneModel: EnableNotificationOneModel()),
      )..add(EnableNotificationOneInitialEvent()),
      child: const EnableNotificationOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EnableNotificationOneBloc, EnableNotificationOneState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          appBar: _buildAppBar(context),
          body: SafeArea(
            top: false,
            child: Container(
              padding: EdgeInsets.only(top: 6.h),
              width: double.infinity,
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Opacity(
                    opacity: 0.15,
                    child: CustomImageView(
                      imagePath: ImageConstant.img7223Jpeg1692x430,
                      height: 692.h,
                      width: double.infinity,
                    ),
                  ),
                  _buildContent(context),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 54.h,
      actions: [
        AppbarSubtitleSeven(
          text: "lbl_skip".tr,
          margin: EdgeInsets.only(right: 22.h),
        ),
      ],
    );
  }

  Widget _buildContent(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(top: 148.h),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBasilNotificationOnSolid,
            height: 100.h,
            width: 102.h,
          ),
          SizedBox(height: 36.h),
          Text(
            "msg_enable_notification_s".tr,
            style: CustomTextStyles.headlineSmallSkModernist,
          ),
          SizedBox(height: 12.h),
          SizedBox(
            width: 290.h,
            child: Text(
              "msg_get_push_notification".tr,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: CustomTextStyles.bodyMediumSkModernistonPrimary.copyWith(
                height: 1.50,
              ),
            ),
          ),
          SizedBox(height: 36.h),
          CustomElevatedButton(
            height: 46.h,
            width: 176.h,
            text: "msg_allow_notification".tr,
            buttonStyle: CustomButtonStyles.fillPrimaryTL20,
            buttonTextStyle: CustomTextStyles.labelLargeMulishBlack900,
          ),
        ],
      ),
    );
  }
}
