import 'package:equatable/equatable.dart';

/// Model defining variables used in EnableNotificationOneScreen.
class EnableNotificationOneModel extends Equatable {
  EnableNotificationOneModel();

  EnableNotificationOneModel copyWith() {
    return EnableNotificationOneModel();
  }

  @override
  List<Object?> get props => [];
}
