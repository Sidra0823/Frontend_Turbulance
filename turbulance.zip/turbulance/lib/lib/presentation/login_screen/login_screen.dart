import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/utils/validation_functions.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/custom_outlined_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/login_bloc.dart';
import 'models/login_model.dart';

// ignore_for_file: must_be_immutable

class LoginScreen extends StatelessWidget {
  LoginScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<LoginBloc>(
      create: (context) => LoginBloc(LoginState(loginModelObj: LoginModel()))
        ..add(LoginInitialEvent()),
      child: LoginScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: SizedBox(
                width: double.maxFinite,
                child: Column(
                  children: [
                    SizedBox(
                      height: 648.h,
                      width: double.maxFinite,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Opacity(
                            opacity: 0.29,
                            child: CustomImageView(
                              imagePath: ImageConstant.imgImg72233peg1,
                              height: 648.h,
                              width: double.maxFinite,
                            ),
                          ),
                          Align(
                            alignment: Alignment.topCenter,
                            child: Container(
                              width: double.maxFinite,
                              margin: EdgeInsets.only(left: 34.h, top: 60.h, right: 44.h),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  BlocSelector<LoginBloc, LoginState, LoginModel?>(
                                    selector: (state) => state.loginModelObj,
                                    builder: (context, loginModelObj) {
                                      return CustomDropDown(
                                        width: 114.h,
                                        icon: Container(
                                          margin: EdgeInsets.only(left: 8.h),
                                          child: CustomImageView(
                                            imagePath: ImageConstant.imgArrowdown,
                                            height: 16.h,
                                            width: 24.h,
                                            fit: BoxFit.contain,
                                          ),
                                        ),
                                        iconSize: 16.h,
                                        hintText: "lbl_english_uk".tr,
                                        hintStyle: CustomTextStyles.titleSmallNunitoExtraBold15,
                                        alignment: Alignment.center,
                                        items: loginModelObj?.dropdownItemList ?? [],
                                        contentPadding: EdgeInsets.only(left: 12.h, top: 2.h, bottom: 2.h),
                                      );
                                    },
                                  ),
                                  SizedBox(height: 72.h),
                                  Text(
                                    "lbl_welcome_back".tr,
                                    style: CustomTextStyles.headlineLargeUrbanistGray500,
                                  ),
                                  SizedBox(height: 12.h),
                                  _buildRowLogIntoOne(context),
                                  SizedBox(height: 10.h),
                                  Container(
                                    width: double.maxFinite,
                                    margin: EdgeInsets.only(left: 16.h, right: 4.h),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding: EdgeInsets.only(bottom: 8.h),
                                            child: Divider(),
                                          ),
                                        ),
                                        SizedBox(width: 8.h),
                                        Align(
                                          alignment: Alignment.center,
                                          child: Text(
                                            "lbl_or_login_with".tr,
                                            style: CustomTextStyles.titleSmallUrbanist,
                                          ),
                                        ),
                                        SizedBox(width: 8.h),
                                        Expanded(
                                          child: Padding(
                                            padding: EdgeInsets.only(bottom: 8.h),
                                            child: Divider(),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 16.h),
                                  Padding(
                                    padding: EdgeInsets.only(left: 22.h),
                                    child: Text(
                                      "lbl_email".tr,
                                      style: CustomTextStyles.labelLargeUrbanistOnPrimary,
                                    ),
                                  ),
                                  SizedBox(height: 6.h),
                                  _buildEmailTwo(context),
                                  SizedBox(height: 38.h),
                                  Padding(
                                    padding: EdgeInsets.only(left: 22.h),
                                    child: Text(
                                      "lbl_password".tr,
                                      style: CustomTextStyles.labelLargeUrbanistOnPrimary,
                                    ),
                                  ),
                                  SizedBox(height: 8.h),
                                  _buildPasswordTwo(context),
                                  SizedBox(height: 32.h),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: Text(
                                      "msg_forgotten_password".tr,
                                      style: CustomTextStyles.titleSmallInriaSansLightBlue700,
                                    ),
                                  ),
                                  SizedBox(height: 58.h),
                                  _buildLoginOne(context),
                                  SizedBox(height: 26.h),
                                  _buildCreateNew(context),
                                  SizedBox(height: 52.h),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // Section Widget for Row Log Into One
  Widget _buildRowLogIntoOne(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        children: [
          Text(
            "msg_login_to_continue".tr,
            style: CustomTextStyles.titleMediumUrbanist,
          ),
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 10.h),
              child: Row(
                children: [
                  Container(
                    height: 50.h,
                    width: 44.h,
                    padding: EdgeInsets.only(bottom: 10.h),
                    decoration: AppDecoration.fillBlack.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorders,
                    ),
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgGoogleic,
                          height: 26.h,
                          width: 28.h,
                        ),
                        CustomImageView(
                          imagePath: ImageConstant.imgWhatsappImage20241212,
                          height: 44.h,
                          width: 44.h,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Section Widget for Email
  Widget _buildEmailTwo(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 6.h),
      child: BlocSelector<LoginBloc, LoginState, TextEditingController?>(
        selector: (state) => state.emailTwoController,
        builder: (context, emailTwoController) {
          return CustomTextFormField(
            controller: emailTwoController,
            hintText: "lbl_user_mail_com".tr,
            textInputType: TextInputType.emailAddress,
            suffix: Container(
              margin: EdgeInsets.fromLTRB(16.h, 16.h, 20.h, 16.h),
              child: CustomImageView(
                imagePath: ImageConstant.imgSearch,
                height: 24.h,
                width: 24.h,
                fit: BoxFit.contain,
              ),
            ),
            suffixConstraints: BoxConstraints(maxHeight: 56.h),
            contentPadding: EdgeInsets.fromLTRB(14.h, 16.h, 28.h, 16.h),
            borderDecoration: TextFormFieldStyleHelper.outlineOnPrimary,
            fillColor: appTheme.black900,
            validator: (value) {
              if (value == null || !isValidEmail(value, isRequired: true)) {
                return "err_msg_please_enter_valid_email".tr;
              }
              return null;
            },
          );
        },
      ),
    );
  }

  // Section Widget for Password
  Widget _buildPasswordTwo(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 6.h),
      child: BlocBuilder<LoginBloc, LoginState>(
        builder: (context, state) {
          return CustomTextFormField(
            controller: state.passwordTwoController,
            hintText: "lbl_password_123".tr,
            textInputAction: TextInputAction.done,
            textInputType: TextInputType.visiblePassword,
            suffix: Inkwell(
              onTap: () {
                context.read<LoginBloc>().add(ChangePasswordVisibilityEvent(
                  value: state.isShowPassword,
                ));
              },
              child: Container(
                margin: EdgeInsets.fromLTRB(16.h, 16.h, 20.h, 16.h),
                child: CustomImageView(
                  imagePath: ImageConstant.imgMageeyeoff,
                  height: 24.h,
                  width: 24.h,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            suffixConstraints: BoxConstraints(maxHeight: 56.h),
            obscureText: state.isShowPassword,
            contentPadding: EdgeInsets.fromLTRB(14.h, 16.h, 20.h, 16.h),
            borderDecoration: TextFormFieldStyleHelper.outlineOnPrimary,
            fillColor: appTheme.black900,
            validator: (value) {
              if (value == null || !isValidPassword(value, isRequired: true)) {
                return "err_msg_please_enter_valid_password".tr;
              }
              return null;
            },
          );
        },
      ),
    );
  }

  // Section Widget for Login
  Widget _buildLoginOne(BuildContext context) {
    return CustomOutlinedButton(
      height: 50.h,
      text: "lbl_login".tr,
      margin: EdgeInsets.only(left: 40.h, right: 44.h),
      buttonStyle: CustomButtonStyles.outlineOnPrim,
      buttonTextStyle: CustomTextStyles.titleLargeInriaSansBlack900,
      onPressed: () {
        if (_formKey.currentState?.validate() ?? false) {
          // Add logic to handle login here
        }
      },
    );
  }

  // Section Widget for Create New Account
  Widget _buildCreateNew(BuildContext context) {
    return CustomOutlinedButton(
      height: 50.h,
      text: "msg_create_new_account".tr,
      margin: EdgeInsets.only(left: 40.h, right: 44.h),
      buttonTextStyle: CustomTextStyles.titleLargeInriaSans22,
      onPressed: () {
        // Add logic to navigate to the sign-up screen
      },
    );
  }
}
