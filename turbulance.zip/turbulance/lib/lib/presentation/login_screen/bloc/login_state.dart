part of 'login_bloc.dart';

/// Represents the state of Login in the application.
class LoginState extends Equatable {
  LoginState({
    this.emailController,
    this.passwordController,
    this.selectedDropdownValue,
    this.isPasswordVisible = true,
    this.loginModel,
  });

  final TextEditingController? emailController;
  final TextEditingController? passwordController;
  final SelectionPopupModel? selectedDropdownValue;
  final LoginModel? loginModel;
  final bool isPasswordVisible;

  @override
  List<Object?> get props => [
    emailController,
    passwordController,
    selectedDropdownValue,
    isPasswordVisible,
    loginModel,
  ];

  LoginState copyWith({
    TextEditingController? emailController,
    TextEditingController? passwordController,
    SelectionPopupModel? selectedDropdownValue,
    bool? isPasswordVisible,
    LoginModel? loginModel,
  }) {
    return LoginState(
      emailController: emailController ?? this.emailController,
      passwordController: passwordController ?? this.passwordController,
      selectedDropdownValue: selectedDropdownValue ?? this.selectedDropdownValue,
      isPasswordVisible: isPasswordVisible ?? this.isPasswordVisible,
      loginModel: loginModel ?? this.loginModel,
    );
  }
}
