import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/login_model.dart';

part 'login_event.dart';
part 'login_state.dart';

/// A bloc that manages the state of a Login according to the event that is dispatched to it.
class LoginBloc extends Bloc<LoginEvent, LoginState> {
  LoginBloc(LoginState initialState) : super(initialState) {
    on<LoginInitialEvent>(_onInitialize);
    on<ChangePasswordVisibilityEvent>(_changePasswordVisibility);
  }

  Future<void> _onInitialize(
      LoginInitialEvent event,
      Emitter<LoginState> emit,
      ) async {
    emit(
      state.copyWith(
        emailController: TextEditingController(),
        passwordController: TextEditingController(),
        isPasswordVisible: true,
      ),
    );

    emit(
      state.copyWith(
        loginModel: state.loginModel?.copyWith(
          dropdownItemList: _fillDropdownItemList(),
        ),
      ),
    );
  }

  Future<void> _changePasswordVisibility(
      ChangePasswordVisibilityEvent event,
      Emitter<LoginState> emit,
      ) async {
    emit(state.copyWith(isPasswordVisible: event.value));
  }

  List<SelectionPopupModel> _fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
