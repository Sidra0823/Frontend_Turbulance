import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';

/// This class defines the variables used in the [login_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class LoginModel extends Equatable {
  LoginModel({this.dropdownItemList = const []});

  final List<SelectionPopupModel> dropdownItemList;

  LoginModel copyWith({
    List<SelectionPopupModel>? dropdownItemList,
  }) {
    return LoginModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
    );
  }

  @override
  List<Object?> get props => [dropdownItemList];
}
