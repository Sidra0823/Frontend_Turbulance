part of 'header_bloc.dart';

/// Abstract class for all events that can be dispatched from the Header widget.
abstract class HeaderEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event dispatched when the Header widget is initialized.
class HeaderInitialEvent extends HeaderEvent {}
