import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/header_model.dart';

part 'header_event.dart';
part 'header_state.dart';

/// A bloc that manages the state of a Header according to the event dispatched.
class HeaderBloc extends Bloc<HeaderEvent, HeaderState> {
  HeaderBloc(HeaderState initialState) : super(initialState) {
    on<HeaderInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(HeaderInitialEvent event, Emitter<HeaderState> emit) async {
    emit(state.copyWith(headerModelObj: HeaderModel()));
  }
}
