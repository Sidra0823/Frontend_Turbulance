part of 'header_bloc.dart';

/// Represents the state of Header in the application.
class HeaderState extends Equatable {
  final HeaderModel? headerModelObj;

  HeaderState({this.headerModelObj});

  @override
  List<Object?> get props => [headerModelObj];

  HeaderState copyWith({HeaderModel? headerModelObj}) {
    return HeaderState(
      headerModelObj: headerModelObj ?? this.headerModelObj,
    );
  }
}
