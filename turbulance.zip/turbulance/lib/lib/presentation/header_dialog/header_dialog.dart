import 'package:flutter/material.dart';
import 'bloc/header_bloc.dart';
import 'models/header_model.dart';

/// A dialog widget with Header functionality.
class HeaderDialog extends StatelessWidget {
  const HeaderDialog({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => HeaderBloc(HeaderState(headerModelObj: HeaderModel()))
        ..add(HeaderInitialEvent()),
      child: const HeaderDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 48.h),
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 16.h),
          decoration: AppDecoration.outlineOnPrimary1.copyWith(
            borderRadius: BorderRadiusStyle.roundedBorders,
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgGoogleRed50001,
                height: 32.h,
                width: 32.h,
              ),
              Padding(
                padding: EdgeInsets.only(left: 16.h, top: 4.h),
                child: Text(
                  "msg_sign_in_with_google".tr,
                  style: CustomTextStyles.bodyLargeRoboto18,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
