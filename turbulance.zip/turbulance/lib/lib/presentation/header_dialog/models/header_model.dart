import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [header_dialog],
/// typically to hold data that is passed between parts of the application.
class HeaderModel extends Equatable {
  HeaderModel();

  HeaderModel copyWith() {
    return HeaderModel();
  }

  @override
  List<Object?> get props => [];
}
