import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/create_group_bloc.dart';
import 'models/create_group_model.dart';
import 'models/listgroup139_item_model.dart';
import 'widgets/listgroup139_item_widget.dart';

class CreateGroupPage extends StatefulWidget {
  const CreateGroupPage({Key? key}) : super(key: key);

  @override
  CreateGroupPageState createState() => CreateGroupPageState();

  static Widget builder(BuildContext context) {
    return BlocProvider<CreateGroupBloc>(
      create: (context) => CreateGroupBloc(CreateGroupState(
        createGroupModelObj: CreateGroupModel(),
      ))..add(CreateGroupInitialEvent()),
      child: CreateGroupPage(),
    );
  }
}

class CreateGroupPageState extends State<CreateGroupPage> with AutomaticKeepAliveClientMixin<CreateGroupPage> {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);

    return Scaffold(
      backgroundColor: Colors.transparent,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Column(
                children: [
                  BlocSelector<CreateGroupBloc, CreateGroupState, TextEditingController?>(
                    selector: (state) => state.searchController,
                    builder: (context, searchController) {
                      return CustomSearchView(controller: searchController, hintText: "Search");
                    },
                  ),
                  SizedBox(height: 8),
                  BlocSelector<CreateGroupBloc, CreateGroupState, TextEditingController?>(
                    selector: (state) => state.settingsoneController,
                    builder: (context, settingsoneController) {
                      return CustomTextFormField(
                        controller: settingsoneController,
                        hintText: "Create Group",
                      );
                    },
                  ),
                  SizedBox(height: 36),
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: BlocSelector<CreateGroupBloc, CreateGroupState, CreateGroupModel?>(
                        selector: (state) => state.createGroupModelObj,
                        builder: (context, createGroupModelObj) {
                          return ListView.separated(
                            itemCount: createGroupModelObj?.listgroup139ItemList.length ?? 0,
                            itemBuilder: (context, index) {
                              final model = createGroupModelObj?.listgroup139ItemList[index] ?? Listgroup139ItemModel();
                              return Listgroup139ItemWidget(model);
                            },
                            separatorBuilder: (context, index) => SizedBox(height: 38),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
