import 'package:equatable/equatable.dart';


/// This class is used in the [Listgroup139ItemWidget] screen.
class Listgroup139ItemModel extends Equatable {
  final String? image;
  final String? imageOne;
  final String? group139;
  final String? closefriends;
  final String? thankyoufor;
  final String? time;
  final String? group141;
  final String? id;

  Listgroup139ItemModel({
    this.image,
    this.imageOne,
    this.group139,
    this.closefriends,
    this.thankyoufor,
    this.time,
    this.group141,
    this.id,
  });

  Listgroup139ItemModel copyWith({
    String? image,
    String? imageOne,
    String? group139,
    String? closefriends,
    String? thankyoufor,
    String? time,
    String? group141,
    String? id,
  }) {
    return Listgroup139ItemModel(
      image: image ?? this.image,
      imageOne: imageOne ?? this.imageOne,
      group139: group139 ?? this.group139,
      closefriends: closefriends ?? this.closefriends,
      thankyoufor: thankyoufor ?? this.thankyoufor,
      time: time ?? this.time,
      group141: group141 ?? this.group141,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [image, imageOne, group139, closefriends, thankyoufor, time, group141, id];
}
