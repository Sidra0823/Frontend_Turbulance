import 'package:equatable/equatable.dart';

import 'listgroup139_item_model.dart';

/// This class defines the variables used in the [CreateGroupPage],
/// and is typically used to hold data that is passed between different parts of the application.
class CreateGroupModel extends Equatable {
  final List<Listgroup139ItemModel> listgroup139ItemList;

  CreateGroupModel({this.listgroup139ItemList = const []});

  CreateGroupModel copyWith({
    List<Listgroup139ItemModel>? listgroup139ItemList,
  }) {
    return CreateGroupModel(
      listgroup139ItemList: listgroup139ItemList ?? this.listgroup139ItemList,
    );
  }

  @override
  List<Object?> get props => [listgroup139ItemList];
}
