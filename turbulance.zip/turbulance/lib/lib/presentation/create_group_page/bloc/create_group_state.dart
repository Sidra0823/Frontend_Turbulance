part of 'create_group_bloc.dart';

/// State class for managing the state of the CreateGroup widget.
class CreateGroupState extends Equatable {
  final TextEditingController? searchController;
  final TextEditingController? settingsoneController;
  final CreateGroupModel? createGroupModelObj;

  const CreateGroupState({
    this.searchController,
    this.settingsoneController,
    this.createGroupModelObj,
  });

  /// Creates a copy of the current state with the option to override some properties.
  CreateGroupState copyWith({
    TextEditingController? searchController,
    TextEditingController? settingsoneController,
    CreateGroupModel? createGroupModelObj,
  }) {
    return CreateGroupState(
      searchController: searchController ?? this.searchController,
      settingsoneController: settingsoneController ?? this.settingsoneController,
      createGroupModelObj: createGroupModelObj ?? this.createGroupModelObj,
    );
  }

  @override
  List<Object?> get props => [searchController, settingsoneController, createGroupModelObj];
}
