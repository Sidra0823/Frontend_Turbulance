part of 'create_group_bloc.dart';

/// Abstract class for all events that can be dispatched from the CreateGroup widget.
abstract class CreateGroupEvent extends Equatable {
  const CreateGroupEvent();

  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the CreateGroup widget is initialized.
class CreateGroupStartedEvent extends CreateGroupEvent {}
