import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

/// Ensure `part` directives are at the top, after imports.
part 'create_group_event.dart';
part 'create_group_state.dart';

/// Define ImageConstant class with dummy image paths or replace with your actual implementation.
class ImageConstant {
  static const String imgDownload4730x30 = "assets/images/img_download_30x30.png";
  static const String imgDownload5030x30 = "assets/images/img_download_50x30.png";
}

/// Mock classes for app export (replace with actual imports and implementations).
abstract class AppExport {}
abstract class CreateGroupModel {
  CreateGroupModel copyWith({List<Listgroup139ItemModel>? listgroup139ItemList});
}

/// Item model for the group list.
class Listgroup139ItemModel {
  final String? image;
  final String? imageOne;
  final String? group139;
  final String? closefriends;
  final String? thankyoufor;
  final String? time;
  final String? group141;

  Listgroup139ItemModel({
    this.image,
    this.imageOne,
    this.group139,
    this.closefriends,
    this.thankyoufor,
    this.time,
    this.group141,
  });
}

/// A Bloc that manages the state of CreateGroup according to the event that is dispatched to it.
class CreateGroupBloc extends Bloc<CreateGroupEvent, CreateGroupState> {
  CreateGroupBloc(CreateGroupState initialState) : super(initialState);

  Stream<CreateGroupState> mapEventToState(CreateGroupEvent event) async* {
    if (event is CreateGroupInitialEvent) {
      yield* _onInitialize(event);
    }
  }

  Stream<CreateGroupState> _onInitialize(CreateGroupInitialEvent event) async* {
    yield state.copyWith(
      searchController: TextEditingController(),
      settingsoneController: TextEditingController(),
      createGroupModelObj: state.createGroupModelObj?.copyWith(
        listgroup139ItemList: fillListgroup139ItemList(),
      ),
    );
  }

  List<Listgroup139ItemModel> fillListgroup139ItemList() {
    return [
      Listgroup139ItemModel(
        image: ImageConstant.imgDownload4730x30,
        imageOne: ImageConstant.imgDownload5030x30,
        group139: "+9",
        closefriends: "Close Friends",
        thankyoufor: "Thank you for sharing",
        time: "3:03pm",
        group141: "1",
      ),
      Listgroup139ItemModel(
        closefriends: "Close Friends",
        thankyoufor: "Thank you for sharing",
        time: "3:03pm",
        group141: "1",
      ),
    ];
  }
}

/// Event definition (replace with actual implementation)
abstract class CreateGroupEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class CreateGroupInitialEvent extends CreateGroupEvent {}

/// State definition (replace with actual implementation)
class CreateGroupState extends Equatable {
  final TextEditingController? searchController;
  final TextEditingController? settingsoneController;
  final CreateGroupModel? createGroupModelObj;

  CreateGroupState({
    this.searchController,
    this.settingsoneController,
    this.createGroupModelObj,
  });

  CreateGroupState copyWith({
    TextEditingController? searchController,
    TextEditingController? settingsoneController,
    CreateGroupModel? createGroupModelObj,
  }) {
    return CreateGroupState(
      searchController: searchController ?? this.searchController,
      settingsoneController: settingsoneController ?? this.settingsoneController,
      createGroupModelObj: createGroupModelObj ?? this.createGroupModelObj,
    );
  }

  @override
  List<Object?> get props => [searchController, settingsoneController, createGroupModelObj];
}
