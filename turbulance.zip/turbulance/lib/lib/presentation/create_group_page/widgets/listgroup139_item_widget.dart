import 'package:flutter/material.dart';
import '../models/listgroup139_item_model.dart';

class Listgroup139ItemWidget extends StatelessWidget {
  final Listgroup139ItemModel listgroup139ItemModelObj;

  const Listgroup139ItemWidget(this.listgroup139ItemModelObj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: 50,
            width: 40,
            margin: EdgeInsets.only(top: 4),
            child: Stack(
              alignment: Alignment.bottomLeft,
              children: [
                CustomImageView(
                  imagePath: listgroup139ItemModelObj.image!,
                  height: 24,
                  width: 26,
                  radius: BorderRadius.circular(10),
                ),
                CustomImageView(
                  imagePath: listgroup139ItemModelObj.imageOne!,
                  height: 24,
                  width: 26,
                  radius: BorderRadius.circular(10),
                ),
                Container(
                  width: 28,
                  height: 28,
                  alignment: Alignment.center,
                  margin: EdgeInsets.only(left: 6),
                  decoration: BoxDecoration(
                    color: Colors.grey[500],
                    borderRadius: BorderRadius.circular(5),
                  ),
                  child: Text(
                    listgroup139ItemModelObj.group139!,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: 28),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  listgroup139ItemModelObj.closefriends!,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 2),
                Text(
                  listgroup139ItemModelObj.thankyoufor!,
                  style: TextStyle(color: Colors.grey),
                ),
                SizedBox(height: 4),
                Text(
                  listgroup139ItemModelObj.time!,
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
