import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_ninetysix_screen].
class Iphone1415ProMaxNinetysixModel extends Equatable {
  Iphone1415ProMaxNinetysixModel({this.dropdownItemList = const []});

  final List<SelectionPopupModel> dropdownItemList;

  Iphone1415ProMaxNinetysixModel copyWith({List<SelectionPopupModel>? dropdownItemList}) {
    return Iphone1415ProMaxNinetysixModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
    );
  }

  @override
  List<Object?> get props => [dropdownItemList];
}
