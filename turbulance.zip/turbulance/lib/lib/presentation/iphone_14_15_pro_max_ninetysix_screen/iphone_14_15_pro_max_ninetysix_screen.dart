import 'package:flutter/material.dart';
import 'bloc/iphone_14_15_pro_max_ninetysix_bloc.dart';
import 'models/iphone_14_15_pro_max_ninetysix_model.dart';

class Iphone1415ProMaxNinetysixScreen extends StatelessWidget {
  Iphone1415ProMaxNinetysixScreen({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxNinetysixBloc>(
      create: (context) => Iphone1415ProMaxNinetysixBloc(
        Iphone1415ProMaxNinetysixState(
          iphone1415ProMaxNinetysixModelObj: Iphone1415ProMaxNinetysixModel(),
        ),
      )..add(Iphone1415ProMaxNinetysixInitialEvent()),
      child: Iphone1415ProMaxNinetysixScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Add widgets here based on requirements.
              ],
            ),
          ),
        ),
      ),
    );
  }
}
