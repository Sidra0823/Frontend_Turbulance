import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/iphone_14_15_pro_max_ninetysix_model.dart';

part 'iphone_14_15_pro_max_ninetysix_event.dart';
part 'iphone_14_15_pro_max_ninetysix_state.dart';

/// A bloc that manages the state of Iphone1415ProMaxNinetysix.
class Iphone1415ProMaxNinetysixBloc extends Bloc<Iphone1415ProMaxNinetysixEvent, Iphone1415ProMaxNinetysixState> {
  Iphone1415ProMaxNinetysixBloc(Iphone1415ProMaxNinetysixState initialState) : super(initialState) {
    on<Iphone1415ProMaxNinetysixInitialEvent>(_onInitialize);
  }

  void _onInitialize(Iphone1415ProMaxNinetysixInitialEvent event, Emitter<Iphone1415ProMaxNinetysixState> emit) async {
    emit(state.copyWith(phoneController: TextEditingController()));
    emit(state.copyWith(
      iphone1415ProMaxNinetysixModelObj: state.iphone1415ProMaxNinetysixModelObj?.copyWith(
        dropdownItemList: _fillDropdownItemList(),
      ),
    ));
  }

  List<SelectionPopupModel> _fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
