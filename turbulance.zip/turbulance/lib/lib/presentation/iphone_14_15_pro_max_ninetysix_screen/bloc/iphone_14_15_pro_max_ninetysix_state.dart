part of 'iphone_14_15_pro_max_ninetysix_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetysix in the application.
class Iphone1415ProMaxNinetysixState extends Equatable {
  Iphone1415ProMaxNinetysixState({
    this.phoneController,
    this.selectedDropDownValue,
    this.iphone1415ProMaxNinetysixModelObj,
  });

  final TextEditingController? phoneController;
  final SelectionPopupModel? selectedDropDownValue;
  final Iphone1415ProMaxNinetysixModel? iphone1415ProMaxNinetysixModelObj;

  @override
  List<Object?> get props => [
    phoneController,
    selectedDropDownValue,
    iphone1415ProMaxNinetysixModelObj,
  ];

  Iphone1415ProMaxNinetysixState copyWith({
    TextEditingController? phoneController,
    SelectionPopupModel? selectedDropDownValue,
    Iphone1415ProMaxNinetysixModel? iphone1415ProMaxNinetysixModelObj,
  }) {
    return Iphone1415ProMaxNinetysixState(
      phoneController: phoneController ?? this.phoneController,
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      iphone1415ProMaxNinetysixModelObj: iphone1415ProMaxNinetysixModelObj ?? this.iphone1415ProMaxNinetysixModelObj,
    );
  }
}
