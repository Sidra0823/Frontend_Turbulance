part of 'iphone_14_15_pro_max_ninetysix_bloc.dart';

/// Abstract class for all events that can be dispatched from the Iphone1415ProMaxNinetysix widget.
abstract class Iphone1415ProMaxNinetysixEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Iphone1415ProMaxNinetysix widget is first created.
class Iphone1415ProMaxNinetysixInitialEvent extends Iphone1415ProMaxNinetysixEvent {}
