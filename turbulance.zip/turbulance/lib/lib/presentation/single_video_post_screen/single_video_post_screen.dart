import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/app_export.dart';
import 'bloc/single_video_post_bloc.dart';
import 'models/single_video_post_model.dart';

class SingleVideoPostScreen extends StatelessWidget {
  const SingleVideoPostScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<SingleVideoPostBloc>(
      create: (context) => SingleVideoPostBloc(SingleVideoPostState(
        singleVideoPostModelObj: SingleVideoPostModel(),
      ))..add(SingleVideoPostInitialEvent()),
      child: SingleVideoPostScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Single Video Post"),
        backgroundColor: Colors.blue,
      ),
      body: SafeArea(
        child: BlocBuilder<SingleVideoPostBloc, SingleVideoPostState>(
          builder: (context, state) {
            return Column(
              children: [
                // Display video content, for example using a video player
                Expanded(
                  child: Center(
                    child: Container(
                      width: double.maxFinite,
                      height: 200,
                      color: Colors.grey[300],
                      child: Center(
                        child: Text("Video Content Goes Here"),
                      ),
                    ),
                  ),
                ),

                // Display the comment section with a text field
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: TextField(
                    controller: TextEditingController(),
                    decoration: InputDecoration(
                      hintText: "Write a comment",
                      border: OutlineInputBorder(),
                      contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                    ),
                  ),
                ),

                // Add action buttons (like a "Submit" button for the comment)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                  child: ElevatedButton(
                    onPressed: () {
                      // Add your onPressed logic here, e.g., submit the comment
                    },
                    child: Text("Submit Comment"),
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
