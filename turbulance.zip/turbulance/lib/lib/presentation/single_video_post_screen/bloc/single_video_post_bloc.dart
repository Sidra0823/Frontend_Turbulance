import 'package:equatable/equatable.dart';
import '../models/single_video_post_model.dart';

part 'single_video_post_event.dart';
part 'single_video_post_state.dart';

/// A bloc that manages the state of a SingleVideoPost according to the event that is dispatched to it.
class SingleVideoPostBloc extends Bloc<SingleVideoPostEvent, SingleVideoPostState> {
  SingleVideoPostBloc(SingleVideoPostState initialState) : super(initialState);

  // Handling the initialization event
  @override
  Stream<SingleVideoPostState> mapEventToState(
      SingleVideoPostEvent event,
      ) async* {
    if (event is SingleVideoPostInitialEvent) {
      yield* _onInitialize(event);
    }
  }

  // Initialize method
  Stream<SingleVideoPostState> _onInitialize(
      SingleVideoPostInitialEvent event,
      ) async* {
    // Add logic to handle the initialization, e.g. loading data or setting up initial state
    yield SingleVideoPostState(
      // Set the initial state, such as any initial data model for the SingleVideoPost
      singleVideoPostModelObj: SingleVideoPostModel(),
    );
  }
}
