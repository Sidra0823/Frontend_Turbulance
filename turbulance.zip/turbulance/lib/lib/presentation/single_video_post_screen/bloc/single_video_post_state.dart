part of 'single_video_post_bloc.dart';

/// Represents the state of SingleVideoPost in the application.
//
// ignore_for_file: must_be_immutable
class SingleVideoPostState extends Equatable {
  SingleVideoPostState({this.singleVideoPostModelObj});

  SingleVideoPostModel? singleVideoPostModelObj;

  @override
  List<Object?> get props => [singleVideoPostModelObj];

  SingleVideoPostState copyWith({
    SingleVideoPostModel? singleVideoPostModelObj,
  }) {
    return SingleVideoPostState(
      singleVideoPostModelObj: singleVideoPostModelObj ?? this.singleVideoPostModelObj,
    );
  }
}
