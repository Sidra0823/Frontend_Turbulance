import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/iphone_14_15_pro_max_eightynine_bloc.dart';
import 'models/iphone_14_15_pro_max_eightynine_model.dart';

class Iphone1415ProMaxEightynineScreen extends StatelessWidget {
  const Iphone1415ProMaxEightynineScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxEightynineBloc>(
      create: (context) => Iphone1415ProMaxEightynineBloc(
        Iphone1415ProMaxEightynineState(
          iphone1415ProMaxEightynineModelobj: Iphone1415ProMaxEightynineModel(),
        ),
      )..add(Iphone1415ProMaxEightynineInitialEvent()),
      child: const Iphone1415ProMaxEightynineScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(top: 182.h),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              CustomIconButton(
                height: 72.h,
                width: 72.h,
                padding: EdgeInsets.all(14.h),
                decoration: IconButtonStyleHelper.outlineOnPrimaryTL16,
                child: CustomImageView(
                  imagePath: ImageConstant.imgFavoriteOnprimary,
                ),
              ),
              SizedBox(height: 14.h),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "msg_use_your_apple_id".tr,
                      style: CustomTextStyles.bodyLargeRoboto_1,
                    ),
                    TextSpan(
                      text: "lbl_turbulence".tr,
                      style: CustomTextStyles.bodyLargeRoboto_1,
                    ),
                    TextSpan(
                      text: "lbl".tr,
                      style: CustomTextStyles.bodyLargeRoboto_1,
                    ),
                  ],
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: 12.h),
              BlocSelector<Iphone1415ProMaxEightynineBloc,
                  Iphone1415ProMaxEightynineState, TextEditingController?>(
                selector: (state) => state.inputoneController,
                builder: (context, inputoneController) {
                  return CustomTextFormField(
                    width: 220.h,
                    controller: inputoneController,
                    hintText: "lbl_apple_id".tr,
                    hintStyle: CustomTextStyles.bodyLargeRoboto_2,
                    textInputAction: TextInputAction.done,
                    suffix: Container(
                      margin: EdgeInsets.fromLTRB(16.h, 16.h, 20.h, 16.h),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgArrowleftonprimary,
                        height: 24.h,
                        width: 26.h,
                        fit: BoxFit.contain,
                      ),
                    ),
                    suffixConstraints: BoxConstraints(
                      maxHeight: 56.h,
                    ),
                    contentPadding: EdgeInsets.fromLTRB(14.h, 16.h, 20.h, 16.h),
                    borderDecoration: TextFormFieldstyleHelper.outlineOnPrimaryTL12,
                    filled: false,
                  );
                },
              ),
              SizedBox(height: 16.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "msg_forgotten_your_apple".tr,
                    style: CustomTextStyles.bodySmallRobotoOnPrimary12_1,
                  ),
                  SizedBox(width: 4.h),
                  CustomImageView(
                    imagePath: ImageConstant.imgArrowUpRight,
                    height: 14.h,
                    width: 14.h,
                  ),
                ],
              ),
              SizedBox(height: 14.h),
              CustomImageView(
                imagePath: ImageConstant.imgIcon24x30,
                height: 24.h,
                width: 32.h,
              ),
              SizedBox(
                width: 278.h,
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "msg_having_set_up_sign".tr,
                        style: CustomTextStyles.bodySmallRobotoOnPrimary12,
                      ),
                      TextSpan(
                        text: "msg_see_how_your_data".tr,
                        style: CustomTextStyles.bodySmallRobotoLightblue700,
                      ),
                    ],
                    textAlign: TextAlign.center,
                    maxLines: 4,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
