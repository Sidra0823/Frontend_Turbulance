import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_eightynine_screen],
/// and is typically used to hold data that is passed between different parts of the application.

class Iphone1415ProMaxEightynineModel extends Equatable {
  // Define any properties here as needed
  // For example, you can add:
  // final String? name;
  // final int? id;

  Iphone1415ProMaxEightynineModel({
// Initialize properties here if needed
// this.name,
// this.id,
});

// A method to create a copy of this model with updated values for the properties
Iphone1415ProMaxEightynineModel copyWith({
// Add properties here for copyWith to update them
// String? name,
// int? id,
}) {
return Iphone1415ProMaxEightynineModel(
// Return new instance with updated properties
// name: name ?? this.name,
// id: id ?? this.id,
);
}

@override
List<Object?> get props => [
// Include the properties that should be used for comparison here
// For example:
// name,
// id,
];
}
