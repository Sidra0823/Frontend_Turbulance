import 'package:flutter/material.dart';
import '../models/iphone_14_15_pro_max_eightynine_model.dart';

part 'iphone_14_15_pro_max_eightynine_event.dart';
part 'iphone_14_15_pro_max_eightynine_state.dart';

/// A bloc that manages the state of Iphone1415ProMaxEightynine according to the event that is dispatched to it.
class Iphone1415ProMaxEightynineBloc extends Bloc<Iphone1415ProMaxEightynineEvent, Iphone1415ProMaxEightynineState> {
  Iphone1415ProMaxEightynineBloc(Iphone1415ProMaxEightynineState initialState) : super(initialState) {
    on<Iphone1415ProMaxEightynineInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      Iphone1415ProMaxEightynineInitialEvent event,
      Emitter<Iphone1415ProMaxEightynineState> emit,
      ) async {
    emit(
      state.copyWith(
        inputOneController: TextEditingController(),
      ),
    );
  }
}
