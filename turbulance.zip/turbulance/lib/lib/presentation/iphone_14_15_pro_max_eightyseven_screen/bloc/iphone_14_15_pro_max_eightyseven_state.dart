part of 'iphone_14_15_pro_max_eightynine_bloc.dart';

/// Represents the state of Iphone1415ProMaxEightynine in the application.
///
/// ignore_for_file: must_be_immutable
class Iphone1415ProMaxEightynineState extends Equatable {
  final TextEditingController? inputOneController;
  final Iphone1415ProMaxEightynineModel? iphone1415ProMaxEightynineModelObj;

  Iphone1415ProMaxEightynineState({
    this.inputOneController,
    this.iphone1415ProMaxEightynineModelObj,
  });

  @override
  List<Object?> get props => [inputOneController, iphone1415ProMaxEightynineModelObj];

  Iphone1415ProMaxEightynineState copyWith({
    TextEditingController? inputOneController,
    Iphone1415ProMaxEightynineModel? iphone1415ProMaxEightynineModelObj,
  }) {
    return Iphone1415ProMaxEightynineState(
      inputOneController: inputOneController ?? this.inputOneController,
      iphone1415ProMaxEightynineModelObj: iphone1415ProMaxEightynineModelObj ?? this.iphone1415ProMaxEightynineModelObj,
    );
  }
}
