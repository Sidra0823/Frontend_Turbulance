import 'package:flutter/material.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import 'package:flutter_chat_ui/flutter_chat_ui.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle.dart';
import '../../widgets/app_bar/appbar_subtitle_nine.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/message_bloc.dart';
import 'models/message_model.dart';

class MessageScreen extends StatelessWidget {
  const MessageScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<MessageBloc>(
      create: (context) => MessageBloc(MessageState(messageModelObj: MessageModel()))
        ..add(MessageInitialEvent()),
      child: const MessageScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      appBar: buildAppbar(context),
      body: SafeArea(
        top: false,
        child: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 224.h),
              Expanded(
                child: SizedBox(
                  width: double.maxFinite,
                  child: BlocBuilder<MessageBloc, MessageState>(
                    builder: (context, state) {
                      return Chat(
                        showUserNames: false,
                        disableImageGallery: false,
                        dateHeaderThreshold: 86400000,
                        messages: state.messagelist!,
                        user: state.chatUser!,
                        onSendPressed: (types.PartialText text) {},
                        customBottomWidget: Container(
                          width: double.maxFinite,
                          padding: EdgeInsets.symmetric(horizontal: 8.h),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(bottom: 12.h),
                                child: BlocSelector<MessageBloc, MessageState, TextEditingController?>(
                                  selector: (state) => state.messagesixController,
                                  builder: (context, messagesixController) {
                                    return CustomTextFormField(
                                      controller: messagesixController,
                                      hintText: "lbl_messages2".tr,
                                      hintStyle: CustomTextStyles.titleLargeBlack900Regular,
                                      textInputAction: TextInputAction.done,
                                      prefix: Container(
                                        padding: EdgeInsets.all(8.h),
                                        margin: EdgeInsets.fromLTRB(6.h, 8.h, 8.h, 8.h),
                                        decoration: BoxDecoration(
                                          color: appTheme.lightBlue700,
                                          borderRadius: BorderRadius.circular(20.h),
                                        ),
                                        child: CustomImageView(
                                          imagePath: ImageConstant.imgCameraBlack900,
                                          height: 24.h,
                                          width: 24.h,
                                          fit: BoxFit.contain,
                                        ),
                                      ),
                                      prefixConstraints: BoxConstraints(maxHeight: 58.h),
                                      suffix: Padding(
                                        padding: EdgeInsets.fromLTRB(30.h, 13.h, 23.h, 13.h),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            CustomImageView(
                                              imagePath: ImageConstant.imgMenu,
                                              height: 26.07.h,
                                              width: 24.79.h,
                                              margin: EdgeInsets.symmetric(horizontal: 30.h),
                                            ),
                                            CustomImageView(
                                              imagePath: ImageConstant.imgFavoriteBlack900,
                                              height: 32.h,
                                              width: 32.h,
                                            ),
                                          ],
                                        ),
                                      ),
                                      suffixConstraints: BoxConstraints(maxHeight: 58.h),
                                      contentPadding: EdgeInsets.symmetric(vertical: 14.h),
                                      borderDecoration: TextFormFieldStyleHelper.fillGrayTL20,
                                      fillColor: appTheme.gray50061,
                                    );
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowLeftOne(context);
        },
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 23.h),
        child: Column(
          children: [
            AppbarSubtitle(text: "lbl_grace".tr),
            Padding(
              padding: EdgeInsets.only(left: 5.h, right: 4.h),
              child: Row(
                children: [
                  Container(
                    height: 6.h,
                    width: 6.h,
                    margin: EdgeInsets.only(top: 5.h, bottom: 4.h),
                    decoration: BoxDecoration(
                      color: appTheme.green600,
                      borderRadius: BorderRadius.circular(3.h),
                    ),
                  ),
                  AppbarSubtitleNine(
                    text: "lbl_online".tr,
                    margin: EdgeInsets.only(left: 9.h),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgCall,
          height: 22.h,
          width: 20.h,
        ),
        AppbarTrailingImage(
          imagePath: ImageConstant.imgUpload,
          height: 32.h,
          width: 32.h,
          margin: EdgeInsets.symmetric(horizontal: 26.h),
        ),
      ],
    );
  }

  void onTapArrowLeftOne(BuildContext context) {
    NavigatorService.goBack();
  }
}
