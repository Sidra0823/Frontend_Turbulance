part of 'message_bloc.dart';

/// Represents the state of Message in the application.
// ignore_for_file: must_be_immutable
class MessageState extends Equatable {
  MessageState({
    this.messagesixController,
    this.chatUser,
    this.messagelist,
    this.messageModelObj,
  });

  TextEditingController? messagesixController;
  MessageModel? messageModelObj;
  types.User? chatUser;
  List<types.Message>? messagelist;

  @override
  List<Object?> get props => [messagesixController, chatUser, messagelist, messageModelObj];

  MessageState copyWith({
    TextEditingController? messagesixController,
    types.User? chatUser,
    List<types.Message>? messagelist,
    MessageModel? messageModelObj,
  }) {
    return MessageState(
      chatUser: chatUser ?? this.chatUser,
      messagesixController: messagesixController ?? this.messagesixController,
      messagelist: messagelist ?? this.messagelist,
      messageModelObj: messageModelObj ?? this.messageModelObj,
    );
  }
}
