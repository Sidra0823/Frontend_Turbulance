import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_chat_types/flutter_chat_types.dart' as types;
import '../models/message_model.dart';

part 'message_event.dart';
part 'message_state.dart';

/// A bloc that manages the state of a Message according to the event that is dispatched to it.
class MessageBloc extends Bloc<MessageEvent, MessageState> {
  MessageBloc(MessageState initialState) : super(initialState) {
    on<MessageInitialEvent>(onInitialize);
  }

  _onInitialize(
      MessageInitialEvent event,
      Emitter<MessageState> exit,
      ) async {
    exit(
      state.copyWith(
        messagesixController: TextEditingController(),
      ),
    );
  }
}
