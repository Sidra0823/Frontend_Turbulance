part of 'live_one_bloc.dart';

/// Represents the state of LiveOne in the application.
class LiveOneState extends Equatable {
  LiveOneState({this.liveOneModelObj});

  final LiveOneModel? liveOneModelObj;

  @override
  List<Object?> get props => [liveOneModelObj];

  LiveOneState copyWith({LiveOneModel? liveOneModelObj}) {
    return LiveOneState(
      liveOneModelObj: liveOneModelObj ?? this.liveOneModelObj,
    );
  }
}
