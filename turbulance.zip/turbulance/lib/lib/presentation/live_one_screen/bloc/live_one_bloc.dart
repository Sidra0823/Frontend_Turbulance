import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/live_one_model.dart';

part 'live_one_event.dart';
part 'live_one_state.dart';

/// A bloc that manages the state of LiveOne according to the event dispatched to it.
class LiveOneBloc extends Bloc<LiveOneEvent, LiveOneState> {
  LiveOneBloc(LiveOneState initialState) : super(initialState) {
    on<LiveOneInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      LiveOneInitialEvent event,
      Emitter<LiveOneState> emit,
      ) async {
    // Add initialization logic if required
    emit(state.copyWith());
  }
}
