part of 'live_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the LiveOne widget.
class LiveOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the LiveOne widget is first created.
class LiveOneInitialEvent extends LiveOneEvent {
  @override
  List<Object?> get props => [];
}
