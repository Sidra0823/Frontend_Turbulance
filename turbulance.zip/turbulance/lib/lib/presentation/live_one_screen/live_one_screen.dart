import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_trailing_iconbutton_one.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'bloc/live_one_bloc.dart';
import 'models/live_one_model.dart';

class LiveOneScreen extends StatelessWidget {
  const LiveOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<LiveOneBloc>(
      create: (context) => LiveOneBloc(
        LiveOneState(
          liveOneModelObj: LiveOneModel(),
        ),
      )..add(LiveOneInitialEvent()),
      child: const LiveOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LiveOneBloc, LiveOneState>(
      builder: (context, state) {
        return Scaffold(
          extendBody: true,
          extendBodyBehindAppBar: true,
          backgroundColor: appTheme.black900,
          appBar: _buildAppBar(context),
          body: Container(
            width: double.maxFinite,
            height: SizeUtils.height,
            decoration: AppDecoration.fillBlack9001,
            child: SafeArea(
              child: SizedBox(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.all(14.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            height: 28.h,
                            width: double.maxFinite,
                            margin: EdgeInsets.only(right: 370.h),
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgMusic,
                                  height: 28.h,
                                  width: 30.h,
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 20.h),
                        ],
                      ),
                    ),
                    _buildRowViewTwo(context),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () => _onTapArrowLeftOne(context),
      ),
      actions: [
        AppbarTrailingIconbuttonOne(
          imagePath: ImageConstant.imgArrowRight,
          margin: EdgeInsets.only(
            top: 5.h,
            right: 29.h,
            bottom: 7.h,
          ),
        ),
      ],
    );
  }

  Widget _buildRowViewTwo(BuildContext context) {
    return Container(
      height: 92.h,
      padding: EdgeInsets.symmetric(horizontal: 12.h),
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            height: 40.h,
            width: 40.h,
            margin: EdgeInsets.only(left: 4.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
              borderRadius: BorderRadius.circular(20.h),
            ),
          ),
          Spacer(),
          CustomImageView(
            imagePath: ImageConstant.imgDownload62,
            height: 64.h,
            width: 66.h,
            radius: BorderRadius.circular(32.h),
          ),
          Align(
            alignment: Alignment.topCenter,
            child: Container(
              height: 80.h,
              width: 82.h,
              margin: EdgeInsets.only(
                left: 28.h,
                bottom: 12.h,
              ),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgUntitledDesign80x80,
                    height: 80.h,
                    width: 80.h,
                    radius: BorderRadius.circular(40.h),
                  ),
                  Text(
                    "lbl_live".tr,
                    style: CustomTextStyles.titleLargeExtraBold,
                  ),
                ],
              ),
            ),
          ),
          Container(
            height: 64.h,
            width: 66.h,
            margin: EdgeInsets.only(left: 28.h),
            decoration: AppDecoration.fillBlueGray.copyWith(
              borderRadius: BorderRadiusStyle.circleBorder32,
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgImage23,
                  height: 64.h,
                  width: 64.h,
                  radius: BorderRadius.circular(32.h),
                ),
              ],
            ),
          ),
          Container(
            height: 40.h,
            width: 40.h,
            margin: EdgeInsets.only(left: 20.h),
            decoration: BoxDecoration(
              color: appTheme.blueGray100,
              borderRadius: BorderRadius.circular(20.h),
            ),
          ),
        ],
      ),
    );
  }

  /// Navigates to the previous screen.
  void _onTapArrowLeftOne(BuildContext context) {
    NavigatorService.goBack();
  }
}
