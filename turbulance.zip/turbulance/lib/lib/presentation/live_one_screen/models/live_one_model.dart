import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [live_one_screen],
/// and is typically used to hold data passed between different parts of the application.
class LiveOneModel extends Equatable {
  LiveOneModel();

  LiveOneModel copyWith() {
    return LiveOneModel();
  }

  @override
  List<Object?> get props => [];
}
