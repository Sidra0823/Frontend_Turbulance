import 'package:flutter/material.dart';
import '../models/griddownload_item_model.dart';

/// A widget that displays a single item in a grid view.
class GriddownloadItemWidget extends StatelessWidget {
  const GriddownloadItemWidget(this.griddownloadItemModelObj, {Key? key}) : super(key: key);

  final GriddownloadItemModel griddownloadItemModelObj;

  @override
  Widget build(BuildContext context) {
    return CustomImageView(
      imagePath: griddownloadItemModelObj.download ?? '',
      height: 124.h,
      width: 124.h,
      radius: BorderRadius.circular(14.h),
    );
  }
}
