import 'package:flutter/material.dart';
import 'package:responsive_grid_list/responsive_grid_list.dart';
import 'bloc/profile_page_photo_post_bloc.dart';
import 'models/griddownload_item_model.dart';
import 'models/scrollview_one_tab_model.dart';
import 'widgets/griddownload_item_widget.dart';

class ScrollviewOneTabPage extends StatefulWidget {
  const ScrollviewOneTabPage({Key? key}) : super(key: key);

  @override
  ScrollviewOneTabPageState createState() => ScrollviewOneTabPageState();

  /// Static builder method to create the page.
  static Widget builder(BuildContext context) {
    return BlocProvider<ProfilePagePhotoPostBloc>(
      create: (context) => ProfilePagePhotoPostBloc(
        ProfilePagePhotoPostState(
          scrollviewOneTabModelObj: ScrollviewOneTabModel(),
        ),
      )..add(ProfilePagePhotoPostInitialEvent()),
      child: const ScrollviewOneTabPage(),
    );
  }
}

class ScrollviewOneTabPageState extends State<ScrollviewOneTabPage> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      primary: true,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 8.h),
        child: Column(
          children: [
            SizedBox(height: 12.h),
            buildGridDownload(context),
          ],
        ),
      ),
    );
  }

  /// Builds the grid view for displaying items.
  Widget buildGridDownload(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 4.h),
      child: BlocSelector<ProfilePagePhotoPostBloc, ProfilePagePhotoPostState,
          ScrollviewOneTabModel?>(
        selector: (state) => state.scrollviewOneTabModelObj,
        builder: (context, scrollviewOneTabModelObj) {
          return ResponsiveGridList(
            minItemWidth: 100.h,
            minItemsPerRow: 3,
            maxItemsPerRow: 3,
            horizontalGridSpacing: 8.h,
            verticalGridSpacing: 8.h,
            children: List.generate(
              scrollviewOneTabModelObj?.griddownloadItemList.length ?? 0,
                  (index) {
                GriddownloadItemModel model = scrollviewOneTabModelObj
                    ?.griddownloadItemList[index] ??
                    GriddownloadItemModel();
                return GriddownloadItemWidget(model);
              },
            ),
          );
        },
      ),
    );
  }
}
