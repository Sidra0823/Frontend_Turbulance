part of 'profile_page_photo_post_bloc.dart';

/// Represents the state of ProfilePagePhotoPost in the application.
class ProfilePagePhotoPostState extends Equatable {
  ProfilePagePhotoPostState({
    this.scrollviewOneTabModelObj,
    this.profilePagePhotoPostModelObj,
  });

  final ProfilePagePhotoPostModel? profilePagePhotoPostModelObj;
  final ScrollviewOneTabModel? scrollviewOneTabModelObj;

  @override
  List<Object?> get props => [scrollviewOneTabModelObj, profilePagePhotoPostModelObj];

  ProfilePagePhotoPostState copyWith({
    ScrollviewOneTabModel? scrollviewOneTabModelObj,
    ProfilePagePhotoPostModel? profilePagePhotoPostModelObj,
  }) {
    return ProfilePagePhotoPostState(
      scrollviewOneTabModelObj: scrollviewOneTabModelObj ?? this.scrollviewOneTabModelObj,
      profilePagePhotoPostModelObj: profilePagePhotoPostModelObj ?? this.profilePagePhotoPostModelObj,
    );
  }
}
