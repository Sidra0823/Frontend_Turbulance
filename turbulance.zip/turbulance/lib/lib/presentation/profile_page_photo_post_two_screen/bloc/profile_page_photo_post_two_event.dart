part of 'profile_page_photo_post_bloc.dart';

/// Abstract class for all events that can be dispatched from the ProfilePagePhotoPost widget.
abstract class ProfilePagePhotoPostEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event dispatched when the ProfilePagePhotoPost widget is first created.
class ProfilePagePhotoPostInitialEvent extends ProfilePagePhotoPostEvent {}
