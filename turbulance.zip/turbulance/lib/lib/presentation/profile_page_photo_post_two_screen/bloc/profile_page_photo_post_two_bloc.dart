import 'package:flutter_bloc/flutter_bloc.dart';
import '../models/griddownload_item_model.dart';
import '../models/profile_page_photo_post_model.dart';
import '../models/scrollview_one_tab_model.dart';

part 'profile_page_photo_post_event.dart';
part 'profile_page_photo_post_state.dart';

/// Bloc that manages the state of ProfilePagePhotoPost according to the event dispatched to it.
class ProfilePagePhotoPostBloc extends Bloc<ProfilePagePhotoPostEvent, ProfilePagePhotoPostState> {
  ProfilePagePhotoPostBloc(ProfilePagePhotoPostState initialState)
      : super(initialState) {
    on<ProfilePagePhotoPostInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      ProfilePagePhotoPostInitialEvent event,
      Emitter<ProfilePagePhotoPostState> emit,
      ) async {
    emit(
      state.copyWith(
        scrollviewOneTabModelObj: state.scrollviewOneTabModelObj?.copyWith(
          griddownloadItemList: _fillGriddownloadItemList(),
        ),
      ),
    );
  }

  List<GriddownloadItemModel> _fillGriddownloadItemList() {
    return [
      GriddownloadItemModel(download: ImageConstant.imgDownload52),
      GriddownloadItemModel(download: ImageConstant.imgDownload54),
      GriddownloadItemModel(download: ImageConstant.imgDownload56),
      GriddownloadItemModel(download: ImageConstant.imgImage25),
      GriddownloadItemModel(download: ImageConstant.imgDownload60),
      GriddownloadItemModel(download: ImageConstant.imgImage25),
      GriddownloadItemModel(),
      GriddownloadItemModel(),
      GriddownloadItemModel(),
    ];
  }
}
