import 'package:equatable/equatable.dart';
import 'griddownload_item_model.dart';

/// This class is used in the `scrollview_one_tab_page` screen.
class ScrollviewOneTabModel extends Equatable {
  ScrollviewOneTabModel({this.griddownloadItemList = const []});

  final List<GriddownloadItemModel> griddownloadItemList;

  ScrollviewOneTabModel copyWith({List<GriddownloadItemModel>? griddownloadItemList}) {
    return ScrollviewOneTabModel(
      griddownloadItemList: griddownloadItemList ?? this.griddownloadItemList,
    );
  }

  @override
  List<Object?> get props => [griddownloadItemList];
}
