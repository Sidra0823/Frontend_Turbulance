import 'package:equatable/equatable.dart';

/// Defines the variables used in the `profile_page_photo_post_page` and holds data passed between different parts of the application.
class ProfilePagePhotoPostModel extends Equatable {
  ProfilePagePhotoPostModel();

  ProfilePagePhotoPostModel copyWith() {
    return ProfilePagePhotoPostModel();
  }

  @override
  List<Object?> get props => [];
}
