import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../videos_post_page/videos_post_page.dart';
import 'bloc/profile_page_photo_post_bloc.dart';
import 'models/profile_page_photo_post_model.dart';
import 'scrollview_one_tab_page.dart';

/// A page that represents the ProfilePagePhotoPost screen.
class ProfilePagePhotoPostPage extends StatefulWidget {
  const ProfilePagePhotoPostPage({Key? key}) : super(key: key);

  @override
  ProfilePagePhotoPostPageState createState() => ProfilePagePhotoPostPageState();

  static Widget builder(BuildContext context) {
    return BlocProvider<ProfilePagePhotoPostBloc>(
      create: (context) => ProfilePagePhotoPostBloc(
        ProfilePagePhotoPostState(
          profilePagePhotoPostModelObj: ProfilePagePhotoPostModel(),
        ),
      )..add(ProfilePagePhotoPostInitialEvent()),
      child: const ProfilePagePhotoPostPage(),
    );
  }
}

class ProfilePagePhotoPostPageState extends State<ProfilePagePhotoPostPage> with TickerProviderStateMixin {
  late TabController tabViewController;

  @override
  void initState() {
    super.initState();
    tabViewController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: SizedBox(
          width: double.maxFinite,
          child: NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) {
              return [
                SliverToBoxAdapter(
                  child: Column(
                    children: [_buildColumnArrowLeft(context)],
                  ),
                ),
              ];
            },
            body: SizedBox(
              height: 424.h,
              child: TabBarView(
                controller: tabViewController,
                children: [
                  ScrollviewOneTabPage.builder(context),
                  VideosPostPage.builder(context),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildColumnArrowLeft(BuildContext context) {
    return Column(
      children: [
        CustomAppBar(
          leadingWidth: 70.h,
          leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 30.h),
            onTap: () {
              _onTapArrowLeft(context);
            },
          ),
          actions: [
            AppbarTrailingIconButton(
              imagePath: ImageConstant.imgCloseOnPrimary,
              margin: EdgeInsets.only(right: 29.h),
            ),
          ],
        ),
        CustomImageView(
          imagePath: ImageConstant.imgProfilePicture80x80,
          height: 80.h,
          width: 80.h,
          radius: BorderRadius.circular(40.h),
        ),
        SizedBox(height: 8.h),
        Text("lbl_turbulance".tr, style: CustomTextStyles.titleLarge22),
        Text("lbl_turbulance3".tr, style: CustomTextStyles.bodyLargeGray50001),
        SizedBox(height: 12.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("lbl_518".tr, style: theme.textTheme.titleMedium),
            Padding(
              padding: EdgeInsets.only(left: 12.h),
              child: Text("lbl_posts".tr, style: CustomTextStyles.titleMediumGray50001),
            ),
          ],
        ),
        SizedBox(height: 18.h),
        Container(
          width: double.maxFinite,
          margin: EdgeInsets.symmetric(horizontal: 60.h),
          child: Row(
            children: [
              Expanded(
                child: CustomElevatedButton(
                  height: 56.h,
                  text: "lbl_friends".tr,
                  leftIcon: Container(
                    margin: EdgeInsets.only(right: 8.h),
                    child: CustomImageView(
                      height: 12.h,
                      imagePath: ImageConstant.imgCheckmarkOnPrimary,
                    ),
                  ),
                  buttonStyle: CustomButtonStyles.fillPrimary,
                  buttonTextStyle: CustomTextStyles.titleMediumSemiBold,
                ),
              ),
              SizedBox(width: 26.h),
              Expanded(
                child: CustomElevatedButton(
                  height: 56.h,
                  text: "lbl_message".tr,
                  leftIcon: Container(
                    margin: EdgeInsets.only(right: 6.h),
                    child: CustomImageView(
                      height: 26.h,
                      width: 26.h,
                      imagePath: ImageConstant.imgUserBlack900,
                    ),
                  ),
                  buttonStyle: CustomButtonStyles.fillGray,
                  buttonTextStyle: CustomTextStyles.titleMediumBlack900,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 22.h),
        TabBar(
          controller: tabViewController,
          labelColor: appTheme.gray50001,
          labelStyle: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            fontFamily: 'Nunito',
          ),
          unselectedLabelColor: theme.colorScheme.onPrimary,
          unselectedLabelStyle: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            fontFamily: 'Nunito',
          ),
          indicatorColor: appTheme.gray50001,
          tabs: [
            Tab(child: Text("lbl_photos".tr)),
            Tab(child: Text("lbl_videos".tr)),
          ],
        ),
      ],
    );
  }

  void _onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
