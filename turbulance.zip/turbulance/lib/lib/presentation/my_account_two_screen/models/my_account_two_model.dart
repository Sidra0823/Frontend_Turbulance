import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [my_account_two_screen],
/// and is typically used to hold data passed between different parts of the application.
class MyAccountTwoModel extends Equatable {
  MyAccountTwoModel();

  MyAccountTwoModel copyWith() {
    return MyAccountTwoModel();
  }

  @override
  List<Object?> get props => [];
}
