import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'bloc/my_account_two_bloc.dart';
import 'models/my_account_two_model.dart';

class MyAccountTwoScreen extends StatelessWidget {
  const MyAccountTwoScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<MyAccountTwoBloc>(
      create: (context) => MyAccountTwoBloc(
        MyAccountTwoState(
          myAccountTwoModelObj: MyAccountTwoModel(),
        ),
      )..add(MyAccountTwoInitialEvent()),
      child: const MyAccountTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MyAccountTwoBloc, MyAccountTwoState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          appBar: _buildAppBar(context),
          body: SafeArea(
            top: false,
            child: Padding(
              padding: EdgeInsets.only(top: 18.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgHelpCircle,
                    height: 44.h,
                    width: 44.h,
                    radius: BorderRadius.circular(8.h),
                    margin: EdgeInsets.only(bottom: 4.h),
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 20.h),
                    child: Text(
                      "lbl_help".tr,
                      style: theme.textTheme.headlineMedium,
                    ),
                  ),
                  SizedBox(height: 50.h),
                  CustomImageView(
                    imagePath: ImageConstant.imgProfilePicture80x80,
                    height: 80.h,
                    width: 82.h,
                    radius: BorderRadius.circular(40.h),
                  ),
                  SizedBox(height: 18.h),
                  Text(
                    "lbl_turbulance".tr,
                    style: theme.textTheme.headlineLarge,
                  ),
                  SizedBox(height: 6.h),
                  Text(
                    "lbl_need_help".tr,
                    style: theme.textTheme.titleLarge,
                  ),
                  SizedBox(height: 40.h),
                  Text(
                    "msg_if_you_have_any2".tr,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: CustomTextStyles.titleSmallNunitoExtraBold15,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          NavigatorService.goBack();
        },
      ),
    );
  }
}
