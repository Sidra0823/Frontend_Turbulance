import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/my_account_two_model.dart';

part 'my_account_two_event.dart';
part 'my_account_two_state.dart';

/// A bloc that manages the state of MyAccountTwo according to the event that is dispatched.
class MyAccountTwoBloc extends Bloc<MyAccountTwoEvent, MyAccountTwoState> {
  MyAccountTwoBloc(MyAccountTwoState initialState) : super(initialState) {
    on<MyAccountTwoInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      MyAccountTwoInitialEvent event,
      Emitter<MyAccountTwoState> emit,
      ) async {
    // Add initialization logic here if required
    emit(state.copyWith());
  }
}
