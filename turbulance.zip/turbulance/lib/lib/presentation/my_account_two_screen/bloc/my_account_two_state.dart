part of 'my_account_two_bloc.dart';

/// Represents the state of MyAccountTwo in the application.
class MyAccountTwoState extends Equatable {
  MyAccountTwoState({this.myAccountTwoModelObj});

  final MyAccountTwoModel? myAccountTwoModelObj;

  @override
  List<Object?> get props => [myAccountTwoModelObj];

  MyAccountTwoState copyWith({MyAccountTwoModel? myAccountTwoModelObj}) {
    return MyAccountTwoState(
      myAccountTwoModelObj: myAccountTwoModelObj ?? this.myAccountTwoModelObj,
    );
  }
}
