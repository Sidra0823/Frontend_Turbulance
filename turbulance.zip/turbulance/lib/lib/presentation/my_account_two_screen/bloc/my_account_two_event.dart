part of 'my_account_two_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// MyAccountTwo widget.
class MyAccountTwoEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the MyAccountTwo widget is first created.
class MyAccountTwoInitialEvent extends MyAccountTwoEvent {
  @override
  List<Object?> get props => [];
}
