import 'package:equatable/equatable.dart';
import '../models/video_call_model.dart';

part 'video_call_event.dart';
part 'video_call_state.dart';

/// A bloc that manages the state of a VideoCall according to the event that is dispatched to it.
class VideoCallBloc extends Bloc<VideoCallEvent, VideoCallState> {
  VideoCallBloc(VideoCallState initialState) : super(initialState) {
    on<VideoCallInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      VideoCallInitialEvent event,
      Emitter<VideoCallState> emit,
      ) async {
    emit(state.copyWith(videoCallModelObj: VideoCallModel()));
    // Add any additional initialization logic here
  }
}
