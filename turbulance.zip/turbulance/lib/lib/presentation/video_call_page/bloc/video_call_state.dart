part of 'video_call_bloc.dart';

/// Represents the state of VideoCall in the application.
// ignore_for_file: must_be_immutable

class VideoCallState extends Equatable {
  VideoCallState({this.videoCallModelObj});

  final VideoCallModel? videoCallModelObj;

  @override
  List<Object?> get props => [videoCallModelObj];

  VideoCallState copyWith({VideoCallModel? videoCallModelObj}) {
    return VideoCallState(
      videoCallModelObj: videoCallModelObj ?? this.videoCallModelObj,
    );
  }
}
