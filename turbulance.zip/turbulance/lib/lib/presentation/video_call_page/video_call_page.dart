import 'package:flutter/material.dart';

import '../../widgets/custom_icon_button.dart';

import 'bloc/video_call_bloc.dart';
import 'models/video_call_model.dart'; // ignore_for_file: must_be_immutable

class VideoCallPage extends StatelessWidget {
  const VideoCallPage({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<VideoCallBloc>(
      create: (context) => VideoCallBloc(VideoCallState(videoCallModelObj: VideoCallModel()))
        ..add(VideoCallInitialEvent()),
      child: const VideoCallPage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<VideoCallBloc, VideoCallState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: theme.colorScheme.onPrimary,
          body: Container(
            width: double.maxFinite,
            height: SizeUtils.height,
            extendBody: true,
            extendBodyBehindAppBar: true,
            padding: EdgeInsets.symmetric(horizontal: 14.h),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [buildRowCloseOne(context)],
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget buildRowCloseOne(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(right: 8.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CustomIconButton(
            height: 40.h,
            width: 48.h,
            decoration: IconButtonStyleHelper.none,
            onTap: () {
              onTapBtnCloseOne(context);
            },
            child: CustomImageView(
              imagePath: ImageConstant.imgCloseOnPrimary,
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgImage21,
            height: 186.h,
            width: 102.h,
            radius: BorderRadius.circular(14.h),
            alignment: Alignment.center,
          ),
        ],
      ),
    );
  }

  /// Navigates to the previous screen.
  void onTapBtnCloseOne(BuildContext context) {
    NavigatorService.goBack();
  }
}
