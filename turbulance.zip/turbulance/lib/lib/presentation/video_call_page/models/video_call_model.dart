import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [video_call_page],
/// and is typically used to hold data that is passed between different parts of the application.

class VideoCallModel extends Equatable {
  VideoCallModel();

  // A copyWith method to allow creating a new instance with potentially updated fields.
  VideoCallModel copyWith() {
    return VideoCallModel();
  }

  @override
  List<Object?> get props => [];
}
