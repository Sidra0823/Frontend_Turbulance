import 'package:flutter/material.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_icon_button.dart';
import 'bloc/my_account_one_bloc.dart';
import 'models/my_account_one_model.dart';

class MyAccountOneScreen extends StatelessWidget {
  const MyAccountOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<MyAccountOneBloc>(
      create: (context) => MyAccountOneBloc(
        MyAccountOneState(myAccountOneModelObj: MyAccountOneModel()),
      )..add(MyAccountOneInitialEvent()),
      child: const MyAccountOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MyAccountOneBloc, MyAccountOneState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          appBar: buildAppbar(context),
          body: SafeArea(
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.only(top: 18.h),
              child: Column(
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconButton(
                        height: 44.h,
                        width: 44.h,
                        padding: EdgeInsets.all(2.h),
                        decoration: IconButtonStyleHelper.fillOnPrimary,
                        child: CustomImageView(imagePath: ImageConstant.imgUploadBlack900),
                      ),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: EdgeInsets.only(left: 14.h, bottom: 4.h),
                          child: Text(
                            "lbl_terms_to_use".tr,
                            style: theme.textTheme.headlineSmall,
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 58.h),
                  CustomImageView(
                    imagePath: ImageConstant.imgProfilePicture80x80,
                    height: 80.h,
                    width: 82.h,
                    radius: BorderRadius.circular(40.h),
                  ),
                  SizedBox(height: 18.h),
                  Text(
                    "lbl_turbulance".tr,
                    style: theme.textTheme.headlineLarge,
                  ),
                  SizedBox(height: 78.h),
                  GestureDetector(
                    onTap: () {
                      onTapTxtClickonthelink2(context);
                    },
                    child: RichText(
                      text: TextSpan(
                        children: [
                          TextSpan(
                            text: "msg_click_on_the_link".tr,
                            style: CustomTextStyles.bodyMediumNunito,
                          ),
                          TextSpan(
                            text: "\n",
                            style: CustomTextStyles.bodyMediumNunito.copyWith(
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          TextSpan(
                            text: "msg_https_turbula2".tr,
                            style: CustomTextStyles.bodyMediumNunito.copyWith(
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowLeftOne(context);
        },
      ),
    );
  }

  void onTapArrowLeftOne(BuildContext context) {
    NavigatorService.goBack();
  }

  void onTapTxtClickonthelink2(BuildContext context) {
    // Handle tap on the link (you can implement your logic here)
  }
}
