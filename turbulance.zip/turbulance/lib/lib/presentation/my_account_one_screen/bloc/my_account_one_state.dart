part of 'my_account_one_bloc.dart';

/// Represents the state of MyAccountOne in the application.
class MyAccountOneState extends Equatable {
  MyAccountOneState({this.myAccountOneModelObj});
  MyAccountOneModel? myAccountOneModelObj;

  @override
  List<Object?> get props => [myAccountOneModelObj];

  MyAccountOneState copyWith({MyAccountOneModel? myAccountOneModelObj}) {
    return MyAccountOneState(
      myAccountOneModelObj: myAccountOneModelObj ?? this.myAccountOneModelObj,
    );
  }
}
