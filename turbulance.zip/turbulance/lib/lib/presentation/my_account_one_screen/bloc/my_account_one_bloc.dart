import 'package:equatable/equatable.dart';
import '../models/my_account_one_model.dart';

part 'my_account_one_event.dart';
part 'my_account_one_state.dart';

/// A bloc that manages the state of a MyAccountOne according to the event that is dispatched to it.
class MyAccountOneBloc extends Bloc<MyAccountOneEvent, MyAccountOneState> {
  MyAccountOneBloc(MyAccountOneState initialState) : super(initialState) {
    on<MyAccountOneInitialEvent>(onInitialize);
  }

  Future<void> onInitialize(
      MyAccountOneInitialEvent event,
      Emitter<MyAccountOneState> emit,
      ) async {
    // Handle initialization
  }
}
