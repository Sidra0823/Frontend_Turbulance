part of 'my_account_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the MyAccountOne widget.
/// Events must be immutable and implement the [Equatable] interface.
class MyAccountOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the MyAccountOne widget is first created.
class MyAccountOneInitialEvent extends MyAccountOneEvent {
  @override
  List<Object?> get props => [];
}
