import 'package:flutter/material.dart';
import '../../../core/app_export.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../../../widgets/custom_drop_down.dart';
import 'bloc/iphone_14_15_pro_max_ninetynine_bloc.dart';
import 'models/iphone_14_15_pro_max_ninetynine_model.dart';

class Iphone1415ProMaxNinetynineScreen extends StatelessWidget {
  const Iphone1415ProMaxNinetynineScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxNinetynineBloc>(
      create: (context) => Iphone1415ProMaxNinetynineBloc(
        Iphone1415ProMaxNinetynineState(
          iphone1415ProMaxNinetynineModelObj: Iphone1415ProMaxNinetynineModel(),
        ),
      )..add(Iphone1415ProMaxNinetynineInitialEvent()),
      child: const Iphone1415ProMaxNinetynineScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.black900,
      body: SafeArea(
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(left: 20, top: 132, right: 20),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              // Screen content here
            ],
          ),
        ),
      ),
    );
  }
}
