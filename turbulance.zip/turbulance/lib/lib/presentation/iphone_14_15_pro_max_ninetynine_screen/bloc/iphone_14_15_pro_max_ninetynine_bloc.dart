import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/iphone_14_15_pro_max_ninetynine_model.dart';

part 'iphone_14_15_pro_max_ninetynine_event.dart';
part 'iphone_14_15_pro_max_ninetynine_state.dart';

/// A bloc that manages the state of an Iphone1415ProMaxNinetynine according to the event that is dispatched to it.
class Iphone1415ProMaxNinetynineBloc
    extends Bloc<Iphone1415ProMaxNinetynineEvent, Iphone1415ProMaxNinetynineState> {
  Iphone1415ProMaxNinetynineBloc(Iphone1415ProMaxNinetynineState initialState)
      : super(initialState) {
    on<Iphone1415ProMaxNinetynineInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      Iphone1415ProMaxNinetynineInitialEvent event,
      Emitter<Iphone1415ProMaxNinetynineState> emit,
      ) async {
    emit(state.copyWith(
      iphone1415ProMaxNinetynineModelObj: state.iphone1415ProMaxNinetynineModelObj?.copyWith(
        dropdownItemList: fillDropdownItemList(),
      ),
    ));
  }

  List<SelectionPopupModel> fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
