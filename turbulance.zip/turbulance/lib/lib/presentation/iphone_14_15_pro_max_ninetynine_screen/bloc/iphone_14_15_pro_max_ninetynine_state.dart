part of 'iphone_14_15_pro_max_ninetynine_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetynine in the application.
class Iphone1415ProMaxNinetynineState extends Equatable {
  final SelectionPopupModel? selectedDropDownValue;
  final Iphone1415ProMaxNinetynineModel? iphone1415ProMaxNinetynineModelObj;

  Iphone1415ProMaxNinetynineState({
    this.selectedDropDownValue,
    this.iphone1415ProMaxNinetynineModelObj,
  });

  @override
  List<Object?> get props => [selectedDropDownValue, iphone1415ProMaxNinetynineModelObj];

  Iphone1415ProMaxNinetynineState copyWith({
    SelectionPopupModel? selectedDropDownValue,
    Iphone1415ProMaxNinetynineModel? iphone1415ProMaxNinetynineModelObj,
  }) {
    return Iphone1415ProMaxNinetynineState(
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      iphone1415ProMaxNinetynineModelObj:
      iphone1415ProMaxNinetynineModelObj ?? this.iphone1415ProMaxNinetynineModelObj,
    );
  }
}
