part of 'iphone_14_15_pro_max_121_bloc.dart';

/// Represents the state of Iphone1415ProMax121 in the application.

// ignore_for_file: must_be_immutable
class Iphone1415ProMax121State extends Equatable {
  Iphone1415ProMax121State({this.iphone1415ProMax121ModelObj});

  final Iphone1415ProMax121Model? iphone1415ProMax121ModelObj;

  @override
  List<Object?> get props => [iphone1415ProMax121ModelObj];

  Iphone1415ProMax121State copyWith({
    Iphone1415ProMax121Model? iphone1415ProMax121ModelObj,
  }) {
    return Iphone1415ProMax121State(
      iphone1415ProMax121ModelObj:
      iphone1415ProMax121ModelObj ?? this.iphone1415ProMax121ModelObj,
    );
  }
}
