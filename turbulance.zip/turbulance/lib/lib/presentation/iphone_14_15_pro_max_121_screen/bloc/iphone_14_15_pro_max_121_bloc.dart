import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/iphone_14_15_pro_max_121_model.dart';

part 'iphone_14_15_pro_max_121_event.dart';
part 'iphone_14_15_pro_max_121_state.dart';

/// A Bloc that manages the state of an Iphone1415ProMax121 according to the event that is dispatched to it.
class Iphone1415ProMax121Bloc
    extends Bloc<Iphone1415ProMax121Event, Iphone1415ProMax121State> {
  Iphone1415ProMax121Bloc(Iphone1415ProMax121State initialState)
      : super(initialState) {
    on<Iphone1415ProMax121InitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      Iphone1415ProMax121InitialEvent event,
      Emitter<Iphone1415ProMax121State> emit,
      ) async {
    // Add your initialization logic here.
  }
}
