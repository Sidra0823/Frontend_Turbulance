part of 'iphone_14_15_pro_max_121_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// Iphone1415ProMax121 widget.
///
/// Events must be immutable and implement the [Equatable] interface.
abstract class Iphone1415ProMax121Event extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Iphone1415ProMax121 widget is first created.
class Iphone1415ProMax121InitialEvent extends Iphone1415ProMax121Event {
  @override
  List<Object?> get props => [];
}
