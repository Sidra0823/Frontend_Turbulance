import 'package:flutter/material.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_subtitle_seven.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/iphone_14_15_pro_max_121_bloc.dart';
import 'models/iphone_14_15_pro_max_121_model.dart';

class Iphone1415ProMax121Screen extends StatelessWidget {
  const Iphone1415ProMax121Screen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMax121Bloc>(
      create: (context) => Iphone1415ProMax121Bloc(
        Iphone1415ProMax121State(
          iphone1415ProMax121ModelObj: Iphone1415ProMax121Model(),
        ),
      )..add(Iphone1415ProMax121InitialEvent()),
      child: const Iphone1415ProMax121Screen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<Iphone1415ProMax121Bloc, Iphone1415ProMax121State>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          appBar: buildAppbar(context),
          body: SafeArea(
            top: false,
            child: Container(
              height: 832.h,
              padding: EdgeInsets.only(top: 20.h),
              width: double.maxFinite,
              child: Stack(
                alignment: Alignment.topCenter,
                children: [
                  Opacity(
                    opacity: 0.15,
                    child: CustomImageView(
                      imagePath: ImageConstant.imgImg7223Jpeg1692x430,
                      height: 692.h,
                      width: double.maxFinite,
                    ),
                  ),
                  _buildColumnBasilone(context),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// App bar widget
  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 54.h,
      actions: [
        AppbarSubtitleSeven(
          text: "lbl_skip".tr,
          margin: EdgeInsets.only(right: 22.h),
        ),
      ],
    );
  }

  /// Column content widget
  Widget _buildColumnBasilone(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(top: 134.h),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgBasilNotificationOnSolid,
            height: 100.h,
            width: 102.h,
          ),
          SizedBox(height: 36.h),
          Text(
            "msg_enable_notification_s".tr,
            style: CustomTextStyles.headlineSmallSkModernist,
          ),
          SizedBox(height: 12.h),
          SizedBox(
            width: 290.h,
            child: Text(
              "msg_get_push_notification".tr,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              style: CustomTextStyles.bodyMediumSkModernistOnPrimary.copyWith(
                height: 1.50,
              ),
            ),
          ),
          SizedBox(height: 36.h),
          CustomElevatedButton(
            height: 46.h,
            width: 176.h,
            text: "msg_allow_notification".tr,
            buttonStyle: CustomButtonStyles.fillPrimaryTL20,
            buttonTextStyle: CustomTextStyles.labelLargeMulishBlack900,
          ),
        ],
      ),
    );
  }
}
