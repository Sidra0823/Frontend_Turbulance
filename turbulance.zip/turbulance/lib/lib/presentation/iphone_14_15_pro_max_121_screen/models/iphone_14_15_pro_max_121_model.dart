import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_121_screen],
/// and is typically used to hold data that is passed between different parts of the application.

class Iphone1415ProMax121Model extends Equatable {
  Iphone1415ProMax121Model();

  Iphone1415ProMax121Model copyWith() {
    return Iphone1415ProMax121Model();
  }

  @override
  List<Object?> get props => [];
}
