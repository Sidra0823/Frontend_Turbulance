part of 'comment_bloc.dart';

/// Represents the state of the Comment in the application.
class CommentState extends Equatable {
  final TextEditingController? pinViewController;
  final CommentModel? commentModelObj;

  CommentState({this.pinViewController, this.commentModelObj});

  @override
  List<Object?> get props => [pinViewController, commentModelObj];

  CommentState copyWith({
    TextEditingController? pinViewController,
    CommentModel? commentModelObj,
  }) {
    return CommentState(
      pinViewController: pinViewController ?? this.pinViewController,
      commentModelObj: commentModelObj ?? this.commentModelObj,
    );
  }
}
