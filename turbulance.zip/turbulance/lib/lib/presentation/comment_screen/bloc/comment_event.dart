import 'package:flutter/material.dart';
import '../models/comment_one_item_model.dart';

part 'comment_event.dart';
part 'comment_state.dart';

/// A bloc that manages the state of a Comment according to the event that is dispatched to it.
class CommentBloc extends Bloc<CommentEvent, CommentState> {
  CommentBloc(CommentState initialState) : super(initialState) {
    on<CommentInitialEvent>(_onInitialize);
  }

  _onInitialize(CommentInitialEvent event, Emitter<CommentState> emit) async {
    emit(state.copyWith(pinViewController: TextEditingController()));

    emit(state.copyWith(
      commentModelObj: state.commentModelObj?.copyWith(
        commentOneItemList: _fillCommentOneItemList(),
      ),
    ));
  }

  List<CommentOneItemModel> _fillCommentOneItemList() {
    return [
      CommentOneItemModel(
        selenaOne: ImageConstant.imgDownload4730x30,
        selenaTwo: "Selena",
        time: "20min ago",
        awesomeEdward: "Awesome Edward, remember those five tips for",
        timezone: "low cost holidays I sent you?",
        reply: "Reply",
      ),
      CommentOneItemModel(
        selenaOne: ImageConstant.imgDownload5030x30,
        selenaTwo: "Ciara",
        time: "20min ago",
        awesomeEdward: "Awesome Edward, remember those five tips for",
        timezone: "low cost holidays I sent you?",
        reply: "Reply",
      ),
      // Add more CommentOneItemModel objects as needed...
    ];
  }
}
