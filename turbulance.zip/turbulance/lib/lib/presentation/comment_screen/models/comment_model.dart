import 'package:equatable/equatable.dart';
import 'comment_one_item_model.dart';

class CommentModel extends Equatable {
  final List<CommentOneItemModel> commentOneItemList;

  CommentModel({this.commentOneItemList = const []});

  @override
  List<Object?> get props => [commentOneItemList];

  CommentModel copyWith({
    List<CommentOneItemModel>? commentOneItemList,
  }) {
    return CommentModel(
      commentOneItemList: commentOneItemList ?? this.commentOneItemList,
    );
  }
}
