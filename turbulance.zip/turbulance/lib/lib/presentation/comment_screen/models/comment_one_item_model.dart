import 'package:equatable/equatable.dart';

class CommentOneItemModel extends Equatable {
  final String? selenaOne;
  final String? selenaTwo;
  final String? time;
  final String? awesomeEdward;
  final String? timezone;
  final String? reply;
  final String? id;

  CommentOneItemModel({
    this.selenaOne,
    this.selenaTwo,
    this.time,
    this.awesomeEdward,
    this.timezone,
    this.reply,
    this.id,
  });

  @override
  List<Object?> get props => [selenaOne, selenaTwo, time, awesomeEdward, timezone, reply, id];

  CommentOneItemModel copyWith({
    String? selenaOne,
    String? selenaTwo,
    String? time,
    String? awesomeEdward,
    String? timezone,
    String? reply,
    String? id,
  }) {
    return CommentOneItemModel(
      selenaOne: selenaOne ?? this.selenaOne,
      selenaTwo: selenaTwo ?? this.selenaTwo,
      time: time ?? this.time,
      awesomeEdward: awesomeEdward ?? this.awesomeEdward,
      timezone: timezone ?? this.timezone,
      reply: reply ?? this.reply,
      id: id ?? this.id,
    );
  }
}
