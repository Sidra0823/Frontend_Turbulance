import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import '../models/comment_one_item_model.dart';

class CommentOneItemWidget extends StatelessWidget {
  final CommentOneItemModel commentOneItemModelObj;

  CommentOneItemWidget(this.commentOneItemModelObj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: EdgeInsets.only(right: 8),
      child: Column(
        children: [
          SizedBox(
            width: double.infinity,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomImageView(
                  imagePath: commentOneItemModelObj.selenaOne!,
                  height: 30,
                  width: 30,
                  radius: BorderRadius.circular(10),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 10),
                  child: Text(
                    commentOneItemModelObj.selenaTwo!,
                    style: CustomTextStyles.titleMediumBold,
                  ),
                ),
                Expanded(
                  child: PinCodeTextField(
                    appContext: context,
                    controller: pinViewController,
                    length: 1,
                    obscureText: true,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    pinTheme: PinTheme(
                      fieldHeight: 12,
                      fieldWidth: 8,
                      shape: PinCodeFieldShape.circle,
                      selectedFillColor: appTheme.gray50001,
                    ),
                    onChanged: (value) {
                      pinViewController?.text = value;
                    },
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 6),
            child: Text(
              commentOneItemModelObj.time!,
              style: theme.textTheme.labelLarge,
            ),
          ),
        ],
      ),
    );
  }
}
