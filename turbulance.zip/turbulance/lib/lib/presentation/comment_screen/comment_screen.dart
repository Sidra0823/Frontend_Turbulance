import 'package:flutter/material.dart';
import 'bloc/comment_bloc.dart';
import 'models/comment_model.dart';
import 'widgets/comment_one_item_widget.dart';
import 'models/comment_one_item_model.dart';

class CommentScreen extends StatelessWidget {
  const CommentScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<CommentBloc>(
      create: (context) => CommentBloc(CommentState(commentModelObj: CommentModel()))
        ..add(CommentInitialEvent()),
      child: CommentScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: buildAppbar(context),
      body: SafeArea(
        child: Container(
          width: double.infinity,
          padding: EdgeInsets.symmetric(horizontal: 28, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "lbl_comments_398k".tr,
                style: theme.textTheme.titleLarge,
              ),
              SizedBox(height: 20),
              _buildCommentList(context),
              SizedBox(height: 52),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCommentList(BuildContext context) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.only(right: 10),
        child: BlocSelector<CommentBloc, CommentState, CommentModel?>(
          selector: (state) => state.commentModelObj,
          builder: (context, commentModelObj) {
            return ListView.separated(
              padding: EdgeInsets.zero,
              physics: BouncingScrollPhysics(),
              shrinkWrap: true,
              separatorBuilder: (context, index) => SizedBox(height: 50),
              itemCount: commentModelObj?.commentOneItemList.length ?? 0,
              itemBuilder: (context, index) {
                CommentOneItemModel model =
                    commentModelObj?.commentOneItemList[index] ??
                        CommentOneItemModel();
                return CommentOneItemWidget(model);
              },
            );
          },
        ),
      ),
    );
  }
}
