part of 'iphone_14_15_pro_max_101_bloc.dart';

/// Represents the state of Iphone1415ProMax101 in the application.
// ignore_for_file: must_be_immutable
class Iphone1415ProMax101State extends Equatable {
  Iphone1415ProMax101State({
    this.selectedDropDownValue,
    this.iphone1415ProMax101ModelObj,
  });

  final SelectionPopupModel? selectedDropDownValue;
  final Iphone1415ProMax101Model? iphone1415ProMax101ModelObj;

  @override
  List<Object?> get props => [selectedDropDownValue, iphone1415ProMax101ModelObj];

  Iphone1415ProMax101State copyWith({
    SelectionPopupModel? selectedDropDownValue,
    Iphone1415ProMax101Model? iphone1415ProMax101ModelObj,
  }) {
    return Iphone1415ProMax101State(
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      iphone1415ProMax101ModelObj: iphone1415ProMax101ModelObj ?? this.iphone1415ProMax101ModelObj,
    );
  }
}
