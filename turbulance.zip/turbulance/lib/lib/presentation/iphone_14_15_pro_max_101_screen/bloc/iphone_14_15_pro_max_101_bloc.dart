import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/iphone_14_15_pro_max_101_model.dart';

part 'iphone_14_15_pro_max_101_event.dart';
part 'iphone_14_15_pro_max_101_state.dart';

/// A bloc that manages the state of an Iphone1415ProMax101 according to the event that is dispatched to it.
class Iphone1415ProMax101Bloc extends Bloc<Iphone1415ProMax101Event, Iphone1415ProMax101State> {
  Iphone1415ProMax101Bloc(Iphone1415ProMax101State initialState) : super(initialState) {
    on<Iphone1415ProMax101InitialEvent>(_onInitialize);
  }

  void _onInitialize(
      Iphone1415ProMax101InitialEvent event,
      Emitter<Iphone1415ProMax101State> emit,
      ) async {
    emit(state.copyWith(
      iphone1415ProMax101ModelObj: state.iphone1415ProMax101ModelObj?.copyWith(
        dropdownItemList: _fillDropdownItemList(),
      ),
    ));
  }

  List<SelectionPopupModel> _fillDropdownItemList() {
    return [
      SelectionPopupModel(
        id: 1,
        title: "Item One",
        isSelected: true,
      ),
      SelectionPopupModel(
        id: 2,
        title: "Item Two",
      ),
      SelectionPopupModel(
        id: 3,
        title: "Item Three",
      ),
    ];
  }
}
