import 'package:flutter/material.dart';
import '../../widgets/custom_drop_down.dart';
import 'bloc/iphone_14_15_pro_max_101_bloc.dart';
import 'models/iphone_14_15_pro_max_101_model.dart';

class Iphone1415ProMax101Screen extends StatelessWidget {
  const Iphone1415ProMax101Screen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMax101Bloc>(
      create: (context) => Iphone1415ProMax101Bloc(
        Iphone1415ProMax101State(
          iphone1415ProMax101ModelObj: Iphone1415ProMax101Model(),
        ),
      )..add(Iphone1415ProMax101InitialEvent()),
      child: const Iphone1415ProMax101Screen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.only(
            left: 30.h,
            top: 126.h,
            right: 30.h,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Container(
                width: double.infinity,
                margin: EdgeInsets.only(left: 10.h),
                padding: EdgeInsets.only(top: 12.h),
                decoration: AppDecoration.outlineGray30001.copyWith(
                  borderRadius: BorderRadiusStyle.roundedBorder8,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.symmetric(horizontal: 16.h),
                      child: Row(
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgGoogle,
                            height: 12.h,
                            width: 12.h,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 12.h),
                            child: Text(
                              "msg_sign_in_with_google".tr,
                              style: CustomTextStyles.titleMediumRobotoSemiBold16,
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 14.h),
                    SizedBox(
                      width: double.infinity,
                      child: Divider(
                        color: appTheme.gray30001,
                      ),
                    ),
                    SizedBox(height: 36.h),
                    CustomImageView(
                      imagePath: ImageConstant.imgContrastPrimaryContainer,
                      height: 36.h,
                      width: 38.h,
                    ),
                    SizedBox(height: 14.h),
                    SizedBox(
                      width: double.infinity,
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "msg_confirm_you_want3".tr,
                              style: CustomTextStyles.headlineSmallRoboto,
                            ),
                            TextSpan(
                              text: "msg_company_as_firstname".tr,
                              style: CustomTextStyles.headlineSmallRobotoBlue600,
                            ),
                          ],
                        ),
                        textAlign: TextAlign.center,
                        maxLines: 3,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgProfilePicture16x16,
                          height: 16.h,
                          width: 16.h,
                        ),
                        SizedBox(width: 8.h),
                        Text(
                          "lbl_email_gmail_com".tr,
                          style: CustomTextStyles.bodyMediumRoboto,
                        ),
                      ],
                    ),
                    SizedBox(height: 28.h),
                    SizedBox(
                      width: 276.h,
                      child: RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "msg_to_create_your_account".tr,
                              style: CustomTextStyles.bodyLargeRoboto_3,
                            ),
                            TextSpan(
                              text: "lbl_privacy_policy".tr,
                              style: CustomTextStyles.bodyLargeRobotoBlue600,
                            ),
                            TextSpan(
                              text: "lbl_and".tr,
                              style: CustomTextStyles.bodyLargeRoboto_3,
                            ),
                            TextSpan(
                              text: "msg_terms_of_service".tr,
                              style: CustomTextStyles.bodyLargeRobotoBlue600,
                            ),
                          ],
                        ),
                        textAlign: TextAlign.left,
                        maxLines: 5,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    SizedBox(height: 24.h),
                    Container(
                      width: double.infinity,
                      margin: EdgeInsets.symmetric(horizontal: 56.h),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "lbl_cancel".tr,
                            style: CustomTextStyles.bodyMediumRobotoBlue600,
                          ),
                          Text(
                            "lbl_confirm".tr,
                            style: CustomTextStyles.bodyMediumRobotoBlue600,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(height: 50.h),
                  ],
                ),
              ),
              SizedBox(height: 24.h),
              Container(
                width: double.infinity,
                margin: EdgeInsets.only(
                  left: 26.h,
                  right: 16.h,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    BlocSelector<Iphone1415ProMax101Bloc, Iphone1415ProMax101State,
                        Iphone1415ProMax101Model?>(
                      selector: (state) => state.iphone1415ProMax101ModelObj,
                      builder: (context, iphone1415ProMax101ModelObj) {
                        return CustomDropDown(
                          width: 56.h,
                          hintText: "lbl_english".tr,
                          hintStyle:
                          CustomTextStyles.bodySmallRobotoOnPrimary12_1,
                          items: iphone1415ProMax101ModelObj?.dropdownItemList ??
                              [],
                          contentPadding: EdgeInsets.all(12.h),
                        );
                      },
                    ),
                    const Spacer(flex: 62),
                    Text(
                      "lbl_help".tr,
                      style: CustomTextStyles.labelLargeRobotoOnPrimary,
                    ),
                    const Spacer(flex: 18),
                    Text(
                      "lbl_privacy".tr,
                      style: CustomTextStyles.labelLargeRobotoOnPrimary,
                    ),
                    const Spacer(flex: 18),
                    Text(
                      "lbl_terms".tr,
                      style: CustomTextStyles.labelLargeRobotoOnPrimary,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
