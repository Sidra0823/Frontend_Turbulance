import 'package:equatable/equatable.dart';
import 'griddownload_item_model.dart';

class ScrollviewOneTab1Model extends Equatable {
  final List<GriddownloadItemModel> griddownloadItemList;

  ScrollviewOneTab1Model({this.griddownloadItemList = const []});

  ScrollviewOneTab1Model copyWith({
    List<GriddownloadItemModel>? griddownloadItemList,
  }) {
    return ScrollviewOneTab1Model(
      griddownloadItemList: griddownloadItemList ?? this.griddownloadItemList,
    );
  }

  @override
  List<Object?> get props => [griddownloadItemList];
}
