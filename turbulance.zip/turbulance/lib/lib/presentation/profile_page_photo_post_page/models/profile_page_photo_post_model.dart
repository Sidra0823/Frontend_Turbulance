import 'package:equatable/equatable.dart';

class ProfilePagePhotoPostOneModel extends Equatable {
  ProfilePagePhotoPostOneModel();

  ProfilePagePhotoPostOneModel copyWith() {
    return ProfilePagePhotoPostOneModel();
  }

  @override
  List<Object?> get props => [];
}
