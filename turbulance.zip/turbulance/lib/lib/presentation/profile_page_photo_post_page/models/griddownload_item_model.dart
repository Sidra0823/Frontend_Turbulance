import 'package:equatable/equatable.dart';

class GriddownloadItemModel extends Equatable {
  final String? download;
  final String? id;

  GriddownloadItemModel({this.download, this.id});

  GriddownloadItemModel copyWith({String? download, String? id}) {
    return GriddownloadItemModel(
      download: download ?? this.download,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [download, id];
}
