part of 'profile_page_photo_post_one_bloc.dart';

/// Represents the state of ProfilePagePhotoPostOne in the application.
class ProfilePagePhotoPostOneState extends Equatable {
  final ProfilePagePhotoPostOneModel? profilePagePhotoPostOneModelObj;
  final ScrollviewOneTab1Model? scrollviewOneTab1ModelObj;

  ProfilePagePhotoPostOneState({
    this.profilePagePhotoPostOneModelObj,
    this.scrollviewOneTab1ModelObj,
  });

  @override
  List<Object?> get props => [profilePagePhotoPostOneModelObj, scrollviewOneTab1ModelObj];

  ProfilePagePhotoPostOneState copyWith({
    ProfilePagePhotoPostOneModel? profilePagePhotoPostOneModelObj,
    ScrollviewOneTab1Model? scrollviewOneTab1ModelObj,
  }) {
    return ProfilePagePhotoPostOneState(
      profilePagePhotoPostOneModelObj:
      profilePagePhotoPostOneModelObj ?? this.profilePagePhotoPostOneModelObj,
      scrollviewOneTab1ModelObj:
      scrollviewOneTab1ModelObj ?? this.scrollviewOneTab1ModelObj,
    );
  }
}
