import 'package:flutter/material.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/profile_page_photo_post_one_bloc.dart';
import 'models/profile_page_photo_post_one_model.dart';
import 'scrollview_one_tab1_page.dart';

class ProfilePagePhotoPostOneScreen extends StatefulWidget {
  const ProfilePagePhotoPostOneScreen({Key? key}) : super(key: key);

  @override
  ProfilePagePhotoPostOneScreenState createState() =>
      ProfilePagePhotoPostOneScreenState();

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => ProfilePagePhotoPostOneBloc(
        ProfilePagePhotoPostOneState(
          profilePagePhotoPostOneModelObj: ProfilePagePhotoPostOneModel(),
        ),
      )..add(ProfilePagePhotoPostOneInitialEvent()),
      child: ProfilePagePhotoPostOneScreen(),
    );
  }
}

class ProfilePagePhotoPostOneScreenState
    extends State<ProfilePagePhotoPostOneScreen> with TickerProviderStateMixin {
  late TabController tabviewController;
  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: SizedBox(
          width: double.maxFinite,
          child: NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) {
              return [
                SliverToBoxAdapter(
                  child: Column(
                    children: [_buildColumnArrowLeft(context)],
                  ),
                ),
              ];
            },
            body: _buildTabBarView(context),
            bottomNavigationBar: SizedBox(
              width: double.maxFinite,
              child: _buildBottomBar(context),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildColumnArrowLeft(BuildContext context) {
    return Column(
      children: [
        CustomAppBar(
          leadingWidth: 70.h,
          leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.only(left: 30.h),
            onTap: () => onTapArrowLeft(context),
          ),
          actions: [
            AppbarTrailingIconButton(
              imagePath: ImageConstant.imgCloseOnPrimary,
              margin: EdgeInsets.only(right: 29.h),
            ),
          ],
        ),
        CustomImageView(
          imagePath: ImageConstant.imgProfilePicture80x80,
          height: 80.h,
          width: 82.h,
          radius: BorderRadius.circular(40.h),
        ),
        SizedBox(height: 8.h),
        Text(
          "lbl_turbulance".tr,
          style: CustomTextStyles.titleLarge22,
        ),
        Text(
          "lbl_turbulance3".tr,
          style: CustomTextStyles.bodyLargeGray5000118,
        ),
        SizedBox(height: 12.h),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("lbl_518".tr, style: theme.textTheme.titleMedium),
            Padding(
              padding: EdgeInsets.only(left: 12.h),
              child: Text("lbl_posts".tr, style: CustomTextStyles.titleMediumGray50061),
            ),
            Padding(
              padding: EdgeInsets.only(left: 28.h),
              child: Text("lbl_22k".tr, style: theme.textTheme.titleMedium),
            ),
            Padding(
              padding: EdgeInsets.only(left: 10.h),
              child: Text("lbl_friends".tr, style: CustomTextStyles.titleMediumGray50001),
            ),
          ],
        ),
        SizedBox(height: 18.h),
        Container(
          width: double.maxFinite,
          child: Row(
            children: [
              Expanded(
                height: 56.h,
                margin: EdgeInsets.symmetric(horizontal: 60.h),
                child: CustomElevatedButton(
                  leftIcon: Container(
                    margin: EdgeInsets.only(right: 8.h),
                    child: CustomImageView(),
                  ),
                  text: "lbl_friends".tr,
                  imagePath: ImageConstant.imgCheckmarkOnPrimary,
                  height: 12.h,
                  width: 16.h,
                  fit: BoxFit.contain,
                  buttonStyle: CustomButtonStyles.fillPrimary,
                  buttonTextStyle: CustomTextStyles.titleMediumSemiBold,
                ),
              ),
              SizedBox(width: 26.h),
              Expanded(
                child: CustomElevatedButton(
                  height: 56.h,
                  text: "lbl_message".tr,
                  leftIcon: Container(),
                  margin: EdgeInsets.only(right: 6.h),
                  child: CustomImageView(),
                  imagePath: ImageConstant.imgUserBlack900,
                  height: 26.h,
                  width: 26.h,
                  fit: BoxFit.contain,
                  buttonStyle: CustomButtonStyles.fillGray,
                  buttonTextStyle: CustomTextStyles.titleMediumBlack900,
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 22.h),
        SizedBox(
          width: 52.h,
          child: Divider(color: appTheme.gray50001),
        ),
        SizedBox(height: 22.h),
        Container(
          margin: EdgeInsets.symmetric(horizontal: 78.h),
          width: double.maxFinite,
          child: TabBar(
            controller: tabviewController,
            labelPadding: EdgeInsets.zero,
            labelColor: appTheme.gray50001,
            labelStyle: TextStyle(fontSize: 18.fSize, fontFamily: 'Nunito', fontWeight: FontWeight.w800),
            unselectedLabelColor: theme.colorScheme.onPrimary,
            unselectedLabelStyle: TextStyle(fontSize: 18.fSize, fontFamily: 'Nunito', fontWeight: FontWeight.w880),
            indicatorColor: appTheme.gray50001,
            tabs: [
              Tab(child: Text("lbl_photos".tr)),
              Tab(child: Text("lbl_videos".tr)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTabBarView(BuildContext context) {
    return SizedBox(
      height: 424.h,
      child: TabBarView(
        controller: tabviewController,
        children: [
          ScrollviewOneTab1Page.builder(context),
          ScrollviewOneTab1Page.builder(context),
        ],
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: CustomBottomBar(
        onChanged: (BottomBarEnum type) {
          Navigator.pushNamed(navigatorKey.currentContext!, getCurrentRoute(type));
        },
      ),
    );
  }

  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.postSomethingInitialPage;
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Close:
        return AppRoutes.videoCallPage;
      case BottomBarEnum.UserOnPrimary:
        return "/";
      case BottomBarEnum.LockOnPrimary:
        return AppRoutes.profilePagePhotoPostPage;
      default:
        return "/";
    }
  }

  void onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
