part of 'likes_bloc.dart';

/// Abstract class for all events that can be dispatched from the Likes widget.
abstract class LikesEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Likes widget is first created.
class LikesInitialEvent extends LikesEvent {}
