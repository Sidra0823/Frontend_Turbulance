import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../models/likes_model.dart';
import '../models/likes_one_item_model.dart';

part 'likes_event.dart';
part 'likes_state.dart';

/// A bloc that manages the state of a Likes according to the event that is dispatched to it.
class LikesBloc extends Bloc<LikesEvent, LikesState> {
  LikesBloc(LikesState initialState) : super(initialState) {
    on<LikesInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      LikesInitialEvent event,
      Emitter<LikesState> emit,
      ) async {
    emit(
      state.copyWith(
        pinViewController: TextEditingController(),
        likesModelObj: state.likesModelObj?.copyWith(
          likesOneItemList: _fillLikesOneItemList(),
        ),
      ),
    );
  }

  List<LikesOneItemModel> _fillLikesOneItemList() {
    return [
      LikesOneItemModel(
        turbulanceOne: ImageConstant.imgDownload471,
        turbulanceTwo: "Turbulance",
        likedYourPost: "Liked your post",
        turbulanceFour: ImageConstant.imgDownload501,
      ),
      LikesOneItemModel(
        turbulanceOne: ImageConstant.imgDownload5030x30,
        likedYourPost: "Liked your post",
        turbulanceFour: ImageConstant.imgDownload501,
      ),
      LikesOneItemModel(
        turbulanceOne: ImageConstant.imgDownload5030x30,
        likedYourPost: "Liked your video",
        turbulanceFour: ImageConstant.imgDownload6230x30,
      ),
    ];
  }
}
