part of 'likes_bloc.dart';

/// Represents the state of Likes in the application.
class LikesState extends Equatable {
  LikesState({
    this.pinViewController,
    this.likesModelObj,
  });

  TextEditingController? pinViewController;
  LikesModel? likesModelObj;

  @override
  List<Object?> get props => [pinViewController, likesModelObj];

  LikesState copyWith({
    TextEditingController? pinViewController,
    LikesModel? likesModelObj,
  }) {
    return LikesState(
      pinViewController: pinViewController ?? this.pinViewController,
      likesModelObj: likesModelObj ?? this.likesModelObj,
    );
  }
}
