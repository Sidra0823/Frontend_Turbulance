import 'package:flutter/material.dart';

import '../models/likes_one_item_model.dart';

/// Represents a single item in the Likes screen.
class LikesOneItemWidget extends StatelessWidget {
  LikesOneItemWidget(this.likesOneItemModelObj, {Key? key}) : super(key: key);

  final LikesOneItemModel likesOneItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomImageView(
          imagePath: likesOneItemModelObj.turbulanceOne!,
          height: 30,
          width: 30,
          radius: BorderRadius.circular(10),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              likesOneItemModelObj.turbulanceTwo!,
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(likesOneItemModelObj.likedYourPost!),
          ],
        ),
      ],
    );
  }
}
