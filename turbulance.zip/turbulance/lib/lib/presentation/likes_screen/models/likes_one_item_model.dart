import 'package:equatable/equatable.dart';


/// This class is used in the LikesOneItemWidget.
class LikesOneItemModel extends Equatable {
  LikesOneItemModel({
    this.turbulanceOne,
    this.turbulanceTwo,
    this.likedYourPost,
    this.turbulanceFour,
    this.id,
  });

  String? turbulanceOne;
  String? turbulanceTwo;
  String? likedYourPost;
  String? turbulanceFour;
  String? id;

  LikesOneItemModel copyWith({
    String? turbulanceOne,
    String? turbulanceTwo,
    String? likedYourPost,
    String? turbulanceFour,
    String? id,
  }) {
    return LikesOneItemModel(
      turbulanceOne: turbulanceOne ?? this.turbulanceOne,
      turbulanceTwo: turbulanceTwo ?? this.turbulanceTwo,
      likedYourPost: likedYourPost ?? this.likedYourPost,
      turbulanceFour: turbulanceFour ?? this.turbulanceFour,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props =>
      [turbulanceOne, turbulanceTwo, likedYourPost, turbulanceFour, id];
}
