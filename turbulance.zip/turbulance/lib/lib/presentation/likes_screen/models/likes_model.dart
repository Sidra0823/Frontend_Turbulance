import 'package:equatable/equatable.dart';

import '../models/likes_one_item_model.dart';

/// This class defines the variables used in the Likes screen.
class LikesModel extends Equatable {
  LikesModel({
    this.likesOneItemList = const [],
  });

  List<LikesOneItemModel> likesOneItemList;

  LikesModel copyWith({List<LikesOneItemModel>? likesOneItemList}) {
    return LikesModel(
      likesOneItemList: likesOneItemList ?? this.likesOneItemList,
    );
  }

  @override
  List<Object?> get props => [likesOneItemList];
}
