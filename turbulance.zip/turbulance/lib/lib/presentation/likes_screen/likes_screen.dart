import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/app_export.dart';
import 'bloc/likes_bloc.dart';
import 'models/likes_model.dart';
import 'widgets/likes_one_item_widget.dart';

class LikesScreen extends StatelessWidget {
  const LikesScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => LikesBloc(LikesState(likesModelObj: LikesModel()))
        ..add(LikesInitialEvent()),
      child: const LikesScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: BlocBuilder<LikesBloc, LikesState>(
        builder: (context, state) {
          return ListView.builder(
            itemCount: state.likesModelObj?.likesOneItemList.length ?? 0,
            itemBuilder: (context, index) {
              final model = state.likesModelObj?.likesOneItemList[index];
              return LikesOneItemWidget(model!);
            },
          );
        },
      ),
    );
  }

  AppBar _buildAppBar(BuildContext context) {
    return AppBar(
      title: const Text("Likes"),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => Navigator.pop(context),
      ),
    );
  }
}
