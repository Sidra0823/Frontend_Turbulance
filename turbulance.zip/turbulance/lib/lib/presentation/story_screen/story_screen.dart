import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:your_app_name/your_bloc_folder/story_bloc.dart'; // Replace with actual import
import 'package:your_app_name/your_models_folder/story_model.dart'; // Replace with actual import

class StoryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => StoryBloc(StoryState()),
      child: Scaffold(
        appBar: AppBar(
          title: Text('Story Screen'),
        ),
        body: BlocBuilder<StoryBloc, StoryState>(
          builder: (context, state) {
            return Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // Story content display (For demonstration purposes)
                  state.storyModelObj != null
                      ? Text('Story Content: ${state.storyModelObj}')
                      : Text('No Story Loaded'),

                  // Comment text field
                  TextField(
                    controller: state.commentController,
                    decoration: InputDecoration(
                      labelText: 'Add a comment...',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 16),

                  // Button to dispatch initialization event
                  ElevatedButton(
                    onPressed: () {
                      // Dispatching the StoryInitialEvent to initialize the bloc
                      context.read<StoryBloc>().add(StoryInitialEvent());
                    },
                    child: Text('Initialize Story'),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}