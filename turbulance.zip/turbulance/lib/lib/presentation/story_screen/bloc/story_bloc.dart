import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/story_model.dart';

part 'story_event.dart';
part 'story_state.dart';

/// A bloc that manages the state of a Story according to the event that is dispatched to it.
class StoryBloc extends Bloc<StoryEvent, StoryState> {
  StoryBloc(StoryState initialState) : super(initialState) {
    on<StoryInitialEvent>(_onInitialize);
  }

  /// Handles the initialization event for Story
  Future<void> _onInitialize(
      StoryInitialEvent event,
      Emitter<StoryState> emit,
      ) async {
    // Simulating some initialization or data loading process
    // For example, you can initialize controllers, fetch data, etc.

    emit(state.copyWith(
      commentController: TextEditingController(),
    ));
  }
}
