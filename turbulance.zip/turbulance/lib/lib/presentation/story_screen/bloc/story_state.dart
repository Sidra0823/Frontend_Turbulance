part of 'story_bloc.dart';

/// Represents the state of Story in the application.

// ignore_for_file: must_be_immutable
class StoryState extends Equatable {
  StoryState({this.commentController, this.storyModelObj});

  TextEditingController? commentController;
  StoryModel? storyModelObj;

  @override
  List<Object?> get props => [commentController, storyModelObj];

  StoryState copyWith({
    TextEditingController? commentController,
    StoryModel? storyModelObj,
  }) {
    return StoryState(
      commentController: commentController ?? this.commentController,
      storyModelObj: storyModelObj ?? this.storyModelObj,
    );
  }
}