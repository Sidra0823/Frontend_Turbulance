import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/enable_notification_bloc.dart';
import 'models/enable_notification_model.dart';

class EnableNotificationScreen extends StatelessWidget {
  const EnableNotificationScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => EnableNotificationBloc(
        EnableNotificationState(enableNotificationModel: EnableNotificationModel()),
      )..add(EnableNotificationInitialEvent()),
      child: const EnableNotificationScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<EnableNotificationBloc, EnableNotificationState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          body: SafeArea(
            child: SizedBox(
              width: double.infinity,
              child: SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.only(top: 42.h),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      SizedBox(height: 20.h),
                      SizedBox(
                        height: 692.h,
                        width: double.infinity,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Opacity(
                              opacity: 0.15,
                              child: CustomImageView(
                                imagePath: ImageConstant.imgImg7223Jpeg1692x430,
                                height: 692.h,
                                width: double.infinity,
                              ),
                            ),
                            _buildColumnCheckmark(context),
                          ],
                        ),
                      ),
                      SizedBox(height: 50.h),
                      CustomElevatedButton(
                        height: 48.h,
                        width: 176.h,
                        text: "lbl_next".tr,
                        margin: EdgeInsets.only(right: 22.h),
                        buttonStyle: CustomButtonStyles.fillDeepPurpleEA,
                        buttonTextStyle: CustomTextStyles.titleSmallNunito15,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildColumnCheckmark(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        margin: EdgeInsets.only(top: 142.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 100.h,
              width: 102.h,
              padding: EdgeInsets.only(bottom: 22.h),
              decoration: AppDecoration.outlinePrimary.copyWith(
                borderRadius: BorderRadiusStyle.circleBorder50,
              ),
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgCheckmarkPrimary,
                    height: 36.h,
                    width: 54.h,
                  ),
                ],
              ),
            ),
            SizedBox(height: 18.h),
            SizedBox(
              height: 66.h,
              width: 120.h,
              child: Column(
                children: [
                  Text(
                    "lbl_payment".tr,
                    style: theme.textTheme.headlineSmall,
                  ),
                  Text(
                    "lbl_successful".tr,
                    style: theme.textTheme.headlineSmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
