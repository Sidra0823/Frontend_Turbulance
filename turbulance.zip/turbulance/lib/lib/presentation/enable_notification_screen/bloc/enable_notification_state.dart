part of 'enable_notification_bloc.dart';

/// Represents the state of EnableNotification in the application.
class EnableNotificationState extends Equatable {
  final EnableNotificationModel? enableNotificationModel;

  EnableNotificationState({this.enableNotificationModel});

  @override
  List<Object?> get props => [enableNotificationModel];

  EnableNotificationState copyWith({EnableNotificationModel? enableNotificationModel}) {
    return EnableNotificationState(
      enableNotificationModel: enableNotificationModel ?? this.enableNotificationModel,
    );
  }
}
