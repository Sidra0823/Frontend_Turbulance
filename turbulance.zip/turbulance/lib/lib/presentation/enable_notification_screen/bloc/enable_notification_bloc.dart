import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/enable_notification_model.dart';

part 'enable_notification_event.dart';
part 'enable_notification_state.dart';

/// A bloc that manages the state of EnableNotification according to events.
class EnableNotificationBloc extends Bloc<EnableNotificationEvent, EnableNotificationState> {
  EnableNotificationBloc(EnableNotificationState initialState) : super(initialState) {
    on<EnableNotificationInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      EnableNotificationInitialEvent event, Emitter<EnableNotificationState> emit) async {
    emit(state.copyWith(enableNotificationModel: EnableNotificationModel()));
  }
}
