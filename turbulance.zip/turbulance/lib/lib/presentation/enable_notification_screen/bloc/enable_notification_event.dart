part of 'enable_notification_bloc.dart';

/// Abstract class for all events that can be dispatched from EnableNotification.
abstract class EnableNotificationEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event triggered when the EnableNotification widget is initialized.
class EnableNotificationInitialEvent extends EnableNotificationEvent {}
