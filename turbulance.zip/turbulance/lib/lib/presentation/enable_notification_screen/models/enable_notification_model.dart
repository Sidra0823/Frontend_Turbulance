import 'package:equatable/equatable.dart';

/// Model defining variables used in EnableNotificationScreen.
class EnableNotificationModel extends Equatable {
  EnableNotificationModel();

  EnableNotificationModel copyWith() {
    return EnableNotificationModel();
  }

  @override
  List<Object?> get props => [];
}
