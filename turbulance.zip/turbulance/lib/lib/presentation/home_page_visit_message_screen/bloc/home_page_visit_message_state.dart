part of 'home_page_visit_message_bloc.dart';

class HomePageVisitMessageState extends Equatable {
  HomePageVisitMessageState({
    this.pinViewController,
    this.homePageVisitMessageModelobj,
  });

  TextEditingController? pinViewController;
  HomePageVisitMessageModel? homePageVisitMessageModelobj;

  @override
  List<Object?> get props => [pinViewController, homePageVisitMessageModelobj];

  HomePageVisitMessageState copyWith({
    TextEditingController? pinViewController,
    HomePageVisitMessageModel? homePageVisitMessageModelobj,
  }) {
    return HomePageVisitMessageState(
      pinViewController: pinViewController ?? this.pinViewController,
      homePageVisitMessageModelobj: homePageVisitMessageModelobj ?? this.homePageVisitMessageModelobj,
    );
  }
}
