part of 'home_page_visit_message_bloc.dart';

abstract class HomePageVisitMessageEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class HomePageVisitMessageInitialEvent extends HomePageVisitMessageEvent {
  @override
  List<Object?> get props => [];
}
