import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/home_page_visit_message_model.dart';
import '../models/listmy_story_item_model.dart';

part 'home_page_visit_message_event.dart';
part 'home_page_visit_message_state.dart';

class HomePageVisitMessageBloc extends Bloc<HomePageVisitMessageEvent, HomePageVisitMessageState> {
  HomePageVisitMessageBloc(HomePageVisitMessageState initialState) : super(initialState) {
    on<HomePageVisitMessageInitialEvent>(_onInitialize);
  }

  void _onInitialize(HomePageVisitMessageInitialEvent event, Emitter<HomePageVisitMessageState> emit) async {
    emit(state.copyWith(
      pinViewController: TextEditingController(),
      homePageVisitMessageModelobj: state.homePageVisitMessageModelobj?.copyWith(
        listmyStoryItemList: fillListmyStoryItemList(),
      ),
    ));
  }

  List<ListmyStoryItemModel> fillListmyStoryItemList() {
    return [
      ListmyStoryItemModel(
          myStoryOne: ImageConstant.imgUntitledDesign64x64,
          myStoryThree: ImageConstant.imgUnnamed1,
          iconOne: ImageConstant.imgIconOnPrimary,
          mystory: "My Story"
      ),
      ListmyStoryItemModel(
          myStoryOne: ImageConstant.imgUntitledDesign64x64,
          mystory: "Selena"
      ),
      ListmyStoryItemModel(
          myStoryOne: ImageConstant.imgUntitledDesign64x64,
          mystory: "Clara"
      ),
      ListmyStoryItemModel(
          myStoryOne: ImageConstant.imgUntitledDesign64x64,
          mystory: "Fabian"
      ),
      ListmyStoryItemModel(mystory: "George"),
    ];
  }
}
