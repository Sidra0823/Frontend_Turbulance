import 'package:equatable/equatable.dart';

class ListmyStoryItemModel extends Equatable {
  ListmyStoryItemModel({
    this.myStoryOne,
    this.myStoryThree,
    this.iconOne,
    this.mystory,
    this.id,
  });

  String? myStoryOne;
  String? myStoryThree;
  String? iconOne;
  String? mystory;
  String? id;

  ListmyStoryItemModel copyWith({
    String? myStoryOne,
    String? myStoryThree,
    String? iconOne,
    String? mystory,
    String? id,
  }) {
    return ListmyStoryItemModel(
      myStoryOne: myStoryOne ?? this.myStoryOne,
      myStoryThree: myStoryThree ?? this.myStoryThree,
      iconOne: iconOne ?? this.iconOne,
      mystory: mystory ?? this.mystory,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [myStoryOne, myStoryThree, iconOne, mystory, id];
}
