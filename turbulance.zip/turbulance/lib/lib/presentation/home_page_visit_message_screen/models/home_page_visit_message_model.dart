import 'package:equatable/equatable.dart';
import 'listmy_story_item_model.dart';

class HomePageVisitMessageModel extends Equatable {
  HomePageVisitMessageModel({
    this.listmyStoryItemList = const [],
  });

  List<ListmyStoryItemModel> listmyStoryItemList;

  HomePageVisitMessageModel copyWith({
    List<ListmyStoryItemModel>? listmyStoryItemList,
  }) {
    return HomePageVisitMessageModel(
      listmyStoryItemList: listmyStoryItemList ?? this.listmyStoryItemList,
    );
  }

  @override
  List<Object?> get props => [listmyStoryItemList];
}
