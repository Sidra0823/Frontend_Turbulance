import 'package:flutter/material.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title_image.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import 'bloc/home_page_visit_message_bloc.dart';
import 'models/home_page_visit_message_model.dart';
import 'models/listmy_story_item_model.dart';
import 'widgets/listmy_story_item_widget.dart';

class HomePageVisitMessageScreen extends StatelessWidget {
  HomePageVisitMessageScreen({Key? key}) : super(key: key);

  GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<HomePageVisitMessageBloc>(
      create: (context) => HomePageVisitMessageBloc(HomePageVisitMessageState(
        homePageVisitMessageModelobj: HomePageVisitMessageModel(),
      ))..add(HomePageVisitMessageInitialEvent()),
      child: HomePageVisitMessageScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: _buildAppbar(context),
      body: SafeArea(
        top: false,
        child: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Container(
              height: 902.h,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: double.maxFinite,
                      margin: EdgeInsets.only(top: 4.h),
                      padding: EdgeInsets.symmetric(horizontal: 14.h, vertical: 10.h),
                      decoration: AppDecoration.fillGray,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("lbl_featured".tr, style: CustomTextStyles.titleSmall15),
                          SizedBox(height: 4.h),
                          _buildListMyStory(context),
                          SizedBox(height: 12.h),
                          _buildColumnPlayOne(context),
                          SizedBox(height: 278.h),
                          _buildColumn(context),
                        ],
                      ),
                    ),
                  ),
                  CustomBottomBar(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildListMyStory(BuildContext context) {
    return BlocBuilder<HomePageVisitMessageBloc, HomePageVisitMessageState>(
      builder: (context, state) {
        return SizedBox(
          height: 76.h,
          child: ListView.builder(
            itemCount: state.homePageVisitMessageModelobj?.listmyStoryItemList?.length ?? 0,
            scrollDirection: Axis.horizontal,
            itemBuilder: (context, index) {
              return ListmyStoryItemWidget(state.homePageVisitMessageModelobj?.listmyStoryItemList?[index] ?? ListmyStoryItemModel());
            },
          ),
        );
      },
    );
  }

  Widget _buildColumnPlayOne(BuildContext context) {
    return Column(
      children: [
        _buildItemPlayOne(context),
      ],
    );
  }

  Widget _buildColumn(BuildContext context) {
    return Column(
      children: [
        _buildItemPlayOne(context),
      ],
    );
  }

  Widget _buildItemPlayOne(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ProfilePagePhotoPostPage()),
        );
      },
      child: Container(
        margin: EdgeInsets.only(left: 20.h, right: 20.h, top: 12.h, bottom: 5.h),
        padding: EdgeInsets.symmetric(vertical: 12.h, horizontal: 16.h),
        decoration: BoxDecoration(
          color: appTheme.whiteA700,
          borderRadius: BorderRadius.circular(8.h),
          boxShadow: [BoxShadow(color: appTheme.black900.withOpacity(0.1), spreadRadius: 2, blurRadius: 10)],
        ),
        child: Row(
          children: [
            CustomImageView(imagePath: ImageConstant.imgPlaceholder, height: 44.h, width: 44.h, radius: BorderRadius.circular(8.h)),
            SizedBox(width: 14.h),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("msg_experience_the".tr, style: CustomTextStyles.bodyLargeInter),
                SizedBox(height: 5.h),
                Text("msg_share_the_fun".tr, style: CustomTextStyles.titleSmallInter),
              ],
            ),
            Spacer(),
            CustomImageView(imagePath: ImageConstant.imgArrowright, height: 16.h, width: 16.h),
          ],
        ),
      ),
    );
  }

  Widget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 62.h,
      title: AppbarTitleImage(imagePath: ImageConstant.imgTitleicon, onTap: () {}),
      actions: [
        AppbarLeadingImage(imagePath: ImageConstant.imgPlaceholder),
        AppbarTrailingImage(imagePath: ImageConstant.imgCloseicon, onTap: () {}),
      ],
    );
  }
}
