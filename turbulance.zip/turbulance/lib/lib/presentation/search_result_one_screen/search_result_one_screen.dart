import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/app_export.dart';
import '../../../theme/custom_button_style.dart';
import '../../../widgets/app_bar/appbar_leading_iconbutton.dart';
import '../../../widgets/app_bar/appbar_title_searchview.dart';
import '../../../widgets/app_bar/custom_app_bar.dart';
import '../../../widgets/custom_elevated_button.dart';
import 'bloc/search_result_one_bloc.dart';
import 'models/search_result_one_model.dart';
import 'widgets/slidablelistche_item_widget.dart';

/// The main screen for displaying the search results.
class SearchResultOneScreen extends StatelessWidget {
  const SearchResultOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<SearchResultOneBloc>(
      create: (context) => SearchResultOneBloc(
        SearchResultOneState(
          searchResultOneModelObj: SearchResultOneModel(),
        ),
      )..add(SearchResultOneInitialEvent()),
      child: const SearchResultOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: CustomElevatedButton(
                height: 40,
                width: 100,
                text: "Remove",
                buttonStyle: CustomButtonStyles.fillRed,
                onPressed: () {
                  // Handle Remove action
                },
              ),
            ),
            Expanded(
              child: BlocBuilder<SearchResultOneBloc, SearchResultOneState>(
                builder: (context, state) {
                  final model = state.searchResultOneModelObj;
                  if (model == null || model.slidablelistcheItemList.isEmpty) {
                    return const Center(child: Text("No results found."));
                  }
                  return ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    separatorBuilder: (context, index) => const SizedBox(height: 16),
                    itemCount: model.slidablelistcheItemList.length,
                    itemBuilder: (context, index) {
                      final item = model.slidablelistcheItemList[index];
                      return SlidablelistcheItemWidget(
                        slidablelistcheItemModelObj: item,
                        changeCheckBox: (value) {
                          // Handle checkbox change
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 56,
      leadingWidth: 72,
      leading: AppbarLeadingIconButton(
        imagePath: ImageConstant.imgCloseOnprimary,
        onTap: () => NavigatorService.goBack(),
      ),
      title: BlocBuilder<SearchResultOneBloc, SearchResultOneState>(
        builder: (context, state) {
          return AppbarTitleSearchview(
            hintText: "Search",
            controller: state.searchController,
            onChanged: (value) {
              // Handle search input
            },
          );
        },
      ),
    );
  }
}
