part of 'search_result_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the SearchResultOne widget.
class SearchResultOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the SearchResultOne widget is first created.
class SearchResultOneInitialEvent extends SearchResultOneEvent {}
