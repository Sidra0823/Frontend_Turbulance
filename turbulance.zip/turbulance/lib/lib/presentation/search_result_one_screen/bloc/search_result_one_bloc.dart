import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/search_result_one_model.dart';
import '../models/slidablelistche_item_model.dart';

part 'search_result_one_event.dart';
part 'search_result_one_state.dart';

/// A bloc that manages the state of a SearchResultOne according to the event that is dispatched to it.
class SearchResultOneBloc extends Bloc<SearchResultOneEvent, SearchResultOneState> {
  SearchResultOneBloc(SearchResultOneState initialState) : super(initialState) {
    on<SearchResultOneInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      SearchResultOneInitialEvent event, Emitter<SearchResultOneState> emit) async {
    emit(state.copyWith(
      searchController: TextEditingController(),
      searchResultOneModelObj: state.searchResultOneModelObj?.copyWith(
        slidablelistcheItemList: _fillSlidableListCheItemList(),
      ),
    ));
  }

  List<SlidablelistcheItemModel> _fillSlidableListCheItemList() {
    return [
      SlidablelistcheItemModel(
          untitledDesign: ImageConstant.imgUntitledDesign64x64,
          unnamedThree: ImageConstant.imgUnnamed1,
          turbulanceTwo: "Turbulance",
          turbulanceOne: "turbulance"),
      SlidablelistcheItemModel(
          untitledDesign: ImageConstant.imgUntitledDesign64x64,
          unnamedThree: ImageConstant.imgDownload50,
          turbulanceTwo: "Magdalene",
          turbulanceOne: "magdalene_02"),
      SlidablelistcheItemModel(
          untitledDesign: ImageConstant.imgUntitledDesign64x64,
          unnamedThree: ImageConstant.imgDownload48,
          turbulanceTwo: "Peter",
          turbulanceOne: "peter parker"),
      SlidablelistcheItemModel(
          untitledDesign: ImageConstant.imgUntitledDesign64x64,
          unnamedThree: ImageConstant.imgDownload48,
          turbulanceTwo: "Olive",
          turbulanceOne: "olive_lucy"),
      SlidablelistcheItemModel(
          untitledDesign: ImageConstant.imgUntitledDesign64x64,
          unnamedThree: ImageConstant.imgDownload48,
          turbulanceTwo: "Luke",
          turbulanceOne: "Luke fernandas"),
      SlidablelistcheItemModel(
          turbulanceTwo: "Grace", turbulanceOne: "grace elizabeth"),
      SlidablelistcheItemModel(
          turbulanceTwo: "Dian", turbulanceOne: "dian christopher"),
    ];
  }
}
