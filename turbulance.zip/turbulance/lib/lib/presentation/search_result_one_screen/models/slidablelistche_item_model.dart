import 'package:equatable/equatable.dart';

/// Model for SlidableListCheItem.
class SlidablelistcheItemModel extends Equatable {
  SlidablelistcheItemModel({
    this.untitledDesign,
    this.unnamedThree,
    this.turbulanceTwo,
    this.turbulanceOne,
    this.checkmarkTwo,
    this.id,
  });

  final String? untitledDesign;
  final String? unnamedThree;
  final String? turbulanceTwo;
  final String? turbulanceOne;
  final bool? checkmarkTwo;
  final String? id;

  SlidablelistcheItemModel copyWith({
    String? untitledDesign,
    String? unnamedThree,
    String? turbulanceTwo,
    String? turbulanceOne,
    bool? checkmarkTwo,
    String? id,
  }) {
    return SlidablelistcheItemModel(
      untitledDesign: untitledDesign ?? this.untitledDesign,
      unnamedThree: unnamedThree ?? this.unnamedThree,
      turbulanceTwo: turbulanceTwo ?? this.turbulanceTwo,
      turbulanceOne: turbulanceOne ?? this.turbulanceOne,
      checkmarkTwo: checkmarkTwo ?? this.checkmarkTwo,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [
    untitledDesign,
    unnamedThree,
    turbulanceTwo,
    turbulanceOne,
    checkmarkTwo,
    id,
  ];
}
