import 'package:equatable/equatable.dart';
import '../models/slidablelistche_item_model.dart';

/// Model for SearchResultOne.
class SearchResultOneModel extends Equatable {
  SearchResultOneModel({this.slidablelistcheItemList = const []});

  final List<SlidablelistcheItemModel> slidablelistcheItemList;

  SearchResultOneModel copyWith({
    List<SlidablelistcheItemModel>? slidablelistcheItemList,
  }) {
    return SearchResultOneModel(
      slidablelistcheItemList: slidablelistcheItemList ?? this.slidablelistcheItemList,
    );
  }

  @override
  List<Object?> get props => [slidablelistcheItemList];
}
