import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import '../../../widgets/custom_checkbox_button.dart';
import '../../../widgets/custom_icon_button.dart';
import '../models/slidablelistche_item_model.dart';

/// Widget representing an individual item in the Slidable List.
class SlidablelistcheItemWidget extends StatelessWidget {
  final SlidablelistcheItemModel slidablelistcheItemModelObj;
  final Function(bool)? changeCheckBox;

  const SlidablelistcheItemWidget({
    Key? key,
    required this.slidablelistcheItemModelObj,
    this.changeCheckBox,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Slidable(
      endActionPane: ActionPane(
        motion: ScrollMotion(),
        extentRatio: 0.4,
        dragDismissible: false,
        children: [
          Container(
            margin: EdgeInsets.only(left: 16),
            child: CustomIconButton(
              height: 30,
              width: 30,
              padding: EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.redAccent,
              ),
              child: Icon(Icons.delete, color: Colors.white),
              onTap: () {
                // Define delete action here
              },
            ),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 32,
              backgroundImage: AssetImage(slidablelistcheItemModelObj.untitledDesign!),
              child: CircleAvatar(
                radius: 28,
                backgroundImage: AssetImage(slidablelistcheItemModelObj.unnamedThree!),
              ),
            ),
            SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    slidablelistcheItemModelObj.turbulanceTwo ?? '',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    slidablelistcheItemModelObj.turbulanceOne ?? '',
                    style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
            CustomCheckboxButton(
              value: slidablelistcheItemModelObj.checkmarkTwo ?? false,
              onChange: (value) {
                if (changeCheckBox != null) {
                  changeCheckBox!(value);
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
