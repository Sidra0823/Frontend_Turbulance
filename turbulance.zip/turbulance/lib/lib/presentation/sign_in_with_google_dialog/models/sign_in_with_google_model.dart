import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';

/// This class defines the variables used in the [sign_in_with_google_dialog],
/// and is typically used to hold data that is passed between different parts of the application.

class SignInWithGoogleModel extends Equatable {
  // Constructor for SignInWithGoogleModel with an optional dropdownItemList parameter
  SignInWithGoogleModel({this.dropdownItemList = const []});

  // List of SelectionPopupModel items for the dropdown
  final List<SelectionPopupModel> dropdownItemList;

  // copyWith method to create a new instance with updated values
  SignInWithGoogleModel copyWith({List<SelectionPopupModel>? dropdownItemList}) {
    return SignInWithGoogleModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
    );
  }

  @override
  List<Object?> get props => [dropdownItemList]; // Equatable property for comparison
}
