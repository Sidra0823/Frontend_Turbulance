import 'package:flutter/material.dart';
import '../../core/utils/validation_functions.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_checkbox_button.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/sign_in_with_google_bloc.dart';
import 'models/sign_in_with_google_model.dart';

// ignore_for_file: must_be_immutable
class SignInWithGoogleDialog extends StatelessWidget {
  SignInWithGoogleDialog({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<SignInWithGoogleBloc>(
      create: (context) => SignInWithGoogleBloc(
        SignInWithGoogleState(
          signInWithGoogleModelObj: SignInWithGoogleModel(),
        ),
      )..add(SignInWithGoogleInitialEvent()),
      child: SignInWithGoogleDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: MainAxisSize.min,
      children: [
        Form(
          key: _formkey,
          child: SizedBox(
            width: double.maxFinite,
            child: Column(
              children: [
                Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.symmetric(vertical: 12.h),
                  decoration: AppDecoration.outlineGray30001.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder8,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      BlocSelector<SignInWithGoogleBloc, SignInWithGoogleState, TextEditingController?>(
                        selector: (state) => state.titleoneController,
                        builder: (context, titleoneController) {
                          return CustomTextFormField(
                            controller: titleoneController,
                            hintText: "msg_sign_in_with_google".tr,
                            hintStyle: CustomTextStyles.titleMediumRobotoGray70002,
                            prefix: Container(
                              margin: EdgeInsets.fromLTRB(8.h, 8.h, 12.h, 8.h),
                              child: CustomImageView(
                                imagePath: ImageConstant.imgGoogle,
                                height: 18.h,
                                width: 12.h,
                                fit: BoxFit.contain,
                              ),
                            ),
                            prefixConstraints: BoxConstraints(
                              maxHeight: 34.h,
                            ),
                            contentPadding: EdgeInsets.fromLTRB(8.h, 8.h, 12.h, 8.h),
                            borderDecoration: TextFormFieldStyleHelper.underLineGray,
                            filled: false,
                          );
                        },
                      ),
                      SizedBox(height: 36.h),
                      Text(
                        "lbl_hi_firstname".tr,
                        style: CustomTextStyles.headlineSmallRobotoRegular,
                      ),
                      SizedBox(height: 6.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgProfilePicture16x16,
                            height: 16.h,
                            width: 16.h,
                          ),
                          SizedBox(width: 8.h),
                          Text(
                            "lbl_email_gmail_com".tr,
                            style: CustomTextStyles.bodyMediumRoboto,
                          ),
                        ],
                      ),
                      SizedBox(height: 12.h),
                      Align(
                        alignment: Alignment.centerLeft,
                        child: Padding(
                          padding: EdgeInsets.only(left: 40.h),
                          child: Text(
                            "msg_to_continue_first".tr,
                            style: CustomTextStyles.bodyMediumRoboto_1,
                          ),
                        ),
                      ),
                      SizedBox(height: 24.h),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 32.h),
                        child: BlocSelector<SignInWithGoogleBloc, SignInWithGoogleState, TextEditingController?>(
                          selector: (state) => state.passwordController,
                          builder: (context, passwordController) {
                            return CustomTextFormField(
                              controller: passwordController,
                              hintText: "msg_enter_your_password".tr,
                              hintStyle: CustomTextStyles.bodyLargeRobotoLightblue700_1,
                              textInputAction: TextInputAction.done,
                              textInputType: TextInputType.visiblePassword,
                              obscureText: true,
                              contentPadding: EdgeInsets.symmetric(horizontal: 14.h, vertical: 16.h),
                              borderDecoration: TextFormFieldStyleHelper.outlineOnPrimaryTL8,
                              filled: false,
                              validator: (value) {
                                if (value == null || !isValidPassword(value, isRequired: true)) {
                                  return "err_msg_please_enter_valid_password".tr;
                                }
                                return null;
                              },
                            );
                          },
                        ),
                      ),
                      SizedBox(height: 88.h),
                      _buildShowpassword(context),
                      SizedBox(height: 24.h),
                      Container(
                        width: double.maxFinite,
                        margin: EdgeInsets.symmetric(horizontal: 40.h),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "msg_forgot_password".tr,
                              style: CustomTextStyles.titleSmallRobotoBlue600,
                            ),
                            CustomElevatedButton(
                              height: 36.h,
                              width: 78.h,
                              text: "lbl_next".tr,
                              buttonStyle: CustomButtonStyles.fillBlue,
                              buttonTextStyle: CustomTextStyles.titleSmallRoboto_1,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 48.h),
                    ],
                  ),
                ),
                SizedBox(height: 24.h),
                _buildFooter(context),
                SizedBox(height: 8.h),
              ],
            ),
          ),
        ),
      ],
    );
  }

  // Section Widget: Show Password Toggle
  Widget _buildShowpassword(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Padding(
        padding: EdgeInsets.only(left: 48.h),
        child: BlocSelector<SignInWithGoogleBloc, SignInWithGoogleState, bool?>(
          selector: (state) => state.showpassword,
          builder: (context, showpassword) {
            return CustomCheckboxButton(
              alignment: Alignment.centerLeft,
              text: "lbl_show_password".tr,
              value: showpassword ?? false,
              padding: EdgeInsets.symmetric(vertical: 6.h),
              textStyle: CustomTextStyles.bodyMediumRoboto_1,
              onChange: (value) {
                context.read<SignInWithGoogleBloc>().add(ChangeCheckBoxEvent(value: value));
              },
            );
          },
        ),
      ),
    );
  }

  // Section Widget: Footer with Dropdown and Legal Texts
  Widget _buildFooter(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.symmetric(horizontal: 16.h),
      child: Row(
        children: [
          BlocSelector<SignInWithGoogleBloc, SignInWithGoogleState, SignInWithGoogleModel?>(
            selector: (state) => state.signInWithGoogleModelObj,
            builder: (context, signInWithGoogleModelObj) {
              return CustomDropDown(
                width: 56.h,
                hintText: "lbl_english".tr,
                items: signInWithGoogleModelObj?.dropdownItemList ?? [],
                contentPadding: EdgeInsets.all(12.h),
              );
            },
          ),
          Spacer(flex: 66),
          Text(
            "lbl_help".tr,
            style: CustomTextStyles.labelLargeRobotoGray70002,
          ),
          Spacer(flex: 16),
          Text(
            "lbl_privacy".tr,
            style: CustomTextStyles.labelLargeRobotoGray70002,
          ),
          Spacer(flex: 16),
          Text(
            "lbl_terms".tr,
            style: CustomTextStyles.labelLargeRobotoGray70002,
          ),
        ],
      ),
    );
  }
}
