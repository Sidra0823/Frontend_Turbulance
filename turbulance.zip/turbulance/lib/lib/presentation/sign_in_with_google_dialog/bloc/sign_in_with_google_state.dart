part of 'sign_in_with_google_bloc.dart';

/// Represents the state of SignInWithGoogle in the application.

class SignInWithGoogleState extends Equatable {
  SignInWithGoogleState({
    this.titleoneController,
    this.passwordController,
    this.selectedDropDownValue,
    this.showpassword = false,
    this.signInWithGoogleModelObj,
  });

  // Properties for the state
  TextEditingController? titleoneController;
  TextEditingController? passwordController;
  SelectionPopupModel? selectedDropDownValue;
  SignInWithGoogleModel? signInWithGoogleModelObj;
  bool showpassword;

  @override
  List<Object?> get props => [
    titleoneController,
    passwordController,
    selectedDropDownValue,
    showpassword,
    signInWithGoogleModelObj,
  ];

  /// Method to copy the state and make modifications to it
  SignInWithGoogleState copyWith({
    TextEditingController? titleoneController,
    TextEditingController? passwordController,
    SelectionPopupModel? selectedDropDownValue,
    bool? showpassword,
    SignInWithGoogleModel? signInWithGoogleModelObj,
  }) {
    return SignInWithGoogleState(
      titleoneController: titleoneController ?? this.titleoneController,
      passwordController: passwordController ?? this.passwordController,
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      showpassword: showpassword ?? this.showpassword,
      signInWithGoogleModelObj: signInWithGoogleModelObj ?? this.signInWithGoogleModelObj,
    );
  }
}
