import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/sign_in_with_google_model.dart';

part 'sign_in_with_google_event.dart';
part 'sign_in_with_google_state.dart';

/// A bloc that manages the state of a SignInWithGoogle according to the event that is dispatched to it.
class SignInWithGoogleBloc extends Bloc<SignInWithGoogleEvent, SignInWithGoogleState> {
  SignInWithGoogleBloc(SignInWithGoogleState initialState) : super(initialState) {
    on<SignInWithGoogleInitialEvent>(_onInitialize);
    on<ChangeCheckBoxEvent>(_changeCheckBox);
  }

  /// Handles the initialization event for SignInWithGoogle
  Future<void> _onInitialize(
      SignInWithGoogleInitialEvent event,
      Emitter<SignInWithGoogleState> emit,
      ) async {
    // Simulate initialization logic
    emit(
      state.copyWith(
        titleOneController: TextEditingController(),
        passwordController: TextEditingController(),
        showPassword: false,
        signInWithGoogleModelObj: state.signInWithGoogleModelObj?.copyWith(
          dropdownItemList: _fillDropdownItemList(),
        ),
      ),
    );
  }

  /// Handles the change of the checkbox event
  void _changeCheckBox(
      ChangeCheckBoxEvent event,
      Emitter<SignInWithGoogleState> emit,
      ) {
    emit(
      state.copyWith(
        showPassword: event.value,
      ),
    );
  }

  /// Fills the dropdown item list with sample data
  List<SelectionPopupModel> _fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
