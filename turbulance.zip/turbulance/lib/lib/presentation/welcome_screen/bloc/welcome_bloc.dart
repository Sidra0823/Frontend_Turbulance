import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart'; // Import Bloc package

import '../models/welcome_model.dart';

part 'welcome_event.dart';
part 'welcome_state.dart';

/// A bloc that manages the state of a Welcome according to the event that is dispatched to it.
class WelcomeBloc extends Bloc<WelcomeEvent, WelcomeState> {
  // Constructor to initialize the WelcomeBloc with an initial state
  WelcomeBloc(WelcomeState initialState) : super(initialState) {
    on<WelcomeInitialEvent>(_onInitialize); // Event handler for WelcomeInitialEvent
  }

  // Event handler function
  Future<void> _onInitialize(
      WelcomeInitialEvent event,
      Emitter<WelcomeState> emit,
      ) async {
    // Simulate some initialization or delay
    await Future.delayed(const Duration(seconds: 3), () {
      // Pop the current screen and push the login screen after the delay
      NavigatorService.popAndPushNamed(AppRoutes.loginScreen);
    });
  }
}
