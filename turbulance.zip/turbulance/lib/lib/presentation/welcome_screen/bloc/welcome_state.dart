part of 'welcome_bloc.dart';

/// Represents the state of Welcome in the application.
/// This state holds the WelcomeModel object, which can be updated as needed.
class WelcomeState extends Equatable {
  // Optional WelcomeModel object to hold state
  WelcomeModel? welcomeModelobj;

  // Constructor for the state
  WelcomeState({this.welcomeModelobj});

  @override
  List<Object?> get props => [welcomeModelobj];

  // CopyWith method to allow for immutable state updates
  WelcomeState copyWith({WelcomeModel? welcomeModelobj}) {
    return WelcomeState(
      welcomeModelobj: welcomeModelobj ?? this.welcomeModelobj,
    );
  }
}
