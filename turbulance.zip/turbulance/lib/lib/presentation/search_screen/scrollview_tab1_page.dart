import 'package:flutter/material.dart';
import '../../widgets/custom_icon_button.dart';
import 'bloc/search_bloc.dart';
import 'models/scrollview_tab1_model.dart';

class ScrollviewTab1Page extends StatefulWidget {
  const ScrollviewTab1Page({Key? key}) : super(key: key);

  @override
  ScrollviewTab1PageState createState() => ScrollviewTab1PageState();

  static Widget builder(BuildContext context) {
    return BlocProvider<SearchBloc>(
      create: (context) => SearchBloc(
        SearchState(
          scrollviewTab1ModelObj: ScrollviewTab1Model(),
        ),
      )..add(SearchInitialEvent()),
      child: ScrollviewTab1Page(),
    );
  }
}

class ScrollviewTab1PageState extends State<ScrollviewTab1Page> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.only(top: 16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 144.0,
              child: Column(
                children: [
                  SizedBox(
                    height: 224.0,
                    width: double.infinity,
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CustomImageView(
                          imagePath: 'assets/images/your_image.jpg',
                          height: 224.0,
                          width: double.infinity,
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 2.0),
                          child: CustomIconButton(
                            height: 30.0,
                            width: 30.0,
                            padding: EdgeInsets.all(2.0),
                            decoration: IconButtonStyleHelper.none,
                            alignment: Alignment.topRight,
                            child: CustomImageView(
                              imagePath: 'assets/images/calendar_icon.png',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Align(
                alignment: Alignment.center,
                child: Column(
                  children: [
                    SizedBox(
                      width: double.infinity,
                      child: Row(
                        children: [
                          Expanded(
                            child: Container(
                              height: 126.0,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  CustomImageView(
                                    imagePath: 'assets/images/download_image.jpg',
                                    height: 126.0,
                                    width: double.infinity,
                                  ),
                                  CustomImageView(
                                    imagePath: 'assets/images/user_icon.png',
                                    height: 24.0,
                                    width: 26.0,
                                    alignment: Alignment.topRight,
                                    margin: EdgeInsets.only(top: 8.0, right: 8.0),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
