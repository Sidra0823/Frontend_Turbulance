import 'package:flutter/material.dart';
import '../../widgets/app_bar/appbar_title_searchview.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'bloc/search_bloc.dart';
import 'models/search_model.dart';
import 'scrollview_tab1_page.dart';
import 'search_result_page.dart';
import 'search_result_two_page.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  SearchScreenState createState() => SearchScreenState();

  static Widget builder(BuildContext context) {
    return BlocProvider<SearchBloc>(
      create: (context) => SearchBloc(
        SearchState(
          searchModelObj: SearchModel(),
        ),
      )..add(SearchInitialEvent()),
      child: SearchScreen(),
    );
  }
}

class SearchScreenState extends State<SearchScreen> with TickerProviderStateMixin {
  late TabController tabviewController;

  @override
  void initState() {
    super.initState();
    tabviewController = TabController(length: 4, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      appBar: buildAppbar(context),
      body: SafeArea(
        top: false,
        child: SizedBox(
          width: double.infinity,
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              SizedBox(height: 8.0),
              Text(
                "lbl_explore".tr,
                style: CustomTextStyles.titleLargeExtraBold,
              ),
              SizedBox(height: 14.0),
              _buildTabview(context),
              Expanded(
                child: Container(
                  child: TabBarView(
                    controller: tabviewController,
                    children: [
                      ScrollviewTab1Page.builder(context),
                      SearchResultTwoPage.builder(context),
                      SearchResultPage.builder(context),
                      SearchResultPage.builder(context),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTabview(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 36.0),
      width: double.infinity,
      child: TabBar(
        labelPadding: EdgeInsets.zero,
        labelColor: theme.colorScheme.onPrimary,
        controller: tabviewController,
        labelStyle: TextStyle(fontSize: 15.0, fontFamily: 'Nunito', fontWeight: FontWeight.w800),
        unselectedLabelColor: theme.colorScheme.onPrimary,
        unselectedLabelStyle: TextStyle(fontSize: 15.0, fontFamily: 'Nunito', fontWeight: FontWeight.w800),
        indicatorColor: appTheme.blueGray100,
        tabs: [
          Tab(child: Text("lbl_for_you".tr)),
          Tab(child: Text("lbl_accounts".tr)),
          Tab(child: Text("lbl_videos".tr)),
          Tab(child: Text("lbl_live".tr)),
        ],
      ),
    );
  }

  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 56.0,
      leadingWidth: 77.0,
      leading: AppbarLeadingIconButton(
        imagePath: ImageConstant.imgCloseOnPrimary,
        margin: EdgeInsets.only(left: 37.0),
        onTap: () {
          onTapCloseOne(context);
        },
      ),
      title: SizedBox(
        width: double.infinity,
        child: BlocSelector<SearchBloc, SearchState, TextEditingController?>(
          selector: (state) => state.searchoneController,
          builder: (context, searchoneController) {
            return AppbarTitleSearchview(
              margin: EdgeInsets.only(left: 12.0, right: 41.0),
              hintText: "msg_search_in_social".tr,
              controller: searchoneController,
            );
          },
        ),
      ),
    );
  }

  void onTapCloseOne(BuildContext context) {
    NavigatorService.goBack();
  }
}
