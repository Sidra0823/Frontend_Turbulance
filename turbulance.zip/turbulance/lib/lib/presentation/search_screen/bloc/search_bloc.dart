import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/scrollview_tab1_model.dart';
import '../models/search_model.dart';

part 'search_event.dart';
part 'search_state.dart';

/// A bloc that manages the state of a Search according to the event that is dispatched to it.
class SearchBloc extends Bloc<SearchEvent, SearchState> {
  SearchBloc(SearchState initialState) : super(initialState) {
    on<SearchInitialEvent>(onInitialize);
  }

  void onInitialize(
      SearchInitialEvent event,
      Emitter<SearchState> emit,
      ) async {
    emit(
      state.copyWith(
        searchoneController: TextEditingController(),
      ),
    );
  }
}
