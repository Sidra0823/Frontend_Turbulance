part of 'search_bloc.dart';

/// Represents the state of Search in the application.
// ignore_for_file: must_be_immutable
class SearchState extends Equatable {
  SearchState({
    this.searchoneController,
    this.scrollviewTab1ModelObj,
    this.searchModelObj,
  });

  TextEditingController? searchoneController;
  SearchModel? searchModelObj;
  ScrollviewTab1Model? scrollviewTab1ModelObj;

  @override
  List<Object?> get props => [
    searchoneController,
    scrollviewTab1ModelObj,
    searchModelObj,
  ];

  SearchState copyWith({
    TextEditingController? searchoneController,
    ScrollviewTab1Model? scrollviewTab1ModelObj,
    SearchModel? searchModelObj,
  }) {
    return SearchState(
      searchoneController: searchoneController ?? this.searchoneController,
      scrollviewTab1ModelObj: scrollviewTab1ModelObj ?? this.scrollviewTab1ModelObj,
      searchModelObj: searchModelObj ?? this.searchModelObj,
    );
  }
}
