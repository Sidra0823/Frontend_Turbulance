import 'package:equatable/equatable.dart';

/// This class is used in the [scrollview_tab1_page] screen.
class ScrollviewTab1Model extends Equatable {
  ScrollviewTab1Model();

  ScrollviewTab1Model copyWith() {
    return ScrollviewTab1Model();
  }

  @override
  List<Object?> get props => [];
}
