import 'package:equatable/equatable.dart';

import '../models/billing_and_payment_model.dart';

part 'billing_and_payment_event.dart';
part 'billing_and_payment_state.dart';

/// A bloc that manages the state of Billing and Payment according to the event dispatched to it.
class BillingAndPaymentBloc
    extends Bloc<BillingAndPaymentEvent, BillingAndPaymentState> {
  BillingAndPaymentBloc(BillingAndPaymentState initialState)
      : super(initialState) {
    on<BillingAndPaymentInitialEvent>(_onInitialize);
  }

  // Event handler for the BillingAndPaymentInitialEvent
  Future<void> _onInitialize(
      BillingAndPaymentInitialEvent event,
      Emitter<BillingAndPaymentState> emit,
      ) async {
    // Update the state with the initial model data and populate the spacer list
    emit(
      state.copyWith(
        billingAndPaymentModelObj: state.billingAndPaymentModelObj?.copyWith(
          listSpacerItemList: _fillListSpacerItemList(),
        ),
      ),
    );
  }

  // Method to fill the list with spacer item models
  List<ListSpacerItemModel> _fillListSpacerItemList() {
    return [
      ListSpacerItemModel(weekly: "10 / Weekly"),
      ListSpacerItemModel(weekly: "30 / Monthly"),
    ];
  }
}
