part of 'billing_and_payment_bloc.dart';

/// Represents the state of BillingAndPayment in the application.

class BillingAndPaymentState extends Equatable {
  BillingAndPaymentState({this.billingAndPaymentModelObj});

  BillingAndPaymentModel? billingAndPaymentModelObj;

  @override
  List<Object?> get props => [billingAndPaymentModelObj];

  BillingAndPaymentState copyWith({
    BillingAndPaymentModel? billingAndPaymentModelObj,
  }) {
    return BillingAndPaymentState(
      billingAndPaymentModelObj: billingAndPaymentModelObj ?? this.billingAndPaymentModelObj,
    );
  }
}
