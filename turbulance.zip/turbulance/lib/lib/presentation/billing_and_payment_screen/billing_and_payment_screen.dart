import 'package:flutter/material.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/billing_and_payment_bloc.dart';
import 'models/billing_and_payment_model.dart';

class BillingAndPaymentScreen extends StatelessWidget {
  const BillingAndPaymentScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<BillingAndPaymentBloc>(
      create: (context) => BillingAndPaymentBloc(
        BillingAndPaymentState(
          billingAndPaymentModelObj: BillingAndPaymentModel(),
        ),
      )..add(BillingAndPaymentInitialEvent()),
      child: BillingAndPaymentScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: _buildAppBar(context),
      body: SafeArea(
        top: false,
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 34.h,
            top: 30.h,
            right: 34.h,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgThumbsUpOnPrimary,
                    height: 44.h,
                    width: 44.h,
                  ),
                  SizedBox(width: 8.h),
                  Text(
                    "msg_billing_and_payments".tr,
                    style: theme.textTheme.headlineMedium,
                  ),
                ],
              ),
              SizedBox(height: 48.h),
              CustomImageView(
                imagePath: ImageConstant.imgProfilePicture80x80,
                height: 80.h,
                width: 82.h,
                radius: BorderRadius.circular(40.h),
              ),
              SizedBox(height: 18.h),
              Text(
                "lbl_turbulance".tr,
                style: theme.textTheme.headlineLarge,
              ),
              SizedBox(height: 44.h),
              _buildListSpacer(context),
              SizedBox(height: 246.h),
              CustomElevatedButton(
                height: 50.h,
                width: 150.h,
                text: "lbl_continue_to_buy".tr,
                buttonStyle: CustomButtonStyles.fillDeepPurpleEa,
                buttonTextStyle: CustomTextStyles.titleSmallNunito15,
              ),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          _onTapArrowLeft(context);
        },
      ),
      centerTitle: true,
      title: Text(
        "lbl_billing_and_payment".tr,
        style: theme.textTheme.headlineMedium,
      ),
    );
  }

  Widget _buildListSpacer(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 12.h),
      child: BlocSelector<BillingAndPaymentBloc, BillingAndPaymentState, BillingAndPaymentModel?>(
        selector: (state) => state.billingAndPaymentModelObj,
        builder: (context, billingAndPaymentModelObj) {
          return ListView.separated(
            padding: EdgeInsets.zero,
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (context, index) {
              return SizedBox(height: 4.h);
            },
            itemCount: billingAndPaymentModelObj?.listSpacerItemList.length ?? 0,
            itemBuilder: (context, index) {
              ListSpacerItemModel model = billingAndPaymentModelObj?.listSpacerItemList[index] ??
                  ListSpacerItemModel();
              return ListSpacerItemWidget(
                model,
              );
            },
          );
        },
      ),
    );
  }

  void _onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
