import 'package:flutter/material.dart';
import '../../../widgets/custom_checkbox_button.dart';
import '../models/listspacer_item_model.dart';

// ignore_for_file: must_be_immutable

class ListspacerItemWidget extends StatelessWidget {
  ListspacerItemWidget(
      this.listspacerItemModelObj, {
        Key? key,
        this.changeCheckBox,
      }) : super(key: key);

  final ListspacerItemModel listspacerItemModelObj;
  final Function(bool)? changeCheckBox;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 22.h,
        vertical: 10.h,
      ),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorders,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start, // Corrected alignment
        children: [
          Spacer(flex: 44),
          CustomImageView(
            imagePath: ImageConstant.imgUserOnprimary30x30,
            height: 30.h,
            width: 32.h,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(
                left: 24.h,
                top: 2.h,
              ),
              child: Text(
                listspacerItemModelObj.weekly!,
                style: theme.textTheme.titleLarge,
              ),
            ),
          ),
          Spacer(flex: 55),
          CustomCheckboxButton(
            value: listspacerItemModelObj.checkmark!,
            onChange: (value) {
              changeCheckBox?.call(value);
            },
          ),
        ],
      ),
    );
  }
}
