import 'package:equatable/equatable.dart';

/// This class is used in the [listspacer_item_widget] screen.

class ListspacerItemModel extends Equatable {
  ListspacerItemModel({
    this.weekly = "10 / Weekly",
    this.checkmark = false,
    this.id = "",
  });

  String? weekly;
  bool? checkmark;
  String? id;

  ListspacerItemModel copyWith({
    String? weekly,
    bool? checkmark,
    String? id,
  }) {
    return ListspacerItemModel(
      weekly: weekly ?? this.weekly,
      checkmark: checkmark ?? this.checkmark,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [weekly, checkmark, id];
}
