import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_ninetyseven_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class Iphone1415ProMaxNinetysevenModel extends Equatable {
  final List<SelectionPopupModel> dropdownItemList;

  Iphone1415ProMaxNinetysevenModel({this.dropdownItemList = const []});

  Iphone1415ProMaxNinetysevenModel copyWith({
    List<SelectionPopupModel>? dropdownItemList,
  }) {
    return Iphone1415ProMaxNinetysevenModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
    );
  }

  @override
  List<Object?> get props => [dropdownItemList];
}
