import 'package:flutter/material.dart';
import 'bloc/iphone_14_15_pro_max_ninetyseven_bloc.dart';
import 'models/iphone_14_15_pro_max_ninetyseven_model.dart';

class Iphone1415ProMaxNinetysevenScreen extends StatelessWidget {
  const Iphone1415ProMaxNinetysevenScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxNinetysevenBloc>(
      create: (context) => Iphone1415ProMaxNinetysevenBloc(
        Iphone1415ProMaxNinetysevenState(
          iphone1415ProMaxNinetysevenModelObj: Iphone1415ProMaxNinetysevenModel(),
        ),
      )..add(Iphone1415ProMaxNinetysevenInitialEvent()),
      child: const Iphone1415ProMaxNinetysevenScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 46),
            Text("Choose an account".tr, style: CustomTextStyles.headlineSmallRobotoRegular),
            const SizedBox(height: 20),
            Text("To continue to MyApp".tr, style: CustomTextStyles.bodyLargeRoboto),
            const SizedBox(height: 26),
            _buildProfile(context),
            const SizedBox(height: 20),
            _buildHorizontalScroll(context),
            const SizedBox(height: 28),
            _buildProfileOne(context),
            const Spacer(),
            _buildFooter(context),
          ],
        ),
      ),
    );
  }

  Widget _buildProfile(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 30),
      child: Row(
        children: [
          Image.asset('assets/imgPlay.png', height: 32, width: 32),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("UI August".tr, style: CustomTextStyles.titleSmallRobotoGray80001),
                Text("username@gmail.com".tr, style: CustomTextStyles.bodySmallRobotoGray80001),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHorizontalScroll(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          // Add horizontal scroll items here
        ],
      ),
    );
  }

  Widget _buildProfileOne(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 28),
      child: Row(
        children: [
          Icon(Icons.lock, size: 24),
          const SizedBox(width: 14),
          Text("Use another account".tr, style: CustomTextStyles.titleSmallRobotoGray80001Medium),
        ],
      ),
    );
  }

  Widget _buildFooter(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        DropdownButton<String>(
          hint: Text("English"),
          items: [
            // Add dropdown items here
          ],
          onChanged: (value) {},
        ),
        const Spacer(),
        TextButton(onPressed: () {}, child: Text("Help".tr)),
        TextButton(onPressed: () {}, child: Text("Privacy".tr)),
        TextButton(onPressed: () {}, child: Text("Terms".tr)),
      ],
    );
  }
}
