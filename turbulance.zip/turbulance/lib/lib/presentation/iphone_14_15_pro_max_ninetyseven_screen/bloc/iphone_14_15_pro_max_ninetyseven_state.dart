part of 'iphone_14_15_pro_max_ninetyseven_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetyseven in the application.
class Iphone1415ProMaxNinetysevenState extends Equatable {
  final SelectionPopupModel? selectedDropDownValue;
  final Iphone1415ProMaxNinetysevenModel? iphone1415ProMaxNinetysevenModelObj;

  Iphone1415ProMaxNinetysevenState({
    this.selectedDropDownValue,
    this.iphone1415ProMaxNinetysevenModelObj,
  });

  @override
  List<Object?> get props => [selectedDropDownValue, iphone1415ProMaxNinetysevenModelObj];

  Iphone1415ProMaxNinetysevenState copyWith({
    SelectionPopupModel? selectedDropDownValue,
    Iphone1415ProMaxNinetysevenModel? iphone1415ProMaxNinetysevenModelObj,
  }) {
    return Iphone1415ProMaxNinetysevenState(
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      iphone1415ProMaxNinetysevenModelObj: iphone1415ProMaxNinetysevenModelObj ?? this.iphone1415ProMaxNinetysevenModelObj,
    );
  }
}
