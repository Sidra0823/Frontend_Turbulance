import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/iphone_14_15_pro_max_ninetyseven_model.dart';

part 'iphone_14_15_pro_max_ninetyseven_event.dart';
part 'iphone_14_15_pro_max_ninetyseven_state.dart';

/// A bloc that manages the state of a Iphone1415ProMaxNinetyseven according to the event that is dispatched to it.
class Iphone1415ProMaxNinetysevenBloc extends Bloc<Iphone1415ProMaxNinetysevenEvent, Iphone1415ProMaxNinetysevenState> {
  Iphone1415ProMaxNinetysevenBloc(Iphone1415ProMaxNinetysevenState initialState)
      : super(initialState) {
    on<Iphone1415ProMaxNinetysevenInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      Iphone1415ProMaxNinetysevenInitialEvent event,
      Emitter<Iphone1415ProMaxNinetysevenState> emit,
      ) async {
    emit(state.copyWith(
      iphone1415ProMaxNinetysevenModelObj: state.iphone1415ProMaxNinetysevenModelObj?.copyWith(
        dropdownItemList: _fillDropdownItemList(),
      ),
    ));
  }

  List<SelectionPopupModel> _fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
