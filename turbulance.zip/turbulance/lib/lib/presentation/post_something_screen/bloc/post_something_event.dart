part of 'post_something_bloc.dart';

/// Abstract class for all events that can be dispatched from the PostSomething widget.
class PostSomethingEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the PostSomething widget is first created.
class PostSomethingInitialEvent extends PostSomethingEvent {
  @override
  List<Object?> get props => [];
}
