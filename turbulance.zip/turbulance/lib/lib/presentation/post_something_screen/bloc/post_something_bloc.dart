import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/post_something_initial_model.dart';
import '../models/post_something_item_model.dart';
import '../models/post_something_model.dart';

part 'post_something_event.dart';
part 'post_something_state.dart';

/// A bloc that manages the state of a PostSomething according to the event that is dispatched to it.
class PostSomethingBloc extends Bloc<PostSomethingEvent, PostSomethingState> {
  PostSomethingBloc(PostSomethingState initialState) : super(initialState);

  @override
  Stream<PostSomethingState> mapEventToState(PostSomethingEvent event) async* {
    if (event is PostSomethingInitialEvent) {
      yield* _onInitialize(event);
    }
  }

  Stream<PostSomethingState> _onInitialize(
      PostSomethingInitialEvent event) async* {
    yield state.copyWith(
      pinViewController: TextEditingController(),
    );
    yield state.copyWith(
      postSomethingInitialModelObj: state.postSomethingInitialModelObj?.copyWith(
        postSomethingItemList: _fillPostSomethingItemList(),
      ),
    );
  }

  List<PostSomethingItemModel> _fillPostSomethingItemList() {
    return [
      PostSomethingItemModel(
        myStoryOne: ImageConstant.imgUntitledDesign64x64,
        myStoryThree: ImageConstant.imgUnnamed1,
        iconOne: ImageConstant.imgIconOnprimary,
        mystory: "My Story",
      ),
      PostSomethingItemModel(myStoryOne: ImageConstant.imgUntitledDesign64x64, mystory: "Selena"),
      PostSomethingItemModel(myStoryOne: ImageConstant.imgUntitledDesign64x64, mystory: "Clara"),
      PostSomethingItemModel(myStoryOne: ImageConstant.imgUntitledDesign64x64, mystory: "Fabian"),
      PostSomethingItemModel(mystory: "George"),
    ];
  }
}
