part of 'post_something_bloc.dart';

/// Represents the state of PostSomething in the application.
class PostSomethingState extends Equatable {
  PostSomethingState({
    this.pinViewController,
    this.postSomethingInitialModelObj,
    this.postSomethingModelObj,
  });

  TextEditingController? pinViewController;
  PostSomethingModel? postSomethingModelObj;
  PostSomethingInitialModel? postSomethingInitialModelObj;

  @override
  List<Object?> get props => [
    pinViewController,
    postSomethingInitialModelObj,
    postSomethingModelObj,
  ];

  PostSomethingState copyWith({
    TextEditingController? pinViewController,
    PostSomethingInitialModel? postSomethingInitialModelObj,
    PostSomethingModel? postSomethingModelObj,
  }) {
    return PostSomethingState(
      pinViewController: pinViewController ?? this.pinViewController,
      postSomethingInitialModelObj: postSomethingInitialModelObj ?? this.postSomethingInitialModelObj,
      postSomethingModelObj: postSomethingModelObj ?? this.postSomethingModelObj,
    );
  }
}
