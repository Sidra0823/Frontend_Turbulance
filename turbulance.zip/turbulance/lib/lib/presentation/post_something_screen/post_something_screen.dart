import 'package:flutter/material.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../video_call_page/video_call_page.dart';
import 'bloc/post_something_bloc.dart';
import 'models/post_something_model.dart';
import 'post_something_initial_page.dart';

// ignore_for_file: must_be_immutable
class PostSomethingScreen extends StatelessWidget {
  PostSomethingScreen({Key? key}) : super(key: key);

  final GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<PostSomethingBloc>(
      create: (context) => PostSomethingBloc(
        PostSomethingState(postSomethingModelObj: PostSomethingModel()),
      )..add(PostSomethingInitialEvent()),
      child: PostSomethingScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: Navigator(
          key: navigatorKey,
          initialRoute: AppRoutes.postSomethingInitialPage,
          onGenerateRoute: (routeSetting) => PageRouteBuilder(
            pageBuilder: (ctx, ani, ani1) => Container(),  // Placeholder for page
            transitionDuration: Duration(seconds: 0),
          ),
        ),
      ),
      bottomNavigationBar: SizedBox(
        width: double.maxFinite,
        child: buildBottomBar(context),
      ),
    );
  }

  /// Section Widget
  Widget buildBottomBar(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: CustomBottomBar(
        onChanged: (BottomBarEnum type) {
          Navigator.pushNamed(
            navigatorKey.currentContext!,
            getCurrentRoute(type),
          );
        },
      ),
    );
  }

  /// Handling route based on bottom click actions
  String getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.postSomethingInitialPage;
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Close:
        return AppRoutes.videoCallPage;
      case BottomBarEnum.Useronprimary:
        return "/";
      case BottomBarEnum.Lockonprimary:
        return AppRoutes.profilePagePhotoPostPage;
      default:
        return "/";
    }
  }

  /// Handling page based on route
  Widget getCurrentPage(BuildContext context, String currentRoute) {
    switch (currentRoute) {
      case AppRoutes.postSomethingInitialPage:
        return PostSomethingInitialPage.builder(context);
      case AppRoutes.videoCallPage:
        return VideoCallPage.builder(context);
      case AppRoutes.profilePagePhotoPostPage:
        return ProfilePagePhotoPostPage.builder(context);
      default:
        return DefaultWidget();
    }
  }
}
