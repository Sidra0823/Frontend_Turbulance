import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title_image.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'bloc/post_something_bloc.dart';
import 'models/post_something_initial_model.dart';
import 'widgets/post_something_item_widget.dart';

class PostSomethingInitialPage extends StatefulWidget {
  const PostSomethingInitialPage({Key? key}) : super(key: key);

  @override
  PostSomethingInitialPageState createState() => PostSomethingInitialPageState();

  static Widget builder(BuildContext context) {
    return BlocProvider<PostSomethingBloc>(
      create: (context) => PostSomethingBloc(PostSomethingState(postSomethingInitialModelObj: PostSomethingInitialModel()))
        ..add(PostSomethingInitialEvent()),
      child: PostSomethingInitialPage(),
    );
  }
}

class PostSomethingInitialPageState extends State<PostSomethingInitialPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      decoration: AppDecoration.outlineBlack,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.maxFinite,
            child: buildAppbar(context),
          ),
          Expanded(
            child: SingleChildScrollView(
              child: Container(
                height: 902.h,
                child: Stack(
                  alignment: Alignment.bottomCenter,
                  children: [
                    Align(
                      alignment: Alignment.topCenter,
                      child: Container(
                        width: double.maxFinite,
                        margin: EdgeInsets.only(top: 4.h),
                        padding: EdgeInsets.symmetric(
                          horizontal: 14.h,
                          vertical: 10.h,
                        ),
                        decoration: AppDecoration.fillGray,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "lbl_featured".tr,
                              style: CustomTextStyles.titleSmall15,
                            ),
                            SizedBox(height: 4.h),
                            _buildPostSomething(context),
                            SizedBox(height: 12.h),
                            _buildColumnPlayOne(context),
                            SizedBox(height: 278.h),
                            _buildColumn(context),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 60.h,
      leadingWidth: 77.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgSearchOnprimary,
        margin: EdgeInsets.only(left: 37.h),
      ),
      centerTitle: true,
      title: AppbarTitleImage(
        imagePath: ImageConstant.imgUntitledDesign60x146,
        height: 60.h,
        width: 146.h,
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.ingUser,
          height: 30.h,
          width: 30.h,
          margin: EdgeInsets.only(right: 38.h),
        ),
      ],
    );
  }

  Widget _buildPostSomething(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(right: 10.h),
      width: double.maxFinite,
      child: BlocSelector<PostSomethingBloc, PostSomethingState, PostSomethingInitialModel?>(
        selector: (state) => state.postSomethingInitialModelObj,
        builder: (context, postSomethingInitialModelObj) {
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Wrap(
              direction: Axis.horizontal,
              children: postSomethingInitialModelObj?.postSomethingItemList
                  .map(
                    (e) => PostSomethingItemWidget(
                  postSomethingItemModel: e,
                ),
              )
                  .toList() ??
                  [],
            ),
          );
        },
      ),
    );
  }

  Widget _buildColumnPlayOne(BuildContext context) {
    return BlocBuilder<PostSomethingBloc, PostSomethingState>(
      builder: (context, state) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            PinCodeTextField(
              controller: state.pinViewController,
              length: 4,
              onChanged: (value) {},
              pinTheme: PinTheme(
                shape: PinCodeFieldShape.box,
                fieldHeight: 40.h,
                fieldWidth: 40.h,
                borderWidth: 1.h,
                activeColor: Colors.black,
              ),
              onCompleted: (value) {
                print(value);
              },
            ),
          ],
        );
      },
    );
  }

  Widget _buildColumn(BuildContext context) {
    return BlocSelector<PostSomethingBloc, PostSomethingState, PostSomethingModel>(
      selector: (state) => state.postSomethingModelObj,
      builder: (context, postSomethingModelObj) {
        return Column(
          children: [
            ElevatedButton(
              onPressed: () {
                print("Post something button pressed!");
              },
              child: Text('Post Something'),
            ),
          ],
        );
      },
    );
  }
}
