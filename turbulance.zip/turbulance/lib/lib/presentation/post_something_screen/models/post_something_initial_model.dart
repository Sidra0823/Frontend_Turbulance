import 'package:equatable/equatable.dart';
import 'post_something_item_model.dart';

/// This class is used in the [post_something_initial_page] screen.
class PostSomethingInitialModel extends Equatable {
  PostSomethingInitialModel({this.postSomethingItemList = const []});

  List<PostSomethingItemModel> postSomethingItemList;

  PostSomethingInitialModel copyWith({
    List<PostSomethingItemModel>? postSomethingItemList,
  }) {
    return PostSomethingInitialModel(
      postSomethingItemList: postSomethingItemList ?? this.postSomethingItemList,
    );
  }

  @override
  List<Object?> get props => [postSomethingItemList];
}
