import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [post_something_screen], and is typically used to hold data that is passed between different parts of the application.
class PostSomethingModel extends Equatable {
  PostSomethingModel();

  PostSomethingModel copyWith() {
    return PostSomethingModel();
  }

  @override
  List<Object?> get props => [];
}
