import 'package:equatable/equatable.dart';

/// This class is used in the [post_something_item_widget] screen.
class PostSomethingItemModel extends Equatable {
  PostSomethingItemModel({
    this.myStoryOne,
    this.myStoryThree,
    this.iconOne,
    this.mystory,
    this.id,
  });

  String? myStoryOne;
  String? myStoryThree;
  String? iconOne;
  String? mystory;
  String? id;

  PostSomethingItemModel copyWith({
    String? myStoryOne,
    String? myStoryThree,
    String? iconOne,
    String? mystory,
    String? id,
  }) {
    return PostSomethingItemModel(
      myStoryOne: myStoryOne ?? this.myStoryOne,
      myStoryThree: myStoryThree ?? this.myStoryThree,
      iconOne: iconOne ?? this.iconOne,
      mystory: mystory ?? this.mystory,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [myStoryOne, myStoryThree, iconOne, mystory, id];
}
