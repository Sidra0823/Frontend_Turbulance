import 'package:equatable/equatable.dart';
import '../models/settings_model.dart';

part 'settings_event.dart';
part 'settings_state.dart';

/// A bloc that manages the state of Settings according to the event that is dispatched to it.
class SettingsBloc extends Bloc<SettingsEvent, SettingsState> {
  SettingsBloc(SettingsState initialState) : super(initialState) {
    on<SettingsInitialEvent>(onInitialize);
  }

  _onInitialize(
      SettingsInitialEvent event,
      Emitter<SettingsState> emit,
      ) async {
    // Initialization logic
  }
}
