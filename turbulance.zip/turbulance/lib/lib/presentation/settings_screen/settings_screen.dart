import 'package:flutter/material.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_icon_button.dart';
import 'bloc/settings_bloc.dart';
import 'models/settings_model.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<SettingsBloc>(
      create: (context) => SettingsBloc(SettingsState(settingsModelObj: SettingsModel(),))
        ..add(SettingsInitialEvent()),
      child: SettingsScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SettingsBloc, SettingsState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          appBar: buildAppbar(context),
          body: SafeArea(
            top: false,
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.only(left: 30.h, top: 16.h, right: 30.h),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "lbl_settings".tr,
                    style: CustomTextStyles.headlineMediumSemiBold,
                  ),
                  SizedBox(height: 20.h),
                  _buildRowlockone(context),
                  SizedBox(height: 20.h),
                  _buildRowiconone(context),
                  SizedBox(height: 20.h),
                  _buildRowthumbsupone(context),
                  SizedBox(height: 20.h),
                  _buildRowlocationone(context),
                  SizedBox(height: 20.h),
                  _buildRowuploadone(context),
                  SizedBox(height: 20.h),
                  _buildRowhelp(context),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // AppBar Widget
  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      title: Padding(
        padding: EdgeInsets.only(left: 26.h),
        child: Column(
          children: [
            Row(
              children: [
                Card(
                  clipBehavior: Clip.antiAlias,
                  elevation: 0,
                  margin: EdgeInsets.symmetric(vertical: 3.h),
                  color: appTheme.blueGray900,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadiusStyle.roundedBorder5,
                  ),
                  child: Container(
                    height: 42.h,
                    width: 42.h,
                    decoration: AppDecoration.fillBluegray900.copyWith(
                      borderRadius: BorderRadiusStyle.roundedBorder5,
                    ),
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CustomImageView(
                          imagePath: ImageConstant.imgProfilePicture42x42,
                          height: 42.h,
                          width: 42.h,
                          radius: BorderRadius.circular(20.h),
                        ),
                        Align(
                          alignment: Alignment.topRight,
                          child: Container(
                            height: 8.h,
                            margin: EdgeInsets.only(
                              width: 8.h,
                              left: 34.h,
                              bottom: 34.h,
                            ),
                            decoration: BoxDecoration(
                              color: appTheme.green60001,
                              borderRadius: BorderRadius.circular(4.h),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                AppbarSubtitlesix(
                  text: "lbl_online".tr,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Row Widgets
  Widget _buildRowlockone(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: Row(
        children: [
          CustomIconButton(
            height: 44.h,
            width: 44.h,
            padding: EdgeInsets.all(2.h),
            decoration: IconButtonStyleHelper.fill0nPrimary,
            child: CustomImageView(imagePath: ImageConstant.imgLockGray90001),
          ),
          Padding(
            padding: EdgeInsets.only(left: 20.h),
            child: Text("lbl_my_account".tr, style: theme.textTheme.headlineSmall),
          ),
        ],
      ),
    );
  }

  // Other Row Widgets (_buildRowiconone, _buildRowthumbsupone, etc.) should follow the same structure as _buildRowlockone

  // Navigates to the previous screen
  void onTapArrowleftone(BuildContext context) {
    NavigatorService.goBack();
  }
}
