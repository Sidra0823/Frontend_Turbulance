part of 'live_bloc.dart';

/// Represents the state of Live in the application.
class LiveState extends Equatable {
  LiveState({this.liveModelObj});

  final LiveModel? liveModelObj;

  @override
  List<Object?> get props => [liveModelObj];

  LiveState copyWith({LiveModel? liveModelObj}) {
    return LiveState(
      liveModelObj: liveModelObj ?? this.liveModelObj,
    );
  }
}
