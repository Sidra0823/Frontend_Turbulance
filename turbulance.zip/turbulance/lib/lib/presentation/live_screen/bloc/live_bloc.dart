import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/live_model.dart';

part 'live_event.dart';
part 'live_state.dart';

/// A bloc that manages the state of a Live according to the event that is dispatched to it.
class LiveBloc extends Bloc<LiveEvent, LiveState> {
  LiveBloc(LiveState initialState) : super(initialState) {
    on<LiveInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      LiveInitialEvent event,
      Emitter<LiveState> emit,
      ) async {
    // Initialization logic here
  }
}
