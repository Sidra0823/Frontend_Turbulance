import 'package:equatable/equatable.dart';

/// This class is used in the [listaxis_bank_item_widget] screen.

// ignore_for_file: must_be_immutable

class ListaxisBankItemModel extends Equatable {
  ListaxisBankItemModel({
    this.axisbank,
    this.eightthousandth,
    this.id,
  }) {
    axisbank ??= "Axis Bank"; // Default value for axisbank
    eightthousandth ??= "**8395"; // Default value for eightthousandth
    id ??= ""; // Default value for id
  }

  String? axisbank;
  String? eightthousandth;
  String? id;

  ListaxisBankItemModel copyWith({
    String? axisbank,
    String? eightthousandth,
    String? id,
  }) {
    return ListaxisBankItemModel(
      axisbank: axisbank ?? this.axisbank,
      eightthousandth: eightthousandth ?? this.eightthousandth,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [axisbank, eightthousandth, id];
}
