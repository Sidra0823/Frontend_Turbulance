import 'package:equatable/equatable.dart';

import 'gridgoogle_pay_item_model.dart';
import 'listaxis_bank_item_model.dart';

/// This class defines the variables used in the [billing_and_payment_three_screen],
/// and is typically used to hold data that is passed between different parts of the application.

// ignore_for_file: must_be_immutable

class BillingAndPaymentThreeModel extends Equatable {
  BillingAndPaymentThreeModel({
    this.listaxisBankItemList = const [],
    this.gridgooglePayItemList = const [],
  });

  List<ListaxisBankItemModel> listaxisBankItemList;
  List<GridgooglePayItemModel> gridgooglePayItemList;

  BillingAndPaymentThreeModel copyWith({
    List<ListaxisBankItemModel>? listaxisBankItemList,
    List<GridgooglePayItemModel>? gridgooglePayItemList,
  }) {
    return BillingAndPaymentThreeModel(
      listaxisBankItemList: listaxisBankItemList ?? this.listaxisBankItemList,
      gridgooglePayItemList: gridgooglePayItemList ?? this.gridgooglePayItemList,
    );
  }

  @override
  List<Object?> get props => [listaxisBankItemList, gridgooglePayItemList];
}
