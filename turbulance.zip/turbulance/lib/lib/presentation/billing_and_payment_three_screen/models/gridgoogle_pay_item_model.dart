import 'package:equatable/equatable.dart';

/// This class is used in the [gridgoogle_pay_item_widget] screen.

// ignore_for_file: must_be_immutable

class GridgooglePayItemModel extends Equatable {
  GridgooglePayItemModel({
    this.googlepay,
    this.id,
  }) {
    googlepay ??= "Google Pay"; // Default value for googlepay
    id ??= ""; // Default value for id
  }

  String? googlepay;
  String? id;

  GridgooglePayItemModel copyWith({
    String? googlepay,
    String? id,
  }) {
    return GridgooglePayItemModel(
      googlepay: googlepay ?? this.googlepay,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [googlepay, id];
}
