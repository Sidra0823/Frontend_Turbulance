part of 'billing_and_payment_three_bloc.dart';

/// Represents the state of BillingAndPayment Three in the application.
// ignore_for_file: must_be_immutable

class BillingAndPaymentThreeState extends Equatable {
  BillingAndPaymentThreeState({this.billingAndPaymentThreeModelObj});

  BillingAndPaymentThreeModel? billingAndPaymentThreeModelObj;

  @override
  List<Object?> get props => [billingAndPaymentThreeModelObj];

  BillingAndPaymentThreeState copyWith({
    BillingAndPaymentThreeModel? billingAndPaymentThreeModelObj,
  }) {
    return BillingAndPaymentThreeState(
      billingAndPaymentThreeModelObj: billingAndPaymentThreeModelObj ?? this.billingAndPaymentThreeModelObj,
    );
  }
}
