import 'package:equatable/equatable.dart';
import '../models/billing_and_payment_three_model.dart';

part 'billing_and_payment_three_event.dart';
part 'billing_and_payment_three_state.dart';

/// A bloc that manages the state of BillingAndPaymentThree according to the event that is dispatched to it.
class BillingAndPaymentThreeBloc
    extends Bloc<BillingAndPaymentThreeEvent, BillingAndPaymentThreeState> {
  BillingAndPaymentThreeBloc(BillingAndPaymentThreeState initialState)
      : super(initialState) {
    on<BillingAndPaymentThreeInitialEvent>(onInitialize);
  }

  Future<void> onInitialize(
      BillingAndPaymentThreeInitialEvent event,
      Emitter<BillingAndPaymentThreeState> emit,
      ) async {
    emit(
      state.copyWith(
        billingAndPaymentThreeModelObj: state.billingAndPaymentThreeModelObj?.copyWith(
          gridGooglePayItemList: fillGridGooglePayItemList(),
          listAxisBankItemList: fillListAxisBankItemList(),
        ),
      ),
    );
  }

  List<GridGooglePayItemModel> fillGridGooglePayItemList() {
    return [
      GridGooglePayItemModel(googlePay: "Google Pay"),
      GridGooglePayItemModel(googlePay: "Google Pay 2"),
      GridGooglePayItemModel(googlePay: "Google Pay 3"),
    ];
  }

  List<ListAxisBankItemModel> fillListAxisBankItemList() {
    return [
      ListAxisBankItemModel(axisBank: "Axis Bank", cardNumber: "********** 8395"),
      ListAxisBankItemModel(axisBank: "Axis Bank", cardNumber: "********** 2345"),
    ];
  }
}
