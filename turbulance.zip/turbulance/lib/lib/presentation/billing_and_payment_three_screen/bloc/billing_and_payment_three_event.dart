part of 'billing_and_payment_three_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// BillingAndPaymentThree widget.
/// Events must be immutable and implement the [Equatable] interface.
class BillingAndPaymentThreeEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the BillingAndPaymentThree widget is first created.
class BillingAndPaymentThreeInitialEvent extends BillingAndPaymentThreeEvent {
  @override
  List<Object?> get props => [];
}
