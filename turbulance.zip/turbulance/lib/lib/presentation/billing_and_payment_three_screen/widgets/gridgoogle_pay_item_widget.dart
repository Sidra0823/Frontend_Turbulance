import 'package:flutter/material.dart';
import '../models/gridgoogle_pay_item_model.dart';

// ignore_for_file: must_be_immutable

class GridgooglePayItemWidget extends StatelessWidget {
  // Constructor with a parameter for gridgooglePayItemModelobj
  GridgooglePayItemWidget(
      this.gridgooglePayItemModelObj, {
        Key? key,
      }) : super(key: key);

  final GridgooglePayItemModel gridgooglePayItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        // CustomImageView should be from your custom widget package
        CustomImageView(
          imagePath: ImageConstant.imgImage3, // Fixed image path
          height: 20.h,
          width: 22.h,
        ),
        SizedBox(width: 8.h),
        Text(
          gridgooglePayItemModelObj.googlepay!,
          style: CustomTextStyles.bodySmallIBMPlexSansOnPrimary,
        ),
      ],
    );
  }
}
