import 'package:equatable/equatable.dart';

/// This class is used in the [home_three_item_widget] screen.
// ignore_for_file: must_be_immutable
class HomeThreeItemModel extends Equatable {
  HomeThreeItemModel({
    this.myStoryOne,
    this.myStoryThree,
    this.iconOne,
    this.myStory,
    this.id,
  });

  String? myStoryOne;
  String? myStoryThree;
  String? iconOne;
  String? myStory;
  String? id;

  HomeThreeItemModel copyWith({
    String? myStoryOne,
    String? myStoryThree,
    String? iconOne,
    String? myStory,
    String? id,
  }) {
    return HomeThreeItemModel(
      myStoryOne: myStoryOne ?? this.myStoryOne,
      myStoryThree: myStoryThree ?? this.myStoryThree,
      iconOne: iconOne ?? this.iconOne,
      myStory: myStory ?? this.myStory,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [myStoryOne, myStoryThree, iconOne, myStory, id];
}
