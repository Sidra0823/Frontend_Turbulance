import 'package:flutter/material.dart';

import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title_image.dart';
import '../../widgets/app_bar/appbar_trailing_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import 'bloc/home_bloc.dart';
import 'models/home_model.dart';
import 'models/home_three_item_model.dart';
import 'widgets/home_three_item_widget.dart';

// ignore_for_file: must_be_immutable

class HomeScreen extends StatelessWidget {
  HomeScreen({Key? key}) : super(key: key);

  final GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<HomeBloc>(
      create: (context) => HomeBloc(
        HomeState(homeModelObj: HomeModel()),
      )..add(HomeInitialEvent()),
      child: HomeScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: _buildAppBar(context),
      body: SafeArea(
        top: false,
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: const EdgeInsets.all(16.0),
                padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 10.0),
                decoration: AppDecoration.fillGray,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "lbl_featured".tr,
                      style: CustomTextStyles.titleSmall15,
                    ),
                    SizedBox(height: 8.0),
                    _buildHomeThree(context),
                    SizedBox(height: 12.0),
                    _buildColumnPlayOne(context),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomBar(
        onChanged: (BottomBarEnum type) {
          Navigator.pushNamed(
            navigatorKey.currentContext!,
            _getCurrentRoute(type),
          );
        },
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 60.0,
      leadingWidth: 77.0,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgSearchOnPrimary,
        margin: const EdgeInsets.only(left: 16.0),
      ),
      centerTitle: true,
      title: AppbarTitleImage(
        imagePath: ImageConstant.imgUntitledDesign60x146,
        height: 60.0,
        width: 146.0,
      ),
      actions: [
        AppbarTrailingImage(
          imagePath: ImageConstant.imgUser,
          height: 30.0,
          width: 30.0,
          margin: const EdgeInsets.only(right: 16.0),
        ),
      ],
    );
  }

  Widget _buildHomeThree(BuildContext context) {
    return BlocSelector<HomeBloc, HomeState, HomeModel?>(
      selector: (state) => state.homeModelObj,
      builder: (context, homeModelObj) {
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: List.generate(
              homeModelObj?.homeThreeItemList.length ?? 0,
                  (index) {
                final HomeThreeItemModel model = homeModelObj!.homeThreeItemList[index];
                return HomeThreeItemWidget(model);
              },
            ),
          ),
        );
      },
    );
  }

  Widget _buildColumnPlayOne(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 10.0),
      decoration: AppDecoration.fillBlack.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorders,
      ),
      child: Column(
        children: [
          Row(
            children: [
              CustomImageView(
                imagePath: ImageConstant.imgPlay30x30,
                height: 30.0,
                width: 30.0,
              ),
              SizedBox(width: 8.0),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "lbl_turbulance".tr,
                    style: CustomTextStyles.titleSmall15,
                  ),
                  SizedBox(height: 4.0),
                  Text(
                    "lbl_us_california".tr,
                    style: theme.textTheme.labelMedium,
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.postSomethingInitialPage;
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Close:
        return AppRoutes.videoCallPage;
      case BottomBarEnum.UserOnPrimary:
        return "/";
      case BottomBarEnum.LockOnPrimary:
        return AppRoutes.profilePagePhotoPostPage;
      default:
        return "/";
    }
  }
}
