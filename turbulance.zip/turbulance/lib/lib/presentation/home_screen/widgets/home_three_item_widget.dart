import 'package:flutter/material.dart';
import '../../../widgets/custom_icon_button.dart';
import '../models/home_three_item_model.dart';

// ignore_for_file: must_be_immutable
class HomeThreeItemWidget extends StatelessWidget {
  HomeThreeItemWidget(this.homeThreeItemModelObj, {Key? key}) : super(key: key);

  final HomeThreeItemModel homeThreeItemModelObj;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 64.h,
      child: Column(
        children: [
          SizedBox(
            height: 64.h,
            width: double.maxFinite,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomImageView(
                  imagePath: homeThreeItemModelObj.myStoryOne!,
                  height: 64.h,
                  width: 64.h,
                  radius: BorderRadius.circular(32.h),
                ),
                Container(
                  height: 54.h,
                  margin: EdgeInsets.only(left: 4.h, right: 2.h),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CustomImageView(
                        imagePath: homeThreeItemModelObj.myStoryThree!,
                        height: 54.h,
                        width: 54.h,
                        radius: BorderRadius.circular(26.h),
                      ),
                      CustomIconButton(
                        height: 16.h,
                        width: 16.h,
                        padding: EdgeInsets.all(4.h),
                        decoration: IconButtonStyleHelper.outlineOnPrimary,
                        alignment: Alignment.bottomRight,
                        child: CustomImageView(
                          imagePath: homeThreeItemModelObj.iconOne!,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            homeThreeItemModelObj.myStory!,
            overflow: TextOverflow.ellipsis,
            style: CustomTextStyles.titleSmallInter,
          ),
        ],
      ),
    );
  }
}
