import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/home_model.dart';
import '../models/home_three_item_model.dart';

part 'home_event.dart';
part 'home_state.dart';

/// A bloc that manages the state of a Home according to the event that is dispatched to it.
class HomeBloc extends Bloc<HomeEvent, HomeState> {
  HomeBloc(HomeState initialState) : super(initialState) {
    on<HomeInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      HomeInitialEvent event,
      Emitter<HomeState> emit,
      ) async {
    emit(state.copyWith(
      pinViewController: TextEditingController(),
      homeModelObj: state.homeModelObj?.copyWith(
        homeThreeItemList: fillHomeThreeItemList(),
      ),
    ));
  }

  List<HomeThreeItemModel> fillHomeThreeItemList() {
    return [
      HomeThreeItemModel(
        myStoryOne: ImageConstant.imgUntitledDesign64x64,
        myStoryThree: ImageConstant.imgUnnamed1,
        iconOne: ImageConstant.imgIconOnPrimary,
        myStory: "My Story",
      ),
      HomeThreeItemModel(myStoryOne: ImageConstant.imgUntitledDesign64x64, myStory: "Selena"),
      HomeThreeItemModel(myStoryOne: ImageConstant.imgUntitledDesign64x64, myStory: "Clara"),
      HomeThreeItemModel(myStoryOne: ImageConstant.imgUntitledDesign64x64, myStory: "Fabian"),
      HomeThreeItemModel(myStory: "George"),
    ];
  }
}
