part of 'home_bloc.dart';

/// Represents the state of Home in the application.
// ignore_for_file: must_be_immutable
class HomeState extends Equatable {
  HomeState({this.pinViewController, this.homeModelObj});

  TextEditingController? pinViewController;
  HomeModel? homeModelObj;

  @override
  List<Object?> get props => [pinViewController, homeModelObj];

  HomeState copyWith({
    TextEditingController? pinViewController,
    HomeModel? homeModelObj,
  }) {
    return HomeState(
      pinViewController: pinViewController ?? this.pinViewController,
      homeModelObj: homeModelObj ?? this.homeModelObj,
    );
  }
}
