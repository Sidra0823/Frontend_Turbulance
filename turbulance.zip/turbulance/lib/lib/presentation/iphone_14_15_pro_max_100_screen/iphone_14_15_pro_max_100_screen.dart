import 'package:flutter/material.dart';
import '../../core/utils/validation_functions.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../../widgets/custom_drop_down.dart';
import '../../widgets/custom_floating_text_field.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/iphone_14_15_pro_max_100_bloc.dart';
import 'models/iphone_14_15_pro_max_100_model.dart';

/// Screen for Iphone1415ProMax100
class Iphone1415ProMax100Screen extends StatelessWidget {
  Iphone1415ProMax100Screen({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMax100Bloc>(
      create: (context) => Iphone1415ProMax100Bloc(
        Iphone1415ProMax100State(
          iphone1415ProMax100ModelObj: Iphone1415ProMax100Model(),
        ),
      )..add(Iphone1415ProMax100InitialEvent()),
      child: Iphone1415ProMax100Screen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: Container(
            width: double.maxFinite,
            padding: EdgeInsets.symmetric(horizontal: 32.h, vertical: 130.h),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.only(top: 12.h),
                  decoration: AppDecoration.outlineGray30001.copyWith(
                    borderRadius: BorderRadiusStyle.roundedBorder,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildGoogleSignInSection(),
                      SizedBox(height: 36.h),
                      _buildCustomTextFieldSection(context),
                      SizedBox(height: 88.h),
                      _buildFooterSection(context),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildGoogleSignInSection() {
    return Column(
      children: [
        Row(
          children: [
            CustomImageView(
              imagePath: ImageConstant.imgGoogle,
              height: 12.h,
              width: 12.h,
            ),
            SizedBox(width: 12.h),
            Text(
              "msg_sign_in_with_google".tr,
              style: CustomTextStyles.titleMediumRobotoGray70002,
            ),
          ],
        ),
        SizedBox(height: 14.h),
        Divider(color: appTheme.gray30001),
      ],
    );
  }

  Widget _buildCustomTextFieldSection(BuildContext context) {
    return Column(
      children: [
        BlocSelector<Iphone1415ProMax100Bloc, Iphone1415ProMax100State, TextEditingController?>(
          selector: (state) => state.nameController,
          builder: (context, nameController) {
            return CustomFloatingTextField(
              controller: nameController,
              labelText: "lbl_account_name".tr,
              hintText: "lbl_account_name".tr,
              validator: (value) => _validateText(value),
            );
          },
        ),
        SizedBox(height: 60.h),
        BlocSelector<Iphone1415ProMax100Bloc, Iphone1415ProMax100State, TextEditingController?>(
          selector: (state) => state.nameOneController,
          builder: (context, nameOneController) {
            return CustomFloatingTextField(
              controller: nameOneController,
              labelText: "lbl_account_name".tr,
              hintText: "lbl_account_name".tr,
              validator: (value) => _validateText(value),
            );
          },
        ),
        SizedBox(height: 60.h),
        BlocSelector<Iphone1415ProMax100Bloc, Iphone1415ProMax100State, TextEditingController?>(
          selector: (state) => state.anotherAccountController,
          builder: (context, anotherAccountController) {
            return CustomTextFormField(
              controller: anotherAccountController,
              hintText: "msg_use_another_account".tr,
              textInputAction: TextInputAction.done,
              prefix: _buildPrefixIcon(),
            );
          },
        ),
      ],
    );
  }

  Widget _buildPrefixIcon() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8.h),
      child: CustomImageView(
        imagePath: ImageConstant.imgAccountIcon,
        height: 18.h,
        width: 28.h,
      ),
    );
  }

  String? _validateText(String? value) {
    if (!isText(value)) {
      return "err_msg_please_enter_valid_text".tr;
    }
    return null;
  }

  Widget _buildFooterSection(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        BlocSelector<Iphone1415ProMax100Bloc, Iphone1415ProMax100State, Iphone1415ProMax100Model?>(
          selector: (state) => state.iphone1415ProMax100ModelObj,
          builder: (context, model) {
            return CustomDropDown(
              hintText: "lbl_english".tr,
              items: model?.dropdownItemList ?? [],
            );
          },
        ),
        Spacer(),
        Text("lbl_help".tr, style: CustomTextStyles.labelLargeRobotoGray70002),
        Spacer(),
        Text("lbl_privacy".tr, style: CustomTextStyles.labelLargeRobotoGray70002),
        Spacer(),
        Text("lbl_terms".tr, style: CustomTextStyles.labelLargeRobotoGray70002),
      ],
    );
  }
}
