part of 'iphone_14_15_pro_max_100_bloc.dart';

/// Represents the state of Iphone1415ProMax100 in the application.
class Iphone1415ProMax100State extends Equatable {
  Iphone1415ProMax100State({
    this.nameController,
    this.nameOneController,
    this.anotherAccountController,
    this.selectedDropDownValue,
    this.iphone1415ProMax100ModelObj,
  });

  final TextEditingController? nameController;
  final TextEditingController? nameOneController;
  final TextEditingController? anotherAccountController;
  final SelectionPopupModel? selectedDropDownValue;
  final Iphone1415ProMax100Model? iphone1415ProMax100ModelObj;

  @override
  List<Object?> get props => [
    nameController,
    nameOneController,
    anotherAccountController,
    selectedDropDownValue,
    iphone1415ProMax100ModelObj,
  ];

  Iphone1415ProMax100State copyWith({
    TextEditingController? nameController,
    TextEditingController? nameOneController,
    TextEditingController? anotherAccountController,
    SelectionPopupModel? selectedDropDownValue,
    Iphone1415ProMax100Model? iphone1415ProMax100ModelObj,
  }) {
    return Iphone1415ProMax100State(
      nameController: nameController ?? this.nameController,
      nameOneController: nameOneController ?? this.nameOneController,
      anotherAccountController: anotherAccountController ?? this.anotherAccountController,
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      iphone1415ProMax100ModelObj: iphone1415ProMax100ModelObj ?? this.iphone1415ProMax100ModelObj,
    );
  }
}
