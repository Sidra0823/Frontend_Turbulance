import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';

import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/iphone_14_15_pro_max_100_model.dart';

part 'iphone_14_15_pro_max_100_event.dart';
part 'iphone_14_15_pro_max_100_state.dart';

/// A bloc that manages the state of a Iphone1415ProMax100 according to the event that is dispatched to it.
class Iphone1415ProMax100Bloc extends Bloc<Iphone1415ProMax100Event, Iphone1415ProMax100State> {
  Iphone1415ProMax100Bloc(Iphone1415ProMax100State initialState) : super(initialState) {
    on<Iphone1415ProMax100InitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      Iphone1415ProMax100InitialEvent event,
      Emitter<Iphone1415ProMax100State> emit,
      ) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      nameOneController: TextEditingController(),
      anotherAccountController: TextEditingController(),
    ));
    emit(state.copyWith(
      iphone1415ProMax100ModelObj: state.iphone1415ProMax100ModelObj?.copyWith(
        dropdownItemList: fillDropdownItemList(),
      ),
    ));
  }

  List<SelectionPopupModel> fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
