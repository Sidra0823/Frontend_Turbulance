import 'package:equatable/equatable.dart';
import 'package:data/models/selection_popup_model/selection_popup_model.dart';

/// This class defines the variables used in the [add_card_option_screen],
/// and is typically used to hold data that is passed between different parts of the application.

// ignore_for_file: must_be_immutable
class AddCardOptionModel extends Equatable {
  final List<SelectionPopupModel> dropdownItemList;
  final List<SelectionPopupModel> dropdownItemList1;

  const AddCardOptionModel({
    this.dropdownItemList = const [],
    this.dropdownItemList1 = const [],
  });

  AddCardOptionModel copyWith({
    List<SelectionPopupModel>? dropdownItemList,
    List<SelectionPopupModel>? dropdownItemList1,
  }) {
    return AddCardOptionModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
      dropdownItemList1: dropdownItemList1 ?? this.dropdownItemList1,
    );
  }

  @override
  List<Object?> get props => [dropdownItemList, dropdownItemList1];
}