part of 'add_card_option_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// AddCardOption widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class AddCardOptionEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the AddCardOption widget is first created.
class AddCardOptionInitialEvent extends AddCardOptionEvent {
  @override
  List<Object?> get props => [];
}