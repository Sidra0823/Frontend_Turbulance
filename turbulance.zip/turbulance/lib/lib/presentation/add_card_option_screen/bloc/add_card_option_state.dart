part of 'add_card_option_bloc.dart';

/// Represents the state of AddCardOption in the application.
class AddCardOptionState extends Equatable {
  final TextEditingController? cardNumberController;
  final TextEditingController? cvvTwoController;
  final TextEditingController? nameController;
  final SelectionPopupModel? selectedDropDownValue;
  final SelectionPopupModel? selectedDropDownValue1;
  final AddCardOptionModel? addCardOptionModelObj;

  const AddCardOptionState({
    this.cardNumberController,
    this.cvvTwoController,
    this.nameController,
    this.selectedDropDownValue,
    this.selectedDropDownValue1,
    this.addCardOptionModelObj,
  });

  @override
  List<Object?> get props => [
    cardNumberController,
    cvvTwoController,
    nameController,
    selectedDropDownValue,
    selectedDropDownValue1,
    addCardOptionModelObj,
  ];

  AddCardOptionState copyWith({
    TextEditingController? cardNumberController,
    TextEditingController? cvvTwoController,
    TextEditingController? nameController,
    SelectionPopupModel? selectedDropDownValue,
    SelectionPopupModel? selectedDropDownValue1,
    AddCardOptionModel? addCardOptionModelObj,
  }) {
    return AddCardOptionState(
      cardNumberController: cardNumberController ?? this.cardNumberController,
      cvvTwoController: cvvTwoController ?? this.cvvTwoController,
      nameController: nameController ?? this.nameController,
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      selectedDropDownValue1: selectedDropDownValue1 ?? this.selectedDropDownValue1,
      addCardOptionModelObj: addCardOptionModelObj ?? this.addCardOptionModelObj,
    );
  }
}