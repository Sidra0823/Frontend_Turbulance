import 'package:flutter/material.dart';

class AddCardOptionsBloc extends Bloc<AddCardOptionEvent, AddCardOptionState> {
  AddCardOptionsBloc(AddCardOptionState initialState) : super(initialState) {
    on<AddCardOptionInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      AddCardOptionInitialEvent event,
      Emitter<AddCardOptionState> emit,
      ) async {
    emit(state.copyWith(
      cardNumberController: TextEditingController(),
      cvvTwoController: TextEditingController(),
      nameController: TextEditingController(),
    ));

    emit(state.copyWith(
      addCardOptionModelObj: state.addCardOptionModelObj?.copyWith(
        dropdownItemList: fillDropdownItemList(),
        dropdownItemList: fillDropdownItemList(),
      ),
    ));
  }

  List<SelectionPopupModel> fillDropdownItemList() {
    return [
      SelectionPopupModel(
        id: 1,
        isSelected: true,
        title: 'Item One',
      ),
      SelectionPopupModel(
        id: 2,
        title: 'Item Two',
      ),
      SelectionPopupModel(
        id: 3,
        title: 'Item Three',
      ),
    ];
  }
}

class SelectionPopupModel {
  final int id;
  final bool isSelected;
  final String title;

  SelectionPopupModel({
    required this.id,
    this.isSelected = false,
    required this.title,
  });
}