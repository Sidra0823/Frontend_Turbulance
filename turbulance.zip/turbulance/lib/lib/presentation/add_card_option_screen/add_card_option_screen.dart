import 'package:flutter/material.dart';
import 'package:flutter_app/core/app_export.dart';
import 'package:flutter_app/widgets/custom_elevated_button.dart';

class PaymentOptionsScreen extends StatelessWidget {
  const PaymentOptionsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: AppBar(
        backgroundColor: appTheme.black900,
        title: Text(
          "Payment Options",
          style: TextStyle(color: appTheme.white),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: appTheme.white),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 12.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Choose Your Payment Method",
              style: TextStyle(
                fontSize: 20.sp,
                fontWeight: FontWeight.bold,
                color: appTheme.white,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 24.h),

            // Apple Pay Button
            CustomElevatedButton(
              height: 50.h,
              text: "Pay with Apple Pay",
              icon: Icon(Icons.apple, color: appTheme.white, size: 24.h),
              buttonStyle: CustomButtonStyles.fillDeepPurpleEa,
              buttonTextStyle: TextStyle(
                fontSize: 16.sp,
                color: appTheme.white,
                fontWeight: FontWeight.w600,
              ),
              onPressed: () {
                // Handle Apple Pay logic here
                _handleApplePay(context);
              },
            ),

            SizedBox(height: 16.h),

            // PayPal Button
            CustomElevatedButton(
              height: 50.h,
              text: "Pay with PayPal",
              icon: Image.asset(
                "assets/images/paypal_logo.png",
                height: 24.h,
                width: 24.h,
              ),
              buttonStyle: CustomButtonStyles.fillPrimary,
              buttonTextStyle: TextStyle(
                fontSize: 16.sp,
                color: appTheme.white,
                fontWeight: FontWeight.w600,
              ),
              onPressed: () {
                // Handle PayPal logic here
                _handlePayPal(context);
              },
            ),

            Spacer(),

            // Additional info
            Text(
              "Secure payments powered by Apple Pay and PayPal.",
              style: TextStyle(
                fontSize: 14.sp,
                color: appTheme.gray300,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  void _handleApplePay(BuildContext context) {
    // Add logic for Apple Pay integration
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Apple Pay"),
        content: Text("Apple Pay processing is not implemented yet."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  void _handlePayPal(BuildContext context) {
    // Add logic for PayPal integration
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("PayPal"),
        content: Text("PayPal processing is not implemented yet."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }
}