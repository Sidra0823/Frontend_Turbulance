part of 'iphone_14_15_pro_max_ninetytwo_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetytwo in the application.
class Iphone1415ProMaxNinetytwoState extends Equatable {
  final Iphone1415ProMaxNinetytwoModel? iphone1415ProMaxNinetytwoModelobj;

  Iphone1415ProMaxNinetytwoState({this.iphone1415ProMaxNinetytwoModelobj});

  @override
  List<Object?> get props => [iphone1415ProMaxNinetytwoModelobj];

  Iphone1415ProMaxNinetytwoState copyWith({Iphone1415ProMaxNinetytwoModel? iphone1415ProMaxNinetytwoModelobj}) {
    return Iphone1415ProMaxNinetytwoState(
      iphone1415ProMaxNinetytwoModelobj: iphone1415ProMaxNinetytwoModelobj ?? this.iphone1415ProMaxNinetytwoModelobj,
    );
  }
}
