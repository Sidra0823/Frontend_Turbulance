import 'package:equatable/equatable.dart';
import '../models/iphone_14_15_pro_max_ninetytwo_model.dart';

part 'iphone_14_15_pro_max_ninetytwo_event.dart';
part 'iphone_14_15_pro_max_ninetytwo_state.dart';

/// A bloc that manages the state of an Iphone1415ProMaxNinetytwo according to the event dispatched to it.
class Iphone1415ProMaxNinetytwoBloc extends Bloc<Iphone1415ProMaxNinetytwoEvent, Iphone1415ProMaxNinetytwoState> {
  Iphone1415ProMaxNinetytwoBloc(Iphone1415ProMaxNinetytwoState initialState) : super(initialState) {
    on<Iphone1415ProMaxNinetytwoInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      Iphone1415ProMaxNinetytwoInitialEvent event,
      Emitter<Iphone1415ProMaxNinetytwoState> emit,
      ) async {
    // Implement initialization logic if needed
  }
}
