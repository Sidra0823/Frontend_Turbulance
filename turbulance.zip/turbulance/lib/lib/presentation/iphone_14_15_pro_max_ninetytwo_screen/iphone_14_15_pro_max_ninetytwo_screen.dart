import 'package:flutter/material.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/iphone_14_15_pro_max_ninetytwo_bloc.dart';
import 'models/iphone_14_15_pro_max_ninetytwo_model.dart';

class Iphone1415ProMaxNinetytwoScreen extends StatelessWidget {
  const Iphone1415ProMaxNinetytwoScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxNinetytwoBloc>(
      create: (context) => Iphone1415ProMaxNinetytwoBloc(
        Iphone1415ProMaxNinetytwoState(
          iphone1415ProMaxNinetytwoModelobj: Iphone1415ProMaxNinetytwoModel(),
        )..add(Iphone1415ProMaxNinetytwoInitialEvent()),
      ),
      child: Iphone1415ProMaxNinetytwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<Iphone1415ProMaxNinetytwoBloc, Iphone1415ProMaxNinetytwoState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black908,
          body: SafeArea(
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.only(left: 44.h, top: 216.h, right: 44.h),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Text(
                    "msg_trust_this_browser".tr,
                    style: CustomTextStyles.headlineSmallRobotoSemiBold,
                  ),
                  SizedBox(height: 10.h),
                  Text(
                    "msg_should_you_chose".tr,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    textAlign: TextAlign.center,
                    style: CustomTextStyles.bodyMediumRoboto.copyWith(height: 1.29),
                  ),
                  SizedBox(height: 10.h),
                  Container(
                    width: double.infinity,
                    margin: EdgeInsets.only(left: 6.h),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CustomElevatedButton(
                          height: 32.h,
                          width: 86.h,
                          text: "lbl_not_now".tr,
                          buttonStyle: CustomButtonStyles.fillLightBlueTL16,
                          buttonTextStyle: CustomTextStyles.bodyLargeRoboto_4,
                        ),
                        Spacer(),
                        CustomElevatedButton(
                          height: 32.h,
                          width: 108.h,
                          text: "lbl_do_not_trust".tr,
                          buttonStyle: CustomButtonStyles.fillLightBlueTL16,
                          buttonTextStyle: CustomTextStyles.bodyLargeRoboto_4,
                        ),
                        CustomElevatedButton(
                          height: 32.h,
                          width: 60.h,
                          text: "lbl_trust".tr,
                          margin: EdgeInsets.only(left: 8.h),
                          buttonStyle: CustomButtonStyles.fillonPrimary,
                          buttonTextStyle: CustomTextStyles.bodyLargeRobotoLightBlue700,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
