import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_ninetytwo_screen],
/// and is typically used to hold data passed between different parts of the application.
class Iphone1415ProMaxNinetytwoModel extends Equatable {
  Iphone1415ProMaxNinetytwoModel();

  Iphone1415ProMaxNinetytwoModel copyWith() {
    return Iphone1415ProMaxNinetytwoModel();
  }

  @override
  List<Object?> get props => [];
}
