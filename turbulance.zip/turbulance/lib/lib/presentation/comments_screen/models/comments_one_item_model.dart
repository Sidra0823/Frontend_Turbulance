import 'package:equatable/equatable.dart';

class CommentsOneItemModel extends Equatable {
  final String? selenaOne;
  final String? selenaTwo;
  final String? time;
  final String? awesomeEdward;
  final String? timeZone;
  final String? reply;
  final String? id;

  CommentsOneItemModel({
    this.selenaOne,
    this.selenaTwo,
    this.time,
    this.awesomeEdward,
    this.timeZone,
    this.reply,
    this.id,
  });

  CommentsOneItemModel copyWith({
    String? selenaOne,
    String? selenaTwo,
    String? time,
    String? awesomeEdward,
    String? timeZone,
    String? reply,
    String? id,
  }) {
    return CommentsOneItemModel(
      selenaOne: selenaOne ?? this.selenaOne,
      selenaTwo: selenaTwo ?? this.selenaTwo,
      time: time ?? this.time,
      awesomeEdward: awesomeEdward ?? this.awesomeEdward,
      timeZone: timeZone ?? this.timeZone,
      reply: reply ?? this.reply,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [selenaOne, selenaTwo, time, awesomeEdward, timeZone, reply, id];
}
