import 'package:equatable/equatable.dart';
import 'comments_one_item_model.dart';

class CommentsModel extends Equatable {
  final List<CommentsOneItemModel> commentsOneItemList;

  CommentsModel({this.commentsOneItemList = const []});

  CommentsModel copyWith({
    List<CommentsOneItemModel>? commentsOneItemList,
  }) {
    return CommentsModel(
      commentsOneItemList: commentsOneItemList ?? this.commentsOneItemList,
    );
  }

  @override
  List<Object?> get props => [commentsOneItemList];
}
