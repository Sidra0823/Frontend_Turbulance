import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/comments_model.dart';
import '../models/comments_one_item_model.dart';

part 'comments_event.dart';
part 'comments_state.dart';

class CommentsBloc extends Bloc<CommentsEvent, CommentsState> {
  CommentsBloc(CommentsState initialState) : super(initialState) {
    on<CommentsInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(CommentsInitialEvent event, Emitter<CommentsState> emit) async {
    emit(state.copyWith(
      pinViewController: TextEditingController(),
      commentsModelobj: state.commentsModelobj?.copyWith(
        commentsOneItemList: _fillCommentsOneItemList(),
      ),
    ));
  }

  List<CommentsOneItemModel> _fillCommentsOneItemList() {
    return [
      CommentsOneItemModel(
        selenaOne: ImageConstant.imgDownload4730x30,
        selenaTwo: "Selena",
        time: "20min ago",
        awesomeEdward: "Awesome Edward, remember that five tips for",
        timeZone: "low cost holidays I sent you?",
        reply: "Reply",
      ),
      // Add other items as needed...
    ];
  }
}
