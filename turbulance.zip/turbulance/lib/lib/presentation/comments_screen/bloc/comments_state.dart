part of 'comments_bloc.dart';

class CommentsState extends Equatable {
  final TextEditingController? pinViewController;
  final CommentsModel? commentsModelobj;

  CommentsState({this.pinViewController, this.commentsModelobj});

  @override
  List<Object?> get props => [pinViewController, commentsModelobj];

  CommentsState copyWith({
    TextEditingController? pinViewController,
    CommentsModel? commentsModelobj,
  }) {
    return CommentsState(
      pinViewController: pinViewController ?? this.pinViewController,
      commentsModelobj: commentsModelobj ?? this.commentsModelobj,
    );
  }
}
