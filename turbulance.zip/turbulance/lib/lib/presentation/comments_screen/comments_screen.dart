import 'package:flutter/material.dart';
import 'bloc/comment_bloc.dart';
import 'models/comment_model.dart';
import 'widgets/comment_one_item_widget.dart';
import 'models/comment_one_item_model.dart';

class CommentScreen extends StatelessWidget {
  const CommentScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<CommentBloc>(
      create: (context) => CommentBloc(CommentState(commentModelobj: CommentModel()))
        ..add(CommentInitialEvent()),
      child: CommentScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: buildAppBar(context),
      body: SafeArea(
        top: false,
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(left: 28.h, top: 10.h, right: 28.h),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "lbl_comments_398k".tr,
                style: theme.textTheme.titleLarge,
              ),
              SizedBox(height: 20.h),
              _buildCommentOne(context),
              SizedBox(height: 52.h),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget buildAppBar(BuildContext context) {
