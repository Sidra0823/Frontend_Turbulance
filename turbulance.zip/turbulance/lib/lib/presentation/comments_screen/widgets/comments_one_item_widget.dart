import 'package:flutter/material.dart';
import '../models/comments_one_item_model.dart';

class CommentOneItemWidget extends StatelessWidget {
  final CommentsOneItemModel commentsOneItemModel;

  CommentOneItemWidget(this.commentsOneItemModel, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      margin: EdgeInsets.only(right: 8.h),
      child: Column(
        children: [
          SizedBox(
            width: double.maxFinite,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomImageView(
                  imagePath: commentsOneItemModel.selenaOne!,
                  height: 30.h,
                  width: 30.h,
                  radius: BorderRadius.circular(10.h),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 10.h),
                  child: Text(
                    commentsOneItemModel.selenaTwo!,
                    style: CustomTextStyles.titleMediumBold,
                  ),
                ),
                Expanded(
                  child: PinCodeTextField(
                    appContext: context,
                    controller: pinViewController,
                    length: 1,
                    obscureText: true,
                    obscuringCharacter: '*',
                    keyboardType: TextInputType.number,
                    autoDismissKeyboard: true,
                    showCursor: false,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    enableActiveFill: true,
                    onChanged: (value) {
                      pinViewController?.text = value;
                    },
                    pinTheme: PinTheme(
                      fieldHeight: 12.h,
                      fieldWidth: 8.h,
                      shape: PinCodeFieldShape.circle,
                      selectedFillColor: appTheme.gray50001,
                      selectedColor: appTheme.gray50001,
                      activeFillColor: appTheme.gray50001,
                      activeColor: appTheme.gray50001,
                      inactiveFillColor: appTheme.gray50001,
                      inactiveColor: appTheme.gray50001,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
