import 'package:equatable/equatable.dart';
import 'listspacer_item_model.dart';

class BillingAndPaymentTwoModel extends Equatable {
  final List<ListSpacerItemModel> listSpacerItemList;

  BillingAndPaymentTwoModel({this.listSpacerItemList = const []});

  BillingAndPaymentTwoModel copyWith({List<ListSpacerItemModel>? listSpacerItemList}) {
    return BillingAndPaymentTwoModel(
      listSpacerItemList: listSpacerItemList ?? this.listSpacerItemList,
    );
  }

  @override
  List<Object?> get props => [listSpacerItemList];
}
