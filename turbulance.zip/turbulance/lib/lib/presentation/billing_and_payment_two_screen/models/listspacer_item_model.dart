import 'package:equatable/equatable.dart';

class ListSpacerItemModel extends Equatable {
  final String? weekly;
  final bool? checkmark;
  final String? id;

  ListSpacerItemModel({this.weekly, this.checkmark = false, this.id = ''});

  ListSpacerItemModel copyWith({String? weekly, bool? checkmark, String? id}) {
    return ListSpacerItemModel(
      weekly: weekly ?? this.weekly,
      checkmark: checkmark ?? this.checkmark,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [weekly, checkmark, id];
}
