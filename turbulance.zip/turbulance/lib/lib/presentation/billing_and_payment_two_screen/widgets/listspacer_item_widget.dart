import 'package:flutter/material.dart';
import '../models/listspacer_item_model.dart';

class ListSpacerItemWidget extends StatelessWidget {
  final ListSpacerItemModel listSpacerItemModelObj;
  final Function(bool)? changeCheckBox;

  const ListSpacerItemWidget(this.listSpacerItemModelObj, {Key? key, this.changeCheckBox}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 22.h, vertical: 10.h),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorders,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Spacer(flex: 44),
          CustomImageView(
            imagePath: ImageConstant.imgUserOnprimary30x30,
            height: 30.h,
            width: 32.h,
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: EdgeInsets.only(left: 24.h, top: 2.h),
              child: Text(
                listSpacerItemModelObj.weekly!,
                style: theme.textTheme.titleLarge,
              ),
            ),
          ),
          Spacer(flex: 55),
          CustomCheckboxButton(
            value: listSpacerItemModelObj.checkmark!,
            onChange: (value) {
              changeCheckBox?.call(value);
            },
          ),
        ],
      ),
    );
  }
}
