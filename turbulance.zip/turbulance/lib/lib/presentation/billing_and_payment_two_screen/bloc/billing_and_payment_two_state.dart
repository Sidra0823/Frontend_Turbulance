part of 'billing_and_payment_two_bloc.dart';

class BillingAndPaymentTwoState extends Equatable {
  final BillingAndPaymentTwoModel? billingAndPaymentTwoModelObj;

  BillingAndPaymentTwoState({this.billingAndPaymentTwoModelObj});

  @override
  List<Object?> get props => [billingAndPaymentTwoModelObj];

  BillingAndPaymentTwoState copyWith({BillingAndPaymentTwoModel? billingAndPaymentTwoModelObj}) {
    return BillingAndPaymentTwoState(
      billingAndPaymentTwoModelObj: billingAndPaymentTwoModelObj ?? this.billingAndPaymentTwoModelObj,
    );
  }
}
