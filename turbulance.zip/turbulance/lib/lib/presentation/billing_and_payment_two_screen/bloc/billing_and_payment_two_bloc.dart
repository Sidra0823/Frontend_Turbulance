import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/billing_and_payment_two_model.dart';
import '../models/listspacer_item_model.dart';

part 'billing_and_payment_two_event.dart';
part 'billing_and_payment_two_state.dart';

class BillingAndPaymentTwoBloc extends Bloc<BillingAndPaymentTwoEvent, BillingAndPaymentTwoState> {
  BillingAndPaymentTwoBloc(BillingAndPaymentTwoState initialState) : super(initialState);

  @override
  Stream<BillingAndPaymentTwoState> mapEventToState(BillingAndPaymentTwoEvent event) async* {
    if (event is BillingAndPaymentTwoInitialEvent) {
      yield* _onInitialize(event);
    }
  }

  Stream<BillingAndPaymentTwoState> _onInitialize(BillingAndPaymentTwoInitialEvent event) async* {
    yield state.copyWith(
      billingAndPaymentTwoModelObj: state.billingAndPaymentTwoModelObj?.copyWith(
        listSpacerItemList: fillListSpacerItemList(),
      ),
    );
  }

  List<ListSpacerItemModel> fillListSpacerItemList() {
    return [
      ListSpacerItemModel(weekly: "10 / Weekly"),
      ListSpacerItemModel(weekly: "30 / Monthly"),
    ];
  }
}
