part of 'billing_and_payment_two_bloc.dart';

abstract class BillingAndPaymentTwoEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class BillingAndPaymentTwoInitialEvent extends BillingAndPaymentTwoEvent {
  @override
  List<Object?> get props => [];
}
