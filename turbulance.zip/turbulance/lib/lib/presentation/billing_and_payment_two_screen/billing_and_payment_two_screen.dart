import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/billing_and_payment_two_bloc.dart';
import 'models/billing_and_payment_two_model.dart';
import 'models/listspacer_item_model.dart';
import 'widgets/listspacer_item_widget.dart';

class BillingAndPaymentTwoScreen extends StatelessWidget {
  const BillingAndPaymentTwoScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<BillingAndPaymentTwoBloc>(
      create: (context) => BillingAndPaymentTwoBloc(
        BillingAndPaymentTwoState(
          billingAndPaymentTwoModelObj: BillingAndPaymentTwoModel(),
        ),
      )..add(BillingAndPaymentTwoInitialEvent()),
      child: const BillingAndPaymentTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: buildAppBar(context),
      body: SafeArea(
        top: false,
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 34.h,
            top: 30.h,
            right: 34.h,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomImageView(
                    imagePath: ImageConstant.imgUserOnprimary30x30,
                    height: 44.h,
                    width: 44.h,
                  ),
                  SizedBox(width: 8.h),
                  Text(
                    "msg_billing_and_payments".tr,
                    style: theme.textTheme.headlineMedium,
                  ),
                ],
              ),
              SizedBox(height: 48.h),
              CustomImageView(
                imagePath: ImageConstant.imgProfilePicture80x80,
                height: 80.h,
                width: 82.h,
                radius: BorderRadius.circular(40.h),
              ),
              SizedBox(height: 18.h),
              Text(
                "lbl_turbulance".tr,
                style: theme.textTheme.headlineLarge,
              ),
              SizedBox(height: 44.h),
              _buildListSpacer(context),
              SizedBox(height: 246.h),
              CustomElevatedButton(
                height: 50.h,
                width: 150.h,
                text: "lbl_continue_to_buy".tr,
                buttonStyle: CustomButtonStyles.fillDeepPurpleEa,
                buttonTextStyle: CustomTextStyles.titleSmallNunito15,
              ),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowleftOne(context);
        },
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "lbl_billing_and_payment".tr,
      ),
    );
  }

  Widget _buildListSpacer(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 12.h),
      child: BlocSelector<BillingAndPaymentTwoBloc, BillingAndPaymentTwoState, BillingAndPaymentTwoModel?>(
        selector: (state) => state.billingAndPaymentTwoModelObj,
        builder: (context, billingAndPaymentTwoModelObj) {
          return ListView.separated(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (context, index) {
              return SizedBox(height: 4.h);
            },
            itemCount: billingAndPaymentTwoModelObj?.listSpacerItemList.length ?? 0,
            itemBuilder: (context, index) {
              ListSpacerItemModel model = billingAndPaymentTwoModelObj?.listSpacerItemList[index] ?? ListSpacerItemModel();
              return ListSpacerItemWidget(
                model,
              );
            },
          );
        },
      ),
    );
  }

  void onTapArrowleftOne(BuildContext context) {
    NavigatorService.goBack();
  }
}
