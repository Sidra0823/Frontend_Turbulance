import 'package:flutter/material.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import 'bloc/audio_call_bloc.dart';
import 'models/audio_call_model.dart';

// ignore_for_file: must_be_immutable

class AudioCallScreen extends StatelessWidget {
  AudioCallScreen({Key? key}) : super(key: key);

  // GlobalKey for navigation
  final GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<AudioCallBloc>(
      create: (context) => AudioCallBloc(AudioCallState(
        audioCallModelobj: AudioCallModel(),
      ))..add(AudioCallInitialEvent()),
      child: AudioCallScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AudioCallBloc, AudioCallState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          appBar: _buildAppBar(context),
          body: SafeArea(
            top: false,
            child: SizedBox(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Expanded(
                    child: Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.only(top: 26.h),
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        children: [
                          CustomImageView(
                            imagePath: ImageConstant.imgProfilePicture100x100,
                            height: 100.h,
                            width: 102.h,
                            radius: BorderRadius.circular(50.h),
                          ),
                          SizedBox(height: 20.h),
                          Text(
                            "lbl_grace".tr,
                            style: CustomTextStyles.headlineSmallRoboto25,
                          ),
                          Align(
                            alignment: Alignment.centerRight,
                            child: Padding(
                              padding: EdgeInsets.only(right: 12.h),
                              child: Text(
                                "lbl_ringing".tr,
                                style: theme.textTheme.bodyLarge,
                              ),
                            ),
                          ),
                          SizedBox(height: 16.h),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          bottomNavigationBar: _buildBottomBar(context),
        );
      },
    );
  }

  // AppBar Builder
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 48.h,
      leadingWidth: 55.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        height: 36.h,
        margin: EdgeInsets.only(left: 15.h),
        onTap: () => _onTapArrowLeft(context),
      ),
      actions: [
        AppbarTrailingIconButton(
          imagePath: ImageConstant.imgcloseOnprimary,
          margin: EdgeInsets.only(right: 29.h),
        ),
      ],
    );
  }

  // Bottom Navigation Bar Builder
  Widget _buildBottomBar(BuildContext context) {
    return SizedBox(
      width: double.maxFinite,
      child: CustomBottomBar(
        onChanged: (BottomBarEnum type) {
          Navigator.pushNamed(
            navigatorKey.currentContext!,
            _getCurrentRoute(type),
          );
        },
      ),
    );
  }

  // Route Handling based on BottomBar action
  String _getCurrentRoute(BottomBarEnum type) {
    switch (type) {
      case BottomBarEnum.Home:
        return AppRoutes.postSomethingInitialPage;
      case BottomBarEnum.Calendar:
        return "/";
      case BottomBarEnum.Close:
        return AppRoutes.videoCallPage;
      case BottomBarEnum.Useronprimary:
        return "/";
      case BottomBarEnum.Lockonprimary:
        return AppRoutes.profilePagePhotoPostPage;
      default:
        return "/";
    }
  }

  // Navigates to the previous screen
  void _onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
