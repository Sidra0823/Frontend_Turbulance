import 'package:equatable/equatable.dart';

import '../models/audio_call_model.dart';

part 'audio_call_event.dart';
part 'audio_call_state.dart';

/// A bloc that manages the state of an AudioCall according to the event that is dispatched to it.
class AudioCallBloc extends Bloc<AudioCallEvent, AudioCallState> {
  AudioCallBloc(AudioCallState initialState) : super(initialState) {
    on<AudioCallInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      AudioCallInitialEvent event,
      Emitter<AudioCallState> emit,
      ) async {
    // Your initialization logic here
  }
}
