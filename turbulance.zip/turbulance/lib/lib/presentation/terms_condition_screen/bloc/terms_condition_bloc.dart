import 'package:equatable/equatable.dart';
import '../models/terms_condition_model.dart';

part 'terms_condition_event.dart';
part 'terms_condition_state.dart';

/// A bloc that manages the state of TermsCondition according to the event that is dispatched to it.
class TermsConditionBloc extends Bloc<TermsConditionEvent, TermsConditionState> {
  // Constructor to initialize the bloc with an initial state.
  TermsConditionBloc(TermsConditionState initialState) : super(initialState) {
    on<TermsConditionInitialEvent>(_onInitialize);
  }

  // Event handler when the TermsConditionInitialEvent is added to the bloc.
  Future<void> _onInitialize(
      TermsConditionInitialEvent event,
      Emitter<TermsConditionState> emit,
      ) async {
    // You can add the logic to initialize the terms and conditions here.
    // Example:
    // Fetch the terms and conditions from a service or local storage.
    // And then update the state.

    final termsConditionModel = TermsConditionModel(terms: "Initial Terms and Conditions");
    emit(state.copyWith(termsConditionModel: termsConditionModel));
  }
}
