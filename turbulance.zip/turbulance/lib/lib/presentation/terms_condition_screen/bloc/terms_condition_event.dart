part of 'terms_condition_bloc.dart';

/// Abstract class for all events that can be dispatched from the TermsCondition widget.
/// Events must be immutable and implement the [Equatable] interface.

class TermsConditionEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the TermsCondition widget is first created.
class TermsConditionInitialEvent extends TermsConditionEvent {
  @override
  List<Object?> get props => [];
}
