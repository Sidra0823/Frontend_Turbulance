import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [terms_condition_screen],
/// and is typically used to hold data that is passed between different parts of the application.

class TermsConditionModel extends Equatable {
  TermsConditionModel();

  TermsConditionModel copyWith() {
    return TermsConditionModel();
  }

  @override
  List<Object?> get props => [];
}
