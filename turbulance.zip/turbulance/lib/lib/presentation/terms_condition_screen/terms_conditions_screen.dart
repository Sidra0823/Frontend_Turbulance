import 'package:flutter/material.dart';

import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_subtitle_eight.dart';
import '../../widgets/app_bar/appbar_subtitle_ten.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_outlined_button.dart';

import 'bloc/terms_condition_bloc.dart';
import 'models/terms_condition_model.dart';

class TermsConditionScreen extends StatelessWidget {
  const TermsConditionScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<TermsConditionBloc>(
      create: (context) => TermsConditionBloc(TermsConditionState(termsConditionModelObj: TermsConditionModel()))
        ..add(TermsConditionInitialEvent()),
      child: const TermsConditionScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<TermsConditionBloc, TermsConditionState>(
      builder: (context, state) {
        return Scaffold(
          appBar: buildAppbar(context),
          body: SafeArea(
            top: false,
            child: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Container(
                  width: double.maxFinite,
                  padding: EdgeInsets.only(
                    left: 16.h,
                    top: 34.h,
                    right: 16.h,
                  ),
                  child: Column(
                    children: [
                      RichText(
                        text: TextSpan(
                          children: [
                            TextSpan(
                              text: "msg_welcome_to_turbulance".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_1_subscription_based".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_1_1_subscription".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_3_user_responsibilities".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_3_1_account_creation".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_4_intellectual".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_4_1_ownership".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_5_termination_and".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_5_1_termination".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_6_disclaimers_and".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_6_1_disclaimer".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_7_dispute_resolution".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_7_1_arbitration".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_8_california_privacy".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_8_1_california".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_9_changes_to_terms".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_we_reserve_the_right".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "lbl_10_contact_us".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_if_you_have_any".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_11_copyright_and".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                            TextSpan(
                              text: "msg_11_1_intellectual".tr,
                              style: CustomTextStyles.titleSmallNunitoExtraBold,
                            ),
                            TextSpan(
                              text: "msg_counter_notice_if".tr,
                              style: CustomTextStyles.titleMedium16,
                            ),
                          ],
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          maxLines: 304,
                        ),
                      ),
                      SizedBox(height: 56.h),
                      Container(
                        width: double.maxFinite,
                        margin: EdgeInsets.only(
                          left: 30.h,
                          right: 46.h,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CustomIconButton(
                              height: 30.h,
                              width: 30.h,
                              padding: EdgeInsets.all(4.h),
                              decoration: IconButtonStyleHelper.fillLightBlue,
                              child: CustomImageView(
                                imagePath: ImageConstant.imgCheckmark,
                              ),
                            ),
                            CustomOutlinedButton(
                              height: 50.h,
                              width: 100.h,
                              text: "lbl_decline".tr,
                              buttonStyle: CustomButtonStyles.outlineOnPrimary,
                              buttonTextStyle: CustomTextStyles.bodyLargeInter,
                            ),
                            CustomElevatedButton(
                              height: 50.h,
                              width: 100.h,
                              text: "lbl_accept".tr,
                              buttonStyle: CustomButtonStyles.fillLightBlue,
                              buttonTextStyle: CustomTextStyles.bodyLargeInter,
                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 8.h)
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 78.h,
      shape: Border(
        bottom: BorderSide(
          color: theme.colorScheme.onPrimary,
        ),
        width: 1.h,
      ),
      leadingWidth: 87.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgFile,
        height: 42.h,
        margin: EdgeInsets.only(left: 47.h),
      ),
      centerTitle: true,
      title: Column(
        children: [
          AppbarSubtitleEight(
            text: "msg_terms_and_conditions".tr,
          ),
          AppbarSubtitleTen(
            text: "msg_effective_date".tr,
            margin: EdgeInsets.symmetric(horizontal: 27.h),
          ),
        ],
      ),
      styleType: Style.bgFillOnPrimary,
    );
  }
}
