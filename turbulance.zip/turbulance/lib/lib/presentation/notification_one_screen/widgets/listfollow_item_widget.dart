import 'package:flutter/material.dart';
import '../models/listfollow_item_model.dart';

class ListFollowItemWidget extends StatelessWidget {
  const ListFollowItemWidget(this.listFollowItemModelObj, {Key? key}) : super(key: key);

  final ListFollowItemModel listFollowItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 8),
      child: Row(
        children: [
          CircleAvatar(
            radius: 26,
            backgroundImage: AssetImage(ImageConstant.imgUntitledDesign54x54),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(listFollowItemModelObj.followRequests ?? ""),
                Text(listFollowItemModelObj.george500 ?? ""),
              ],
            ),
          ),
          Icon(Icons.arrow_forward),
        ],
      ),
    );
  }
}
