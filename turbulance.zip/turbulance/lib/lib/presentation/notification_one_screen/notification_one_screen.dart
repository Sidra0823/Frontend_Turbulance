import 'package:flutter/material.dart';
import 'bloc/notification_one_bloc.dart';
import 'widgets/listfollow_item_widget.dart';

class NotificationOneScreen extends StatelessWidget {
  const NotificationOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => NotificationOneBloc(
        NotificationOneState(notificationOneModelObj: NotificationOneModel()),
      )..add(NotificationOneInitialEvent()),
      child: const NotificationOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Notifications"),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: BlocBuilder<NotificationOneBloc, NotificationOneState>(
        builder: (context, state) {
          final notificationOneModel = state.notificationOneModelObj;

          if (notificationOneModel == null || notificationOneModel.listFollowItemList.isEmpty) {
            return Center(child: Text("No notifications available."));
          }

          return ListView.separated(
            itemCount: notificationOneModel.listFollowItemList.length,
            itemBuilder: (context, index) {
              return ListFollowItemWidget(notificationOneModel.listFollowItemList[index]);
            },
            separatorBuilder: (context, index) => Divider(),
          );
        },
      ),
    );
  }
}
