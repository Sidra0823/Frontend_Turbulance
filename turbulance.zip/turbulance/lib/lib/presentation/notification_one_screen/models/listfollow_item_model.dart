import 'package:equatable/equatable.dart';

/// This class is used in the `listfollow_item_widget` screen.
class ListFollowItemModel extends Equatable {
  ListFollowItemModel({this.followRequests, this.george500, this.id});

  final String? followRequests;
  final String? george500;
  final String? id;

  ListFollowItemModel copyWith({
    String? followRequests,
    String? george500,
    String? id,
  }) {
    return ListFollowItemModel(
      followRequests: followRequests ?? this.followRequests,
      george500: george500 ?? this.george500,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [followRequests, george500, id];
}
