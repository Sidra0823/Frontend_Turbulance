import 'package:equatable/equatable.dart';
import 'listfollow_item_model.dart';

/// This class defines the variables used in the `notification_one_screen`.
class NotificationOneModel extends Equatable {
  NotificationOneModel({this.listFollowItemList = const []});

  final List<ListFollowItemModel> listFollowItemList;

  NotificationOneModel copyWith({
    List<ListFollowItemModel>? listFollowItemList,
  }) {
    return NotificationOneModel(
      listFollowItemList: listFollowItemList ?? this.listFollowItemList,
    );
  }

  @override
  List<Object?> get props => [listFollowItemList];
}
