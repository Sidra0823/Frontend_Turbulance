part of 'notification_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the NotificationOne widget.
abstract class NotificationOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event dispatched when the NotificationOne widget is first created.
class NotificationOneInitialEvent extends NotificationOneEvent {}
