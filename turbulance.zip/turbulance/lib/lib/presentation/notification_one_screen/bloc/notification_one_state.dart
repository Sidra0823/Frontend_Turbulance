part of 'notification_one_bloc.dart';

/// Represents the state of NotificationOne in the application.
class NotificationOneState extends Equatable {
  NotificationOneState({this.notificationOneModelObj});

  final NotificationOneModel? notificationOneModelObj;

  NotificationOneState copyWith({
    NotificationOneModel? notificationOneModelObj,
  }) {
    return NotificationOneState(
      notificationOneModelObj: notificationOneModelObj ?? this.notificationOneModelObj,
    );
  }

  @override
  List<Object?> get props => [notificationOneModelObj];
}
