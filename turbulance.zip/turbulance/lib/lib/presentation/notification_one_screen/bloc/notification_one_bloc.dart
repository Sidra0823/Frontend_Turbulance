import 'package:equatable/equatable.dart';

import '../models/listfollow_item_model.dart';
import '../models/notification_one_model.dart';

part 'notification_one_event.dart';
part 'notification_one_state.dart';

/// A bloc that manages the state of a NotificationOne according to the event dispatched to it.
class NotificationOneBloc extends Bloc<NotificationOneEvent, NotificationOneState> {
  NotificationOneBloc(NotificationOneState initialState) : super(initialState) {
    on<NotificationOneInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      NotificationOneInitialEvent event, Emitter<NotificationOneState> emit) async {
    emit(
      state.copyWith(
        notificationOneModelObj: state.notificationOneModelObj?.copyWith(
          listFollowItemList: _fillListFollowItemList(),
        ),
      ),
    );
  }

  List<ListFollowItemModel> _fillListFollowItemList() {
    return List.generate(
      10,
          (index) => ListFollowItemModel(
        followRequests: "Follow Requests",
        george500: "George +500 others",
      ),
    );
  }
}
