import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/griddownload_item_model.dart';
import '../models/profile_page_photo_post_one_model.dart';
import '../models/scrollview_one_tab1_model.dart';

part 'profile_page_photo_post_one_event.dart';
part 'profile_page_photo_post_one_state.dart';

/// A bloc that manages the state of a ProfilePagePhotoPostOne according to the event that is dispatched to it.
class ProfilePagePhotoPostOneBloc
    extends Bloc<ProfilePagePhotoPostOneEvent, ProfilePagePhotoPostOneState> {
  ProfilePagePhotoPostOneBloc(ProfilePagePhotoPostOneState initialState)
      : super(initialState) {
    on<ProfilePagePhotoPostOneInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      ProfilePagePhotoPostOneInitialEvent event,
      Emitter<ProfilePagePhotoPostOneState> emit,
      ) async {
    emit(
      state.copyWith(
        scrollviewOneTab1ModelObj: state.scrollviewOneTab1ModelObj?.copyWith(
          griddownloadItemList: fillGriddownloadItemList(),
        ),
      ),
    );
  }

  List<GriddownloadItemModel> fillGriddownloadItemList() {
    return [
      GriddownloadItemModel(download: ImageConstant.imgImage25),
      GriddownloadItemModel(),
      GriddownloadItemModel(download: ImageConstant.imgDownload52),
      GriddownloadItemModel(download: ImageConstant.imgDownload54),
      GriddownloadItemModel(download: ImageConstant.imgDownload56),
      GriddownloadItemModel(download: ImageConstant.imgImage25),
      GriddownloadItemModel(download: ImageConstant.imgDownload60),
      GriddownloadItemModel(),
      GriddownloadItemModel(),
    ];
  }
}
