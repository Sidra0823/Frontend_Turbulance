part of 'profile_page_photo_post_one_bloc.dart';

/// Represents the state of ProfilePagePhotoPostOne in the application.
///
/// ignore_for_file: must_be_immutable
class ProfilePagePhotoPostOneState extends Equatable {
  ProfilePagePhotoPostOneState({
    this.scrollviewOneTab1ModelObj,
    this.profilePagePhotoPostOneModelObj,
  });

  ProfilePagePhotoPostOneModel? profilePagePhotoPostOneModelObj;
  ScrollviewOneTab1Model? scrollviewOneTab1ModelObj;

  @override
  List<Object?> get props => [scrollviewOneTab1ModelObj, profilePagePhotoPostOneModelObj];

  ProfilePagePhotoPostOneState copyWith({
    ScrollviewOneTab1Model? scrollviewOneTab1ModelObj,
    ProfilePagePhotoPostOneModel? profilePagePhotoPostOneModelObj,
  }) {
    return ProfilePagePhotoPostOneState(
      scrollviewOneTab1ModelObj: scrollviewOneTab1ModelObj ?? this.scrollviewOneTab1ModelObj,
      profilePagePhotoPostOneModelObj: profilePagePhotoPostOneModelObj ?? this.profilePagePhotoPostOneModelObj,
    );
  }
}
