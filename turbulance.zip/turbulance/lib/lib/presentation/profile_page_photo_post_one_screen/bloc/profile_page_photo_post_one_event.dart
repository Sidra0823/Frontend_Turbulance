part of 'profile_page_photo_post_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// ProfilePagePhotoPostOne widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class ProfilePagePhotoPostOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the ProfilePagePhotoPostOne widget is first created.
class ProfilePagePhotoPostOneInitialEvent extends ProfilePagePhotoPostOneEvent {
  @override
  List<Object?> get props => [];
}
