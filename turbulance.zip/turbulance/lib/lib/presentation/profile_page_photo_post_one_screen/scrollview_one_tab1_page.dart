import 'package:flutter/material.dart';
import 'package:responsive_grid_list/responsive_grid_list.dart';
import 'bloc/profile_page_photo_post_one_bloc.dart';
import 'models/griddownload_item_model.dart';
import 'models/scrollview_one_tab1_model.dart';
import 'widgets/griddownload_item_widget.dart';

class ScrollviewOneTab1Page extends StatefulWidget {
  const ScrollviewOneTab1Page({Key? key}) : super(key: key);

  @override
  ScrollviewOneTab1PageState createState() => ScrollviewOneTab1PageState();

  static Widget builder(BuildContext context) {
    return BlocProvider<ProfilePagePhotoPostOneBloc>(
      create: (context) => ProfilePagePhotoPostOneBloc(
        ProfilePagePhotoPostOneState(
          scrollviewOneTab1ModelObj: ScrollviewOneTab1Model(),
        ),
      )..add(ProfilePagePhotoPostOneInitialEvent()),
      child: ScrollviewOneTab1Page(),
    );
  }
}

class ScrollviewOneTab1PageState extends State<ScrollviewOneTab1Page> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      primary: true,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 10.h, vertical: 8.h),
        child: Column(
          children: [
            SizedBox(height: 12.h),
            Padding(
              padding: EdgeInsets.only(left: 4.h),
              child: BlocSelector<ProfilePagePhotoPostOneBloc,
                  ProfilePagePhotoPostOneState, ScrollviewOneTab1Model?>(
                selector: (state) => state.scrollviewOneTab1ModelObj,
                builder: (context, scrollviewOneTab1ModelObj) {
                  return ResponsiveGridListBuilder(
                    minItemWidth: 1,
                    minItemsPerRow: 3,
                    maxItemsPerRow: 3,
                    horizontalGridSpacing: 8.h,
                    verticalGridSpacing: 8.h,
                    builder: (context, items) => ListView(
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                      physics: NeverScrollableScrollPhysics(),
                      children: items,
                    ),
                    gridItems: List.generate(
                      scrollviewOneTab1ModelObj?.griddownloadItemList.length ?? 0,
                          (index) {
                        GriddownloadItemModel model = scrollviewOneTab1ModelObj
                            ?.griddownloadItemList[index] ??
                            GriddownloadItemModel();
                        return GriddownloadItemWidget(model);
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
