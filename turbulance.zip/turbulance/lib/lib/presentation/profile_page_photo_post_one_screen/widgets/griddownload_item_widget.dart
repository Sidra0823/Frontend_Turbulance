import 'package:flutter/material.dart';
import '../models/griddownload_item_model.dart';

// ignore_for_file: must_be_immutable
class GriddownloadItemWidget extends StatelessWidget {
  final GriddownloadItemModel griddownloadItemModelObj;

  GriddownloadItemWidget(this.griddownloadItemModelObj, {Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomImageView(
      imagePath: griddownloadItemModelObj.download!,
      height: 124.h,
      width: 124.h,
      radius: BorderRadius.circular(14.h),
    );
  }
}
