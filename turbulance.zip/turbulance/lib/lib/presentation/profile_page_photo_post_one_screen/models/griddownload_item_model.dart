import 'package:equatable/equatable.dart';

/// This class is used in the [griddownload_item_widget] screen.
/// ignore_for_file: must_be_immutable
class GriddownloadItemModel extends Equatable {
  GriddownloadItemModel({this.download, this.id});

  String? download;
  String? id;

  GriddownloadItemModel copyWith({
    String? download,
    String? id,
  }) {
    return GriddownloadItemModel(
      download: download ?? this.download,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [download, id];
}
