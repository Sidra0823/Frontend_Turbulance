import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [profile_page_photo_post_one_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class ProfilePagePhotoPostOneModel extends Equatable {
  ProfilePagePhotoPostOneModel();

  ProfilePagePhotoPostOneModel copyWith() {
    return ProfilePagePhotoPostOneModel();
  }

  @override
  List<Object?> get props => [];
}
