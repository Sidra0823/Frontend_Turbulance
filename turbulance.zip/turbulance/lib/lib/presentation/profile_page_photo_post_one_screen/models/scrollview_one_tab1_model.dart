import 'package:equatable/equatable.dart';
import 'griddownload_item_model.dart';

/// This class is used in the [scrollview_one_tabi_page] screen.
/// ignore_for_file: must_be_immutable
class ScrollviewOneTab1Model extends Equatable {
  ScrollviewOneTab1Model({this.griddownloadItemList = const []});

  List<GriddownloadItemModel> griddownloadItemList;

  ScrollviewOneTab1Model copyWith({
    List<GriddownloadItemModel>? griddownloadItemList,
  }) {
    return ScrollviewOneTab1Model(
      griddownloadItemList: griddownloadItemList ?? this.griddownloadItemList,
    );
  }

  @override
  List<Object?> get props => [griddownloadItemList];
}
