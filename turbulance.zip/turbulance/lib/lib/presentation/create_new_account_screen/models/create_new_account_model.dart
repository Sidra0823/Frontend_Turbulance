import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';

/// Holds data used in the create_new_account_screen.
class CreateNewAccountModel extends Equatable {
  final List<SelectionPopupModel> dropdownItemList;

  CreateNewAccountModel({this.dropdownItemList = const []});

  CreateNewAccountModel copyWith({List<SelectionPopupModel>? dropdownItemList}) {
    return CreateNewAccountModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
    );
  }

  @override
  List<Object?> get props => [dropdownItemList];
}
