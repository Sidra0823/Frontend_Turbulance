import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'bloc/create_new_account_bloc.dart';

class CreateNewAccountScreen extends StatelessWidget {
  CreateNewAccountScreen({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => CreateNewAccountBloc(CreateNewAccountState())
        ..add(CreateNewAccountInitialEvent()),
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                // AppBar, Form Fields, Buttons, etc.
              ],
            ),
          ),
        ),
      ),
    );
  }
}
