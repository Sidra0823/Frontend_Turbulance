import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/create_new_account_model.dart';

part 'create_new_account_event.dart';
part 'create_new_account_state.dart';

/// A bloc that manages the state of a CreateNewAccount.
class CreateNewAccountBloc extends Bloc<CreateNewAccountEvent, CreateNewAccountState> {
  CreateNewAccountBloc(CreateNewAccountState initialState) : super(initialState) {
    on<CreateNewAccountInitialEvent>(_onInitialize);
    on<OnSelectedEvent>(_onSelected);
    on<ChangePasswordVisibilityEvent>(_changePasswordVisibility);
  }

  Future<void> _onInitialize(
      CreateNewAccountInitialEvent event, Emitter<CreateNewAccountState> emit) async {
    emit(state.copyWith(
      nameController: TextEditingController(),
      emailController: TextEditingController(),
      passwordController: TextEditingController(),
      isShowPassword: true,
      createNewAccountModel: CreateNewAccountModel(dropdownItemList: _fillDropdownItemList()),
    ));
  }

  void _onSelected(OnSelectedEvent event, Emitter<CreateNewAccountState> emit) {
    emit(state.copyWith(selectedDropDownValue: event.value));
  }

  void _changePasswordVisibility(
      ChangePasswordVisibilityEvent event, Emitter<CreateNewAccountState> emit) {
    emit(state.copyWith(isShowPassword: event.value));
  }

  List<SelectionPopupModel> _fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
