part of 'create_new_account_bloc.dart';

/// Abstract class for all events.
abstract class CreateNewAccountEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class CreateNewAccountInitialEvent extends CreateNewAccountEvent {}

class OnSelectedEvent extends CreateNewAccountEvent {
  final SelectionPopupModel value;

  OnSelectedEvent({required this.value});

  @override
  List<Object?> get props => [value];
}

class ChangePasswordVisibilityEvent extends CreateNewAccountEvent {
  final bool value;

  ChangePasswordVisibilityEvent({required this.value});

  @override
  List<Object?> get props => [value];
}
