part of 'create_new_account_bloc.dart';

/// Represents the state of CreateNewAccount.
class CreateNewAccountState extends Equatable {
  final TextEditingController? nameController;
  final TextEditingController? emailController;
  final TextEditingController? passwordController;
  final SelectionPopupModel? selectedDropDownValue;
  final CreateNewAccountModel? createNewAccountModel;
  final bool isShowPassword;

  CreateNewAccountState({
    this.nameController,
    this.emailController,
    this.passwordController,
    this.selectedDropDownValue,
    this.isShowPassword = true,
    this.createNewAccountModel,
  });

  @override
  List<Object?> get props => [
    nameController,
    emailController,
    passwordController,
    selectedDropDownValue,
    isShowPassword,
    createNewAccountModel,
  ];

  CreateNewAccountState copyWith({
    TextEditingController? nameController,
    TextEditingController? emailController,
    TextEditingController? passwordController,
    SelectionPopupModel? selectedDropDownValue,
    bool? isShowPassword,
    CreateNewAccountModel? createNewAccountModel,
  }) {
    return CreateNewAccountState(
      nameController: nameController ?? this.nameController,
      emailController: emailController ?? this.emailController,
      passwordController: passwordController ?? this.passwordController,
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      isShowPassword: isShowPassword ?? this.isShowPassword,
      createNewAccountModel: createNewAccountModel ?? this.createNewAccountModel,
    );
  }
}
