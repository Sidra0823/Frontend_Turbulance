import 'package:equatable/equatable.dart';

class ListmyStoryItemModel extends Equatable {
  final String? myStoryOne;
  final String? myStoryThree;
  final String? iconOne;
  final String? mystory;
  final String? id;

  ListmyStoryItemModel({
    this.myStoryOne,
    this.myStoryThree,
    this.iconOne,
    this.mystory,
    this.id,
  }) : myStoryOne = myStoryOne ?? ImageConstant.imgUntitledDesign64x64,
        myStoryThree = myStoryThree ?? ImageConstant.imgUnnamed1,
        iconOne = iconOne ?? ImageConstant.imgIconOnprimary,
        mystory = mystory ?? "My Story",
        id = id ?? "";

  ListmyStoryItemModel copyWith({
    String? myStoryOne,
    String? myStoryThree,
    String? iconOne,
    String? mystory,
    String? id,
  }) {
    return ListmyStoryItemModel(
      myStoryOne: myStoryOne ?? this.myStoryOne,
      myStoryThree: myStoryThree ?? this.myStoryThree,
      iconOne: iconOne ?? this.iconOne,
      mystory: mystory ?? this.mystory,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [myStoryOne, myStoryThree, iconOne, mystory, id];
}
