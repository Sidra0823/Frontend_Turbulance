import 'package:equatable/equatable.dart';
import 'listmy_story_item_model.dart';

class HomeGoToProfileModel extends Equatable {
  final List<ListmyStoryItemModel> listmyStoryItemList;

  HomeGoToProfileModel({this.listmyStoryItemList = const []});

  HomeGoToProfileModel copyWith({
    List<ListmyStoryItemModel>? listmyStoryItemList,
  }) {
    return HomeGoToProfileModel(
      listmyStoryItemList: listmyStoryItemList ?? this.listmyStoryItemList,
    );
  }

  @override
  List<Object?> get props => [listmyStoryItemList];
}
