import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/home_go_to_profile_model.dart';
import '../models/listmy_story_item_model.dart';

part 'home_go_to_profile_event.dart';
part 'home_go_to_profile_state.dart';

class HomeGoToProfileBloc extends Bloc<HomeGoToProfileEvent, HomeGoToProfileState> {
  HomeGoToProfileBloc(HomeGoToProfileState initialState) : super(initialState);

  @override
  Stream<HomeGoToProfileState> mapEventToState(HomeGoToProfileEvent event) async* {
    if (event is HomeGoToProfileInitialEvent) {
      yield* _onInitialize(event);
    }
  }

  Stream<HomeGoToProfileState> _onInitialize(HomeGoToProfileInitialEvent event) async* {
    yield state.copyWith(
      pinViewController: TextEditingController(),
      homeGoToProfileModelobj: state.homeGoToProfileModelobj?.copyWith(
        listmyStoryItemList: _fillListmyStoryItemList(),
      ),
    );
  }

  List<ListmyStoryItemModel> _fillListmyStoryItemList() {
    return [
      ListmyStoryItemModel(
          myStoryOne: ImageConstant.imgUntitledDesign64x64,
          myStoryThree: ImageConstant.imgUnnamed1,
          iconOne: ImageConstant.imgIconOnprimary,
          mystory: "My Story"
      ),
      ListmyStoryItemModel(mystory: "Selena"),
      ListmyStoryItemModel(mystory: "Clara"),
      ListmyStoryItemModel(mystory: "Fabian"),
      ListmyStoryItemModel(mystory: "George"),
    ];
  }
}
