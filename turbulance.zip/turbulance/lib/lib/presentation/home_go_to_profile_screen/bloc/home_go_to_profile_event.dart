part of 'home_go_to_profile_bloc.dart';

abstract class HomeGoToProfileEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class HomeGoToProfileInitialEvent extends HomeGoToProfileEvent {
  @override
  List<Object?> get props => [];
}
