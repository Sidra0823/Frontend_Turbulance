part of 'home_go_to_profile_bloc.dart';

class HomeGoToProfileState extends Equatable {
  final TextEditingController? pinViewController;
  final HomeGoToProfileModel? homeGoToProfileModelobj;

  HomeGoToProfileState({this.pinViewController, this.homeGoToProfileModelobj});

  @override
  List<Object?> get props => [pinViewController, homeGoToProfileModelobj];

  HomeGoToProfileState copyWith({
    TextEditingController? pinViewController,
    HomeGoToProfileModel? homeGoToProfileModelobj,
  }) {
    return HomeGoToProfileState(
      pinViewController: pinViewController ?? this.pinViewController,
      homeGoToProfileModelobj: homeGoToProfileModelobj ?? this.homeGoToProfileModelobj,
    );
  }
}
