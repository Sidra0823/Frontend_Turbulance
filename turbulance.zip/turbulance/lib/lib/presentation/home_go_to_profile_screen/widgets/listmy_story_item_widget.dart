import 'package:flutter/material.dart';
import '../../../widgets/custom_icon_button.dart';
import '../models/listmy_story_item_model.dart';

class ListmyStoryItemWidget extends StatelessWidget {
  final ListmyStoryItemModel listmyStoryItemModelobj;

  ListmyStoryItemWidget(this.listmyStoryItemModelobj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 64.h,
      child: Column(
        children: [
          SizedBox(
            height: 64.h,
            width: double.maxFinite,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomImageView(
                  imagePath: listmyStoryItemModelobj.myStoryOne!,
                  height: 64.h,
                  width: 64.h,
                  radius: BorderRadius.circular(32.h),
                ),
                Container(
                  height: 54.h,
                  margin: EdgeInsets.only(left: 4.h, right: 2.h),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      CustomImageView(
                        imagePath: listmyStoryItemModelobj.myStoryThree!,
                        height: 54.h,
                        width: 54.h,
                        radius: BorderRadius.circular(26.h),
                      ),
                      CustomIconButton(
                        height: 16.h,
                        width: 16.h,
                        padding: EdgeInsets.all(4.h),
                        decoration: IconButtonStyleHelper.outlineOnPrimary,
                        alignment: Alignment.bottomRight,
                        child: CustomImageView(
                          imagePath: listmyStoryItemModelobj.iconOne!,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            listmyStoryItemModelobj.mystory!,
            overflow: TextOverflow.ellipsis,
            style: CustomTextStyles.titleSmallInter,
          ),
        ],
      ),
    );
  }
}
