import 'package:flutter/material.dart';
import '../../widgets/custom_bottom_bar.dart';
import 'bloc/home_go_to_profile_bloc.dart';
import 'models/home_go_to_profile_model.dart';
import 'models/listmy_story_item_model.dart';
import 'widgets/listmy_story_item_widget.dart';

class HomeGoToProfileScreen extends StatelessWidget {
  HomeGoToProfileScreen({Key? key}) : super(key: key);

  final GlobalKey<NavigatorState> navigatorKey = GlobalKey();

  static Widget builder(BuildContext context) {
    return BlocProvider<HomeGoToProfileBloc>(
      create: (context) => HomeGoToProfileBloc(
        HomeGoToProfileState(homeGoToProfileModelobj: HomeGoToProfileModel()),
      )..add(HomeGoToProfileInitialEvent()),
      child: HomeGoToProfileScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: buildAppbar(context),
      body: SafeArea(
        top: false,
        child: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Container(
              height: 902.h,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children: [
                  Align(
                    alignment: Alignment.topCenter,
                    child: Container(
                      width: double.maxFinite,
                      margin: EdgeInsets.only(top: 4.h),
                      padding: EdgeInsets.symmetric(horizontal: 14.h, vertical: 10.h),
                      decoration: AppDecoration.fillGray,
                      child: BlocBuilder<HomeGoToProfileBloc, HomeGoToProfileState>(
                        builder: (context, state) {
                          return Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("My Story", style: AppStyle.textstyleinterbold32),
                              SizedBox(height: 13.h),
                              Container(
                                margin: EdgeInsets.only(left: 5.h),
                                child: SizedBox(
                                  height: 104.h,
                                  child: ListView.builder(
                                    scrollDirection: Axis.horizontal,
                                    itemCount: state.homeGoToProfileModelobj?.listmyStoryItemList.length ?? 0,
                                    itemBuilder: (context, index) {
                                      ListmyStoryItemModel listmyStoryItemModel = state.homeGoToProfileModelobj!.listmyStoryItemList[index];
                                      return ListmyStoryItemWidget(listmyStoryItemModel);
                                    },
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomBar(),
    );
  }
}
