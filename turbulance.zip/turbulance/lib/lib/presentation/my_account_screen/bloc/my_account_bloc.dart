import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/my_account_model.dart';

part 'my_account_event.dart';
part 'my_account_state.dart';

/// A bloc that manages the state of MyAccount according to the event that is dispatched to it.
class MyAccountBloc extends Bloc<MyAccountEvent, MyAccountState> {
  MyAccountBloc(MyAccountState initialState) : super(initialState) {
    on<MyAccountInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      MyAccountInitialEvent event,
      Emitter<MyAccountState> emit,
      ) async {
    emit(state.copyWith(myAccountModelObj: MyAccountModel()));
  }
}
