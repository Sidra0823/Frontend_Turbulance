part of 'my_account_bloc.dart';

/// Represents the state of MyAccount in the application.
class MyAccountState extends Equatable {
  MyAccountState({this.myAccountModelObj});

  final MyAccountModel? myAccountModelObj;

  @override
  List<Object?> get props => [myAccountModelObj];

  MyAccountState copyWith({MyAccountModel? myAccountModelObj}) {
    return MyAccountState(
      myAccountModelObj: myAccountModelObj ?? this.myAccountModelObj,
    );
  }
}
