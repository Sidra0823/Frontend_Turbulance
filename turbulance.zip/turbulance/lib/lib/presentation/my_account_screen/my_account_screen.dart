import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_icon_button.dart';
import 'bloc/my_account_bloc.dart';
import 'models/my_account_model.dart';

class MyAccountScreen extends StatelessWidget {
  const MyAccountScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<MyAccountBloc>(
      create: (context) => MyAccountBloc(MyAccountState(
        myAccountModelObj: MyAccountModel(),
      ))..add(MyAccountInitialEvent()),
      child: MyAccountScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<MyAccountBloc, MyAccountState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          appBar: buildAppBar(context),
          body: SafeArea(
            top: false,
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.only(top: 26.h),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconButton(
                        height: 44.h,
                        width: 44.h,
                        padding: EdgeInsets.all(2.h),
                        decoration: IconButtonStyleHelper.fillOnPrimary,
                        child: CustomImageView(imagePath: ImageConstant.imgLockGray90001),
                      ),
                      SizedBox(width: 10.h),
                      Text(
                        "lbl_my_account".tr,
                        style: theme.textTheme.headlineMedium,
                      ),
                    ],
                  ),
                  SizedBox(height: 48.h),
                  CustomImageView(
                    imagePath: ImageConstant.imgProfilePicture80x80,
                    radius: BorderRadius.circular(40.h),
                    height: 80.h,
                    width: 82.h,
                  ),
                  SizedBox(height: 18.h),
                  Text(
                    "lbl_turbulance".tr,
                    style: theme.textTheme.headlineLarge,
                  ),
                  SizedBox(height: 52.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgCalendarOnprimary,
                        height: 30.h,
                        width: 24.h,
                        margin: EdgeInsets.only(top: 4.h),
                      ),
                      SizedBox(width: 10.h),
                      Expanded(
                        child: Align(
                          alignment: Alignment.centerLeft,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "lbl_date_joined".tr,
                                style: CustomTextStyles.headlineSmall25,
                              ),
                              Text(
                                "lbl_december_2024".tr,
                                style: CustomTextStyles.titleMediumBold,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  PreferredSizeWidget buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowLeft(context);
        },
      ),
    );
  }

  void onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
