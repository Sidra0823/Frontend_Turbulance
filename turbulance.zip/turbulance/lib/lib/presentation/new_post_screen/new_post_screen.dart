import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/new_post_bloc.dart';
import 'models/new_post_model.dart';
import 'widgets/new_post_one_item_widget.dart';

class NewPostScreen extends StatelessWidget {
  const NewPostScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (_) => NewPostBloc(NewPostState(newPostModelObj: const NewPostModel()))..add(NewPostInitialEvent()),
      child: const NewPostScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("New Post")),
      body: BlocBuilder<NewPostBloc, NewPostState>(
        builder: (context, state) {
          final newPostModelObj = state.newPostModelObj;

          if (newPostModelObj == null) {
            return const Center(child: CircularProgressIndicator());
          }

          return ListView.builder(
            itemCount: newPostModelObj.newPostOneItemList.length,
            itemBuilder: (context, index) {
              return NewPostOneItemWidget(newPostModelObj.newPostOneItemList[index]);
            },
          );
        },
      ),
    );
  }
}
