part of 'new_post_bloc.dart';

/// Represents the state of NewPost in the application.
class NewPostState extends Equatable {
  final SelectionPopupModel? selectedDropDownValue;
  final NewPostModel? newPostModelObj;

  NewPostState({this.selectedDropDownValue, this.newPostModelObj});

  @override
  List<Object?> get props => [selectedDropDownValue, newPostModelObj];

  NewPostState copyWith({
    SelectionPopupModel? selectedDropDownValue,
    NewPostModel? newPostModelObj,
  }) {
    return NewPostState(
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      newPostModelObj: newPostModelObj ?? this.newPostModelObj,
    );
  }
}
