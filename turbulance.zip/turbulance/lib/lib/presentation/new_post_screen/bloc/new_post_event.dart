part of 'new_post_bloc.dart';

/// Abstract class for all events that can be dispatched from the NewPost widget.
abstract class NewPostEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the NewPost widget is first created.
class NewPostInitialEvent extends NewPostEvent {}
