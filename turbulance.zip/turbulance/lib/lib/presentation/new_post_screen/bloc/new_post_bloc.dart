import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/new_post_model.dart';

part 'new_post_event.dart';
part 'new_post_state.dart';

/// A bloc that manages the state of a NewPost according to the event that is dispatched to it.
class NewPostBloc extends Bloc<NewPostEvent, NewPostState> {
  NewPostBloc(NewPostState initialState) : super(initialState) {
    on<NewPostInitialEvent>(_onInitialize);
  }

  void _onInitialize(NewPostInitialEvent event, Emitter<NewPostState> emit) async {
    emit(
      state.copyWith(
        newPostModelObj: state.newPostModelObj?.copyWith(
          dropdownItemList: _fillDropdownItemList(),
          newPostOneItemList: _fillNewPostOneItemList(),
        ),
      ),
    );
  }

  List<SelectionPopupModel> _fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }

  List<NewPostOneItemModel> _fillNewPostOneItemList() {
    return List.generate(7, (index) => NewPostOneItemModel(cameraTwo: "Camera", photos: "Photos"));
  }
}
