import 'package:equatable/equatable.dart';

/// This class is used in the [new_post_one_item_widget] screen.
class NewPostOneItemModel extends Equatable {
  final String? cameraTwo;
  final String? photos;
  final String? id;

  NewPostOneItemModel({this.cameraTwo = "Camera", this.photos = "Photos", this.id = ""});

  NewPostOneItemModel copyWith({
    String? cameraTwo,
    String? photos,
    String? id,
  }) {
    return NewPostOneItemModel(
      cameraTwo: cameraTwo ?? this.cameraTwo,
      photos: photos ?? this.photos,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [cameraTwo, photos, id];
}
