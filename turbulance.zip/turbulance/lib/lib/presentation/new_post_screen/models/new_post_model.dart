import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import 'new_post_one_item_model.dart';

/// This class defines the variables used in the [new_post_screen].
class NewPostModel extends Equatable {
  final List<SelectionPopupModel> dropdownItemList;
  final List<NewPostOneItemModel> newPostOneItemList;

  const NewPostModel({
    this.dropdownItemList = const [],
    this.newPostOneItemList = const [],
  });

  NewPostModel copyWith({
    List<SelectionPopupModel>? dropdownItemList,
    List<NewPostOneItemModel>? newPostOneItemList,
  }) {
    return NewPostModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
      newPostOneItemList: newPostOneItemList ?? this.newPostOneItemList,
    );
  }

  @override
  List<Object?> get props => [dropdownItemList, newPostOneItemList];
}
