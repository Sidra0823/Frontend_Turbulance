import 'package:flutter/material.dart';
import '../models/new_post_one_item_model.dart';

class NewPostOneItemWidget extends StatelessWidget {
  final NewPostOneItemModel newPostOneItemModelObj;

  const NewPostOneItemWidget(this.newPostOneItemModelObj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 286,
      child: Column(
        children: [
          Text(newPostOneItemModelObj.cameraTwo ?? "Camera"),
          Text(newPostOneItemModelObj.photos ?? "Photos"),
        ],
      ),
    );
  }
}
