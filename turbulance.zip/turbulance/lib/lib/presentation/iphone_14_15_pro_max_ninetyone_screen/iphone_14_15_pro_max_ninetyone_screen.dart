import 'package:flutter/material.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_pin_code_text_field.dart';
import 'bloc/iphone_14_15_pro_max_ninetyone_bloc.dart';
import 'models/iphone_14_15_pro_max_ninetyone_model.dart';

class Iphone1415ProMaxNinetyoneScreen extends StatelessWidget {
  const Iphone1415ProMaxNinetyoneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxNinetyoneBloc>(
      create: (context) => Iphone1415ProMaxNinetyoneBloc(
        Iphone1415ProMaxNinetyoneState(
          iphone1415ProMaxNinetyoneModelObj: Iphone1415ProMaxNinetyoneModel(),
        ),
      )..add(Iphone1415ProMaxNinetyoneInitialEvent()),
      child: const Iphone1415ProMaxNinetyoneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(top: 186.h),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              CustomIconButton(
                height: 72.h,
                width: 72.h,
                padding: EdgeInsets.all(14.h),
                decoration: IconButtonStyleHelper.outlineOnPrimaryTL16,
                child: CustomImageView(
                  imagePath: ImageConstant.imgFavoriteOnPrimary,
                ),
              ),
              SizedBox(height: 14.h),
              Text(
                "msg_two_factor_authentication".tr,
                style: CustomTextStyles.bodyLargeRoboto_2,
              ),
              SizedBox(height: 14.h),
              BlocSelector<Iphone1415ProMaxNinetyoneBloc,
                  Iphone1415ProMaxNinetyoneState, TextEditingController?>(
                selector: (state) => state.otpController,
                builder: (context, otpController) {
                  return CustomPinCodeTextField(
                    context: context,
                    controller: otpController,
                    onChanged: (value) {
                      otpController?.text = value;
                    },
                  );
                },
              ),
              SizedBox(height: 14.h),
              Text(
                "msg_did_not_get_a_verification".tr,
                style: CustomTextStyles.bodySmallRobotoOnPrimary12_1,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
