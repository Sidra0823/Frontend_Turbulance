import 'package:equatable/equatable.dart';

/// This class defines the variables used in the Iphone1415ProMaxNinetyoneScreen.
class Iphone1415ProMaxNinetyoneModel extends Equatable {
  @override
  List<Object?> get props => [];
}
