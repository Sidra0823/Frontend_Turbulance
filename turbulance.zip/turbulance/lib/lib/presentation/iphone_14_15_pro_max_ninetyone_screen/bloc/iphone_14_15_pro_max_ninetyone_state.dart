part of 'iphone_14_15_pro_max_ninetyone_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetyone in the application.
class Iphone1415ProMaxNinetyoneState extends Equatable {
  final TextEditingController? otpController;
  final Iphone1415ProMaxNinetyoneModel? iphone1415ProMaxNinetyoneModelObj;

  Iphone1415ProMaxNinetyoneState({
    this.otpController,
    this.iphone1415ProMaxNinetyoneModelObj,
  });

  @override
  List<Object?> get props => [otpController, iphone1415ProMaxNinetyoneModelObj];

  Iphone1415ProMaxNinetyoneState copyWith({
    TextEditingController? otpController,
    Iphone1415ProMaxNinetyoneModel? iphone1415ProMaxNinetyoneModelObj,
  }) {
    return Iphone1415ProMaxNinetyoneState(
      otpController: otpController ?? this.otpController,
      iphone1415ProMaxNinetyoneModelObj:
      iphone1415ProMaxNinetyoneModelObj ?? this.iphone1415ProMaxNinetyoneModelObj,
    );
  }
}
