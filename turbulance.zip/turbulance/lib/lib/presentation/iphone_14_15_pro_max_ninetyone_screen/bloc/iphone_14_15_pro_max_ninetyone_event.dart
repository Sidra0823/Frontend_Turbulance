part of 'iphone_14_15_pro_max_ninetyone_bloc.dart';

/// Abstract class for all events that can be dispatched from the Iphone1415ProMaxNinetyone widget.
/// Events must be immutable and implement the [Equatable] interface.
abstract class Iphone1415ProMaxNinetyoneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Iphone1415ProMaxNinetyone widget is first created.
class Iphone1415ProMaxNinetyoneInitialEvent extends Iphone1415ProMaxNinetyoneEvent {}

/// Event for OTP auto-fill.
class ChangeOTPEvent extends Iphone1415ProMaxNinetyoneEvent {
  final String code;

  ChangeOTPEvent({required this.code});

  @override
  List<Object?> get props => [code];
}
