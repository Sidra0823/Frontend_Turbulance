import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import 'package:sms_autofill/sms_autofill.dart';
import '../models/iphone_14_15_pro_max_ninetyone_model.dart';

part 'iphone_14_15_pro_max_ninetyone_event.dart';
part 'iphone_14_15_pro_max_ninetyone_state.dart';

/// A bloc that manages the state of a Iphone1415ProMaxNinetyone according to the event that is dispatched to it.
class Iphone1415ProMaxNinetyoneBloc
    extends Bloc<Iphone1415ProMaxNinetyoneEvent, Iphone1415ProMaxNinetyoneState>
    with CodeAutoFill {
  Iphone1415ProMaxNinetyoneBloc(Iphone1415ProMaxNinetyoneState initialState)
      : super(initialState) {
    on<Iphone1415ProMaxNinetyoneInitialEvent>(_onInitialize);
    on<ChangeOTPEvent>(_changeOTP);
  }

  void _onInitialize(
      Iphone1415ProMaxNinetyoneInitialEvent event,
      Emitter<Iphone1415ProMaxNinetyoneState> emit) async {
    emit(state.copyWith(otpController: TextEditingController()));
    listenForCode();
  }

  @override
  void codeUpdated() {
    add(ChangeOTPEvent(code: code!));
  }

  void _changeOTP(
      ChangeOTPEvent event, Emitter<Iphone1415ProMaxNinetyoneState> emit) {
    emit(state.copyWith(
      otpController: TextEditingController(text: event.code),
    ));
  }
}
