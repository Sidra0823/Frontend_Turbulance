import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/listturbulance_item_model.dart';
import '../models/select_people_for_group_model.dart';

part 'select_people_for_group_event.dart';
part 'select_people_for_group_state.dart';

/// A bloc that manages the state of SelectPeopleForGroup according to the event that is dispatched to it.
class SelectPeopleForGroupBloc
    extends Bloc<SelectPeopleForGroupEvent, SelectPeopleForGroupState> {
  SelectPeopleForGroupBloc(SelectPeopleForGroupState initialState)
      : super(initialState) {
    on<SelectPeopleForGroupInitialEvent>(onInitialize);
  }

  Future<void> onInitialize(
      SelectPeopleForGroupInitialEvent event,
      Emitter<SelectPeopleForGroupState> emit) async {
    emit(state.copyWith(searchController: TextEditingController()));
    emit(state.copyWith(
      selectPeopleForGroupModel0bj: state.selectPeopleForGroupModel0bj?.copyWith(
        listturbulanceItemList: fillListturbulanceItemList(),
      ),
    ));
  }

  List<ListturbulanceItemModel> fillListturbulanceItemList() {
    return [
      ListturbulanceItemModel(
        turbulance: ImageConstant.imgUnnamed1,
        turbulanceFour: "Turbulance",
        turbulanceFive: "turbulance",
        checkmarkOne: ImageConstant.imgCheckmark,
      ),
      ListturbulanceItemModel(
        turbulance: ImageConstant.imgDownload50,
        turbulanceFour: "Magdalene",
        turbulanceFive: "magdalene_02",
        checkmarkOne: ImageConstant.imgCheckmark,
      ),
      ListturbulanceItemModel(
        turbulance: ImageConstant.imgDownload48,
        turbulanceFour: "Olive",
        turbulanceFive: "olive_lucy",
        checkmarkOne: ImageConstant.imgCheckmark,
      ),
      ListturbulanceItemModel(
        turbulance: ImageConstant.imgDownload48,
        turbulanceFour: "Luke",
        turbulanceFive: "Luke fernandas",
      ),
      ListturbulanceItemModel(),
      ListturbulanceItemModel(),
      ListturbulanceItemModel(),
      ListturbulanceItemModel(),
    ];
  }
}
