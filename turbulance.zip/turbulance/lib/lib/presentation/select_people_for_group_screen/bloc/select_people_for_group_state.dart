part of 'select_people_for_group_bloc.dart';

/// Represents the state of SelectPeopleForGroup in the application.
// ignore_for_file: must_be_immutable
class SelectPeopleForGroupState extends Equatable {
  SelectPeopleForGroupState({this.searchController, this.selectPeopleForGroupModel0bj});

  TextEditingController? searchController;
  SelectPeopleForGroupModel? selectPeopleForGroupModel0bj;

  @override
  List<Object?> get props => [searchController, selectPeopleForGroupModel0bj];

  SelectPeopleForGroupState copyWith({
    TextEditingController? searchController,
    SelectPeopleForGroupModel? selectPeopleForGroupModelObj,
  }) {
    return SelectPeopleForGroupState(
      searchController: searchController ?? this.searchController,
      selectPeopleForGroupModel0bj: selectPeopleForGroupModelObj ?? this.selectPeopleForGroupModel0bj,
    );
  }
}
