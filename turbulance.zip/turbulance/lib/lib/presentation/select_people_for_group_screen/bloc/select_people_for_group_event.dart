part of 'select_people_for_group_bloc.dart';

/// Abstract class for all events that can be dispatched from the SelectPeopleForGroup widget.
/// Events must be immutable and implement the [Equatable] interface.
class SelectPeopleForGroupEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the SelectPeopleForGroup widget is first created.
class SelectPeopleForGroupInitialEvent extends SelectPeopleForGroupEvent {
  @override
  List<Object?> get props => [];
}
