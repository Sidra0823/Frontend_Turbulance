import 'package:equatable/equatable.dart';
import 'listturbulance_item_model.dart';

/// This class defines the variables used in the [select_people_for_group_screen],
/// and is typically used to hold data that is passed between different parts of the application.
// ignore_for_file: must_be_immutable
class SelectPeopleForGroupModel extends Equatable {
  SelectPeopleForGroupModel({this.listturbulanceItemList = const []});

  List<ListturbulanceItemModel> listturbulanceItemList;

  SelectPeopleForGroupModel copyWith({
    List<ListturbulanceItemModel>? listturbulanceItemList,
  }) {
    return SelectPeopleForGroupModel(
      listturbulanceItemList: listturbulanceItemList ?? this.listturbulanceItemList,
    );
  }

  @override
  List<Object?> get props => [listturbulanceItemList];
}
