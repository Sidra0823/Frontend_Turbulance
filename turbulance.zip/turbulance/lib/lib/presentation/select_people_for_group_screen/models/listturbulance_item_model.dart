import 'package:equatable/equatable.dart';

// ignore_for_file: must_be_immutable
class ListturbulanceItemModel extends Equatable {
  ListturbulanceItemModel({
    this.turbulance,
    this.turbulanceFour,
    this.turbulanceFive,
    this.checkmarkOne,
    this.id,
  });

  String? turbulance;
  String? turbulanceFour;
  String? turbulanceFive;
  String? checkmarkOne;
  String? id;

  ListturbulanceItemModel copyWith({
    String? turbulance,
    String? turbulanceFour,
    String? turbulanceFive,
    String? checkmarkOne,
    String? id,
  }) {
    return ListturbulanceItemModel(
      turbulance: turbulance ?? this.turbulance,
      turbulanceFour: turbulanceFour ?? this.turbulanceFour,
      turbulanceFive: turbulanceFive ?? this.turbulanceFive,
      checkmarkOne: checkmarkOne ?? this.checkmarkOne,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [turbulance, turbulanceFour, turbulanceFive, checkmarkOne, id];
}
