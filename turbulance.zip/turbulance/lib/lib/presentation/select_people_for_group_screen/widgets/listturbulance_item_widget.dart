import 'package:flutter/material.dart';
import '../../../theme/custom_button_style.dart';
import '../../../widgets/custom_elevated_button.dart';
import '../models/listturbulance_item_model.dart';

// ignore_for_file: must_be_immutable
class ListturbulanceItemWidget extends StatelessWidget {
  final ListturbulanceItemModel listturbulanceItemModelObj;

  ListturbulanceItemWidget(this.listturbulanceItemModelObj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 2.h),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 64.h,
            width: 64.h,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgUntitledDesign64x64,
                  height: 64.h,
                  radius: BorderRadius.circular(32.h),
                ),
                CustomImageView(
                  imagePath: listturbulanceItemModelObj.turbulance!,
                  height: 54.h,
                  width: 56.h,
                  radius: BorderRadius.circular(26.h),
                ),
                Expanded(
                  child: Align(
                    alignment: Alignment.bottomLeft,
                    child: Padding(
                      padding: EdgeInsets.only(left: 14.h, bottom: 6.h),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            listturbulanceItemModelObj.turbulanceFour!,
                            style: CustomTextStyles.bodyLarge18,
                          ),
                          Text(
                            listturbulanceItemModelObj.turbulanceFive!,
                            style: theme.textTheme.bodyLarge,
                          ),
                          _buildFollowing(context),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFollowing(BuildContext context) {
    return CustomElevatedButton(
      width: 102.h,
      text: "lbl_following".tr,
      margin: EdgeInsets.only(left: 14.h),
      buttonStyle: CustomButtonStyles.fillGrayTL5,
    );
  }
}
