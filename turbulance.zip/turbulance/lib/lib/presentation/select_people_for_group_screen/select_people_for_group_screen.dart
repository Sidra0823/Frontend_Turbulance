import 'package:flutter/material.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_search_view.dart';
import 'bloc/select_people_for_group_bloc.dart';
import 'models/listturbulance_item_model.dart';
import 'models/select_people_for_group_model.dart';
import 'widgets/listturbulance_item_widget.dart';

class SelectPeopleForGroupScreen extends StatelessWidget {
  const SelectPeopleForGroupScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<SelectPeopleForGroupBloc>(
      create: (context) => SelectPeopleForGroupBloc(SelectPeopleForGroupState(
        selectPeopleForGroupModel0bj: SelectPeopleForGroupModel(),
      ))..add(SelectPeopleForGroupInitialEvent()),
      child: SelectPeopleForGroupScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      appBar: _buildAppbar(context),
      body: SafeArea(
        child: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SizedBox(
              width: double.maxFinite,
              child: Column(
                children: [
                  SizedBox(height: 10.h),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 24.h),
                    child: BlocSelector<SelectPeopleForGroupBloc, SelectPeopleForGroupState, TextEditingController?>(
                      selector: (state) => state.searchController,
                      builder: (context, searchController) {
                        return CustomSearchView(
                          controller: searchController,
                          hintText: "lbl_search".tr,
                          contentPadding: EdgeInsets.fromLTRB(20.h, 6.h, 12.h, 6.h),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 18.h),
                  _buildListturbulance(context),
                  SizedBox(height: 8.h),
                  _buildContinue(context),
                  _buildStackthunderlog(context),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 56.h,
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowleftone(context);
        },
      ),
      centerTitle: true,
      title: AppbarTitle(text: "lbl_create_group".tr),
    );
  }

  Widget _buildListturbulance(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 14.h, right: 24.h),
      child: BlocSelector<SelectPeopleForGroupBloc, SelectPeopleForGroupState, SelectPeopleForGroupModel?>(
        selector: (state) => state.selectPeopleForGroupModel0bj,
        builder: (context, selectPeopleForGroupModel0bj) {
          return ListView.separated(
            padding: EdgeInsets.zero,
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (context, index) {
              return SizedBox(height: 16.h);
            },
            itemCount: selectPeopleForGroupModel0bj?.listturbulanceItemList.length ?? 0,
            itemBuilder: (context, index) {
              ListturbulanceItemModel model = selectPeopleForGroupModel0bj?.listturbulanceItemList[index] ?? ListturbulanceItemModel();
              return ListturbulanceItemWidget(model);
            },
          );
        },
      ),
    );
  }

  Widget _buildContinue(BuildContext context) {
    return CustomElevatedButton(
      height: 44.h,
      width: 174.h,
      text: "lbl_continue".tr,
      buttonStyle: CustomButtonStyles.fillGrayTL14,
      buttonTextStyle: CustomTextStyles.titleMediumBold_1,
    );
  }

  Widget _buildStackthunderlog(BuildContext context) {
    return SizedBox(
      height: 78.h,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgThunderLogo2,
            height: 78.h,
            width: double.maxFinite,
            radius: BorderRadius.vertical(top: Radius.circular(14.h)),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 34.h),
                width: double.maxFinite,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomImageView(imagePath: ImageConstant.imgHomeOnprimary, height: 30.h, width: 32.h),
                    CustomImageView(imagePath: ImageConstant.imgCalendar, height: 30.h, width: 32.h),
                    CustomImageView(imagePath: ImageConstant.imgClose, height: 30.h, width: 30.h),
                    CustomImageView(imagePath: ImageConstant.imgClosePrimary, height: 30.h, width: 32.h),
                    CustomImageView(imagePath: ImageConstant.imgLockOnprimary, height: 30.h, width: 32.h),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void onTapArrowleftone(BuildContext context) {
    NavigatorService.goBack();
  }
}
