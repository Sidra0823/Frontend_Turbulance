part of 'add_card_option_one_bloc.dart';

/// Represents the state of AddCardOptionOne in the application.

// ignore_for_file: must_be_immutable
class AddCardOptionOneState extends Equatable {
  AddCardOptionOneState({
    this.cardNumberController,
    this.cvvtwoController,
    this.nameController,
    this.selectedDropDownValue,
    this.selectedDropDownValue1,
    this.addCardOptionOneModelObj,
  });

  TextEditingController? cardNumberController;
  TextEditingController? cvvtwoController;
  TextEditingController? nameController;
  SelectionPopupModel? selectedDropDownValue;
  SelectionPopupModel? selectedDropDownValue1;
  AddCardOptionOneModel? addCardOptionOneModelObj;

  @override
  List<Object?> get props => [
    cardNumberController,
    cvvtwoController,
    nameController,
    selectedDropDownValue,
    selectedDropDownValue1,
    addCardOptionOneModelObj,
  ];

  AddCardOptionOneState copyWith({
    TextEditingController? cardNumberController,
    TextEditingController? cvvtwoController,
    TextEditingController? nameController,
    SelectionPopupModel? selectedDropDownValue,
    SelectionPopupModel? selectedDropDownValue1,
    AddCardOptionOneModel? addCardOptionOneModelObj,
  }) {
    return AddCardOptionOneState(
      cardNumberController: cardNumberController ?? this.cardNumberController,
      cvvtwoController: cvvtwoController ?? this.cvvtwoController,
      nameController: nameController ?? this.nameController,
      selectedDropDownValue: selectedDropDownValue ?? this.selectedDropDownValue,
      selectedDropDownValue1: selectedDropDownValue1 ?? this.selectedDropDownValue1,
      addCardOptionOneModelObj:
      addCardOptionOneModelObj ?? this.addCardOptionOneModelObj,
    );
  }
}
