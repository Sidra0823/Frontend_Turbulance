import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../../../data/models/selectionPopupModel/selection_popup_model.dart';
import '../models/add_card_option_one_model.dart';

part 'add_card_option_one_event.dart';  // Ensure part files are properly linked
part 'add_card_option_one_state.dart';  // Ensure part files are properly linked

/// A BLoC that manages the state of AddCardOptionOne according to the event dispatched to it.
class AddCardOptionOneBloc extends Bloc<AddCardOptionOneEvent, AddCardOptionOneState> {
  AddCardOptionOneBloc(AddCardOptionOneState initialState) : super(initialState) {
    on<AddCardOptionOneInitialEvent>(_onInitialize);
  }

  /// Method to handle AddCardOptionOneInitialEvent
  Future<void> _onInitialize(
      AddCardOptionOneInitialEvent event,
      Emitter<AddCardOptionOneState> emit,
      ) async {
    // Initialize controllers and model
    emit(state.copyWith(
      cardNumberController: TextEditingController(),
      cvvtwoController: TextEditingController(),
      nameController: TextEditingController(),
    ));

    // Update the state with dropdown lists
    emit(state.copyWith(
      addCardOptionOneModelObj: state.addCardOptionOneModelObj?.copyWith(
        dropdownItemList: fillDropdownItemList(),
        dropdownItemListi: fillDropdownItemListi(),
      ),
    ));
  }

  /// Method to fill the first dropdown item list
  List<SelectionPopupModel> fillDropdownItemList() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }

  /// Method to fill the second dropdown item list
  List<SelectionPopupModel> fillDropdownItemListi() {
    return [
      SelectionPopupModel(id: 1, title: "Item One", isSelected: true),
      SelectionPopupModel(id: 2, title: "Item Two"),
      SelectionPopupModel(id: 3, title: "Item Three"),
    ];
  }
}
