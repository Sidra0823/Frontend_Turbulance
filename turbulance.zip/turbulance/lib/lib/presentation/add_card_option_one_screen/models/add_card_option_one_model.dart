class AddCardOptionOneModel {
  final List<SelectionPopupModel> dropdownItemList;
  final List<SelectionPopupModel> dropdownItemListi;

  AddCardOptionOneModel({
    required this.dropdownItemList,
    required this.dropdownItemListi,
  });

  AddCardOptionOneModel copyWith({
    List<SelectionPopupModel>? dropdownItemList,
    List<SelectionPopupModel>? dropdownItemListi,
  }) {
    return AddCardOptionOneModel(
      dropdownItemList: dropdownItemList ?? this.dropdownItemList,
      dropdownItemListi: dropdownItemListi ?? this.dropdownItemListi,
    );
  }
}
