import 'package:flutter/material.dart';
import 'package:flutter_material_color/flutter_material_color.dart';

import '../../core/app_export.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/add_card_option_one_bloc.dart';
import 'models/add_card_option_one_model.dart';

class AddCardOptionOneScreen extends StatelessWidget {
  AddCardOptionOneScreen({Key? key}) : super(key: key);

  GlobalKey<FormState> formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<AddCardOptionOneBloc>(
      create: (context) => AddCardOptionOneBloc(
        AddCardOptionOneState(
          addCardOptionOneModelObj: AddCardOptionOneModel(),
        ),
      )..add(AddCardOptionOneInitialEvent()),
      child: AddCardOptionOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: SizedBox(
          height: SizeUtils.height,
          child: Form(
            key: formKey,
            child: Container(
              width: double.maxFinite,
              padding: EdgeInsets.only(
                top: 4.h,
                right: 30.h,
                left: 30.h,
                bottom: 30.h,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  // ... other widgets
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
// ... (rest of the code from the image)

_buildColumncardnumbe(BuildContext context) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      SizedBox(height: 36.h),
      Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: EdgeInsets.only(left: 24.h),
          child: Text(
            "lbl_card_number".tr,
            style: CustomTextStyles.titleSmallGray900,
          ),
        ),
      ),
      SizedBox(height: 14.h),
      CustomTextFormField(
        controller: TextEditingController(),
        hintText: "msg_enter_your_card_number".tr,
        textInputType: TextInputType.number,
        textInputAction: TextInputAction.next,
        contentPadding: EdgeInsets.only(
          left: 16.h,
          top: 16.h,
          bottom: 16.h,
          right: 16.h,
        ),
        border: InputBorder.none,
        prefixIcon: Container(
          margin: EdgeInsets.only(left: 16.h),
          child: CommonImageView(
            svgPath: ImageConstant.imgCard,
            height: 18.adaptSize,
            width: 18.adaptSize,
          ),
        ),
      ),
    ],
  );
}

_buildRowvalidthru(BuildContext context) {
  return Row(
    children: [
      Expanded(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 24.h),
              child: Text(
                "lbl_valid_thru".tr,
                style: CustomTextStyles.titleSmallGray900,
              ),
            ),
            SizedBox(height: 14.h),
            CustomTextFormField(
              controller: TextEditingController(),
              hintText: "msg_enter_valid_thru_date".tr,
              textInputType: TextInputType.number,
              textInputAction: TextInputAction.next,
              contentPadding: EdgeInsets.only(
                left: 16.h,
                top: 16.h,
                bottom: 16.h,
                right: 16.h,
              ),
              border: InputBorder.none,
            ),
          ],
        ),
      ),
      Expanded(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.only(left: 24.h),
              child: Text(
                "lbl_cvv_code".tr,
                style: CustomTextStyles.titleSmallGray900,
              ),
            ),
            SizedBox(height: 14.h),
            CustomTextFormField(
              controller: TextEditingController(),
              hintText: "msg_enter_cvv_code".tr,
              textInputType: TextInputType.number,
              textInputAction: TextInputAction.done,
              contentPadding: EdgeInsets.only(
                left: 16.h,
                top: 16.h,
                bottom: 16.h,
                right: 16.h,
              ),
              border: InputBorder.none,
            ),
          ],
        ),
      ),
    ],
  );
}

_buildColumncardholde(BuildContext context) {
  return Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Align(
        alignment: Alignment.centerLeft,
        child: Padding(
          padding: EdgeInsets.only(left: 24.h),
          child: Text(
            "lbl_cardholder_name".tr,
            style: CustomTextStyles.titleSmallGray900,
          ),
        ),
      ),
      SizedBox(height: 14.h),
      CustomTextFormField(
        controller: TextEditingController(),
        hintText: "msg_enter_cardholder_name".tr,
        textInputType: TextInputType.name,
        textInputAction: TextInputAction.done,
        contentPadding: EdgeInsets.only(
          left: 16.h,
          top: 16.h,
          bottom: 16.h,
          right: 16.h,
        ),
        border: InputBorder.none,
      ),
    ],
  );
}

_buildStackproceed(BuildContext context) {
  return Stack(
    alignment: Alignment.center,
    children: [
      CustomElevatedButton(
        height: 56.h,
        text: "lbl_proceed".tr,
        margin: EdgeInsets.only(right: 24.h),
        onPressed: () {
          // Handle button tap
        },
      ),
      Align(
        alignment: Alignment.centerRight,
        child: CommonImageView(
          svgPath: ImageConstant.imgArrowRight,
          height: 24.adaptSize,
          width: 24.adaptSize,
        ),
      ),
    ],
  );
}

_buildAppbar(BuildContext context) {
  return CustomAppBar(
    leadingWidth: 56.h,
    leading: AppbarLeadingImage(
      margin: EdgeInsets.only(left: 24.h, top: 16.h, bottom: 16.h),
      svgPath: ImageConstant.imgClose,
      onTap: () {
        // Handle close button tap
      },
    ),
    title: SizedBox(
      height: 32.h,
      width: 165.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CommonImageView(
            svgPath: ImageConstant.imgRectangle165,
            height: 32.adaptSize,
            width: 165.adaptSize,
          ),
          Padding(
            padding: EdgeInsets.only(left: 16.h),
            child: Text(
              "lbl_add_new_card".tr,
              style: CustomTextStyles.titleSmallWhiteA700,
            ),
          ),
        ],
      ),
    ),
    styleType: AppBarStyle.bgFillWhiteA700,
  );
}// ... (rest of the code from the image)

SizedBox(height = 26.h),
Container(
margin = EdgeInsets.symmetric(horizontal: 18.h),
padding = EdgeInsets.symmetric(horizontal: 16.h, vertical: 14.h),
decoration = AppDecoration.fillGray.copyWith(
borderRadius: BorderRadiusStyle.roundedBorder8,
),
width = double.maxFinite,
child = Row(
children: [
Expanded(
child: Padding(
padding: EdgeInsets.only(left: 4.h),
child: Column(
crossAxisAlignment: CrossAxisAlignment.start,
children: [
Text(
"lbl_847_822".tr,
style: CustomTextStyles.titleMediumIBMPlexSans,
),
SizedBox(height: 2.h),
Text(
"msg_view_detailed_bill".tr,
style: CustomTextStyles.labelLargeIBMPlexSansBlue500,
),
],
),
),
),
Expanded(
child: CustomElevatedButton(
height: 50.h,
text: "lbl_continue_to_buy".tr,
margin: EdgeInsets.only(bottom: 2.h),
buttonStyle: CustomButtonStyles.fillDeepPurpleEa,
buttonTextStyle: CustomTextStyles.titleSmallNunito15,
),
),
],
),
),

// Add more widgets or layout elements as needed, such as:
// - Additional containers or rows for different sections
// - Text widgets for displaying information
// - Image widgets for displaying images
// - Custom widgets that you have defined in your project

// Remember to replace the placeholder text and styles with your actual values and styles.// ... (rest of the code from the image)
//
// SizedBox(height: 26.h),
// Container(
//   margin: EdgeInsets.symmetric(horizontal: 18.h),
//   padding: EdgeInsets.symmetric(horizontal: 16.h, vertical: 14.h),
//   decoration: AppDecoration.fillGray.copyWith(
//     borderRadius: BorderRadiusStyle.roundedBorder8,
//   ),
//   width: double.maxFinite,
//   child: Row(
//     children: [
//       Expanded(
//         child: Padding(
//           padding: EdgeInsets.only(left: 4.h),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 "lbl_847_822".tr,
//                 style: CustomTextStyles.titleMediumIBMPlexSans,
//               ),
//               SizedBox(height: 2.h),
//               Text(
//                 "msg_view_detailed_bill".tr,
//                 style: CustomTextStyles.labelLargeIBMPlexSansBlue500,
//               ),
//             ],
//           ),
//         ),
//       ),
//       Expanded(
//         child: CustomElevatedButton(
//           height: 50.h,
//           text: "lbl_continue_to_buy".tr,
//           margin: EdgeInsets.only(bottom: 2.h),
//           buttonStyle: CustomButtonStyles.fillDeepPurpleEa,
//           buttonTextStyle: CustomTextStyles.titleSmallNunito15,
//         ),
//       ),
//     ],
//   ),
// ),
//
// // Add more widgets or layout elements as needed, such as:
// // - Additional containers or rows for different sections
// // - Text widgets for displaying information
// // - Image widgets for displaying images
// // - Custom widgets that you have defined in your project
//
// // Remember to replace the placeholder text and styles with your actual values and styles.// ... (rest of the code from the image)
//
// Widget _buildColumncardnumbe(BuildContext context) {
//   return Container(
//     width: double.maxFinite,
//     margin: EdgeInsets.only(left: 24.h, right: 8.h),
//     child: Column(
//       crossAxisAlignment: CrossAxisAlignment.start,
//       children: [
//         Text(
//           "lbl_card_number".tr,
//           style: theme.textTheme.bodyMedium,
//         ),
//         SizedBox(height: 6.h),
//         BlocSelector<AddCardOptionOneBloc, AddCardOptionOneState, TextEditingController?>(
//           selector: (state) => state.cardNumberController,
//           builder: (context, cardNumberController) {
//             return CustomTextFormField(
//               controller: cardNumberController,
//               hintText: "msg_enter_12_digit_card".tr,
//               textInputType: TextInputType.number,
//               contentPadding: EdgeInsets.symmetric(
//                 horizontal: 18.h,
//                 vertical: 8.h,
//               ),
//               validator: (value) {
//                 // Add your validation logic here
//                 if (value == null || value.isEmpty) {
//                   return "Please enter your card number";
//                 } else if (value.length != 12) {
//                   return "Card number must be 12 digits";
//                 }
//                 return null;
//               },
//             );
//           },
//         ),
//       ],
//     ),
//   );
// }// ... (rest of the code from the image)
//
// Widget _buildRowvalidthru(BuildContext context) {
//   return Container(
//     width: double.maxFinite,
//     margin: EdgeInsets.only(left: 24.h, right: 16.h),
//     child: Row(
//       children: [
//         Expanded(
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text(
//                 "lbl_valid_thru".tr,
//                 style: theme.textTheme.bodyMedium,
//               ),
//               SizedBox(height: 6.h),
//               SizedBox(
//                 width: double.maxFinite,
//                 child: Row(
//                   children: [
//                     Expanded(
//                       child: BlocSelector<AddCardOptionOneBloc, AddCardOptionOneState, TextEditingController?>(
//                         selector: (state) => state.validThruController,
//                         builder: (context, validThruController) {
//                           return TextFormField(
//                             controller: validThruController,
//                             keyboardType: TextInputType.number,
//                             inputFormatters: [
//                               LengthLimitingTextInputFormatter(4),
//                               FilteringTextInputFormatter.digitsOnly,
//                             ],
//                             decoration: InputDecoration(
//                               hintText: "MM/YY",
//                               contentPadding: EdgeInsets.symmetric(
//                                 horizontal: 18.h,
//                                 vertical: 8.h,
//                               ),
//                             ),
//                             validator: (value) {
//                               if (value == null || value.isEmpty) {
//                                 return "Please enter valid thru date";
//                               } else if (value.length != 4) {
//                                 return "Invalid date format";
//                               }
//                               return null;
//                             },
//                           );
//                         },
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             ],
//           ),
//         ),
//         // ... (rest of the row, e.g., CVV input field)
//       ],
//     ),
//   );
// }// ... (rest of the code from the image)
//
// Expanded(
//   child: Padding(
//     padding: EdgeInsets.only(left: 8.h),
//     child: BlocSelector<AddCardOptionOneBloc, AddCardOptionOneState, AddCardOptionOneModel?>(
//       selector: (state) => state.addCardOptionOneModelObj,
//       builder: (context, addCardOptionOneModelObj) {
//         return CustomDropDown(
//           icon: Container(
//             margin: EdgeInsets.only(left: 12.h),
//             child: CustomImageView(
//               imagePath: ImageConstant.imgCheckmarkOnPrimary22x20,
//               height: 22.h,
//               width: 20.h,
//               fit: BoxFit.contain,
//             ),
//           ),
//           iconSize: 22.h,
//           hintText: "lbl_month".tr,
//           items: addCardOptionOneModelObj?.dropdownItemList ?? [],
//           contentPadding: EdgeInsets.fromLTRB(18.h, 8.h, 14.h, 8.h),
//         );
//       },
//     ),
//   ),
// ),// ... (rest of the code from the image)
//
// Expanded(
//   child: Padding(
//     padding: EdgeInsets.only(left: 8.h),
//     child: BlocSelector<AddCardOptionOneBloc, AddCardOptionOneState, AddCardOptionOneModel?>(
//       selector: (state) => state.addCardOptionOneModelObj,
//       builder: (context, addCardOptionOneModelObj) {
//         return CustomDropDown(
//           icon: Container(
//             margin: EdgeInsets.only(left: 12.h),
//             child: CustomImageView(
//               imagePath: ImageConstant.imgCheckmarkOnPrimary22x20,
//               height: 22.h,
//               width: 20.h,
//               fit: BoxFit.contain,
//             ),
//           ),
//           iconSize: 22.h,
//           hintText: "lbl_year".tr,
//           items: addCardOptionOneModelObj?.dropdownItemList1 ?? [],
//           contentPadding: EdgeInsets.fromLTRB(18.h, 8.h, 14.h, 8.h),
//         );
//       },
//     ),
//   ),
// ),
//
// SizedBox(height: 102.h),
// Column(
//   crossAxisAlignment: CrossAxisAlignment.start,
//   children: [
//     Text(
//       "lbl_cvv".tr,
//       style: theme.textTheme.bodyMedium,
//     ),
//     SizedBox(height: 6.h),
//     BlocSelector<AddCardOptionOneBloc, AddCardOptionOneState, TextEditingController?>(
//       selector: (state) => state.cvvtwoController,
//       builder: (context, cvvtwoController) {
//         return CustomTextFormField(
//           controller: cvvtwoController,
//           hintText: "lbl_cvv".tr,
//           suffix: Container(
//             margin: EdgeInsets.fromLTRB(12.h, 8.h, 14.h, 8.h),
//             child: CustomImageView(
//               imagePath: ImageConstant.imgEyeOnprimary,
//               height: 22.h,
//               width: 20.h,
//               fit: BoxFit.contain,
//             ),
//           ),
//           suffixConstraints: BoxConstraints(maxHeight: 40.h),
//           contentPadding: EdgeInsets.fromLTRB(18.h, 8.h, 14.h, 8.h),
//         );
//       },
//     ),
//   ],
// ),
//
// // ... (rest of the code)// ... (rest of the code from the image)
//
// Expanded(
//   child: Column(
//     crossAxisAlignment: CrossAxisAlignment.start,
//     children: [
//       Text(
//         "msg_card_holder_s_name".tr,
//         style: theme.textTheme.bodyMedium,
//       ),
//       SizedBox(height: 6.h),
//       BlocSelector<AddCardOptionOneBloc, AddCardOptionOneState, TextEditingController?>(
//         selector: (state) => state.nameController,
//         builder: (context, nameController) {
//           return CustomTextFormField(
//             controller: nameController,
//             hintText: "lbl_name_on_card".tr,
//             textInputAction: TextInputAction.done,
//             contentPadding: EdgeInsets.symmetric(
//               horizontal: 18.h,
//               vertical: 8.h,
//             ),
//             validator: (value) {
//               if (!isText(value)) {
//                 return "err_msg_please_enter_valid_text".tr;
//               }
//               return null;
//             },
//           );
//         },
//       ),
//     ],
//   ),
// ),
//
// // ... (rest of the code)
//
// Widget _buildStackproceed(BuildContext context) {
//   return SizedBox(
//     width: double.maxFinite,
//     height: 172.h,
//     child: Stack(
//       alignment: Alignment.bottomCenter,
//       children: [
//         Container(
//           width: double.maxFinite,
//           padding: EdgeInsets.symmetric(horizontal: 12.h, vertical: 16.h),
//           decoration: AppDecoration.fillBlack,
//           child: Column(
//             mainAxisSize: MainAxisSize.min,
//             children: [
//               CustomElevatedButton(
//                 height: 46.h,
//                 text: "msg_proceed_without".tr,
//                 margin: EdgeInsets.only(left: 6.h),
//                 buttonStyle: CustomButtonStyles.fillPrimary,
//                 buttonTextStyle: CustomTextStyles.titleMediumRoboto,
//               ),
//               SizedBox(height: 6.h),
//               CustomElevatedButton(
//                 height: 46.h,
//                 text: "msg_save_card".tr,
//                 buttonStyle: CustomButtonStyles.fillPrimary,
//                 buttonTextStyle: CustomTextStyles.titleMediumRoboto,
//               ),
//             ],
//           ),
//         ),
//       ],
//     ),
//   );
// }// ... (rest of the code from the image)
//
// Align(
//   alignment: Alignment.topCenter,
//   child: Container(
//     width: double.maxFinite,
//     padding: EdgeInsets.symmetric(horizontal: 14.h, vertical: 4.h),
//     decoration: AppDecoration.fillBlack,
//     child: Column(
//       mainAxisSize: MainAxisSize.min,
//       children: [
//         SizedBox(height: 10.h),
//         CustomElevatedButton(
//           height: 46.h,
//           text: "msg_save_card_and_proceed".tr,
//           margin: EdgeInsets.only(left: 4.h),
//           buttonStyle: CustomButtonStyles.fillPrimary,
//           buttonTextStyle: CustomTextStyles.titleMediumRoboto,
//         ),
//         SizedBox(height: 8.h),
//         Text(
//           "lbl_or".tr,
//           style: CustomTextStyles.bodyLargeRoboto_4,
//         ),
//         SizedBox(height: 8.h),
//         CustomElevatedButton(
//           height: 46.h,
//           text: "msg_save_card_only".tr,
//           buttonStyle: CustomButtonStyles.fillPrimary,
//           buttonTextStyle: CustomTextStyles.titleMediumRoboto,
//         ),
//       ],
//     ),
//   ),
// ),
//
// // ... (rest of the code)
//
// /// Section Widget
// Widget _buildAppbar(BuildContext context) {
//   return Align(
//     alignment: Alignment.topCenter,
//     child: CustomAppBar(
//       height: 40.h,
//       leadingWidth: 40.h,
//       leading: AppbarLeadingImage(
//         imagePath: ImageConstant.imgArrowLeft,
//         onTap: () {
//           _onTapArrowleftone(context);
//         },
//       ),
//     ),
//   );
// }
//
// /// Navigates to the previous screen.
// _onTapArrowleftone(BuildContext context) {
//   NavigatorService.goBack();
// }