import 'package:equatable/equatable.dart';
import 'search_result_item_model.dart';

/// This class defines the variables used in the [SearchResultPage].
class SearchResultModel extends Equatable {
  SearchResultModel({this.searchResultItemList = const []});

  final List<SearchResultItemModel> searchResultItemList;

  SearchResultModel copyWith({List<SearchResultItemModel>? searchResultItemList}) {
    return SearchResultModel(
      searchResultItemList: searchResultItemList ?? this.searchResultItemList,
    );
  }

  @override
  List<Object?> get props => [searchResultItemList];
}
