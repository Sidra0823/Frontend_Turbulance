import 'package:equatable/equatable.dart';

/// This class is used in the [SearchResultItemWidget] screen.
class SearchResultItemModel extends Equatable {
  SearchResultItemModel({this.id});

  final String? id;

  SearchResultItemModel copyWith({String? id}) {
    return SearchResultItemModel(
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [id ?? ""];
}
