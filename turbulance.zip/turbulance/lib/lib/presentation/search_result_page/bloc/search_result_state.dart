part of 'search_result_bloc.dart';

/// Represents the state of SearchResult in the application.
class SearchResultState extends Equatable {
  SearchResultState({this.searchResultModelObj});

  final SearchResultModel? searchResultModelObj;

  @override
  List<Object?> get props => [searchResultModelObj ?? SearchResultModel()];

  SearchResultState copyWith({SearchResultModel? searchResultModelObj}) {
    return SearchResultState(
      searchResultModelObj: searchResultModelObj ?? this.searchResultModelObj,
    );
  }
}
