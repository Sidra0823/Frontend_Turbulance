import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/search_result_item_model.dart';
import '../models/search_result_model.dart';

part 'search_result_event.dart';
part 'search_result_state.dart';

/// A bloc that manages the state of a SearchResult according to the event dispatched.
class SearchResultBloc extends Bloc<SearchResultEvent, SearchResultState> {
  SearchResultBloc(SearchResultState initialState) : super(initialState) {
    on<SearchResultInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      SearchResultInitialEvent event, Emitter<SearchResultState> emit) async {
    emit(state.copyWith(
      searchResultModelObj: state.searchResultModelObj?.copyWith(
        searchResultItemList: _fillSearchResultItemList(),
      ),
    ));
  }

  List<SearchResultItemModel> _fillSearchResultItemList() {
    return List.generate(7, (index) => SearchResultItemModel(id: 'Item $index'));
  }
}
