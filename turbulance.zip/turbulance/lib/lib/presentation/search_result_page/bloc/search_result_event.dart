part of 'search_result_bloc.dart';

/// Abstract class for all events that can be dispatched from the SearchResult widget.
abstract class SearchResultEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the SearchResult widget is first created.
class SearchResultInitialEvent extends SearchResultEvent {}
