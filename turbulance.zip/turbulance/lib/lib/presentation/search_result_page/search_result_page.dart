import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/search_result_bloc.dart';
import 'widgets/search_result_item_widget.dart';

class SearchResultPage extends StatelessWidget {
  const SearchResultPage({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => SearchResultBloc(
        SearchResultState(searchResultModelObj: SearchResultModel()),
      )..add(SearchResultInitialEvent()),
      child: const SearchResultPage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search Results')),
      body: BlocBuilder<SearchResultBloc, SearchResultState>(
        builder: (context, state) {
          final items = state.searchResultModelObj?.searchResultItemList ?? [];
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              return SearchResultItemWidget(items[index]);
            },
          );
        },
      ),
    );
  }
}
