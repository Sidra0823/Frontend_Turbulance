import 'package:flutter/material.dart';
import '../models/search_result_item_model.dart';

class SearchResultItemWidget extends StatelessWidget {
  const SearchResultItemWidget(this.searchResultItemModelObj, {Key? key}) : super(key: key);

  final SearchResultItemModel searchResultItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(8),
        ),
        child: ListTile(
          title: Text(searchResultItemModelObj.id ?? 'No Title'),
          leading: const Icon(Icons.folder),
        ),
      ),
    );
  }
}
