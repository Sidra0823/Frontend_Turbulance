import 'package:equatable/equatable.dart';

class SelectThePostModel extends Equatable {
  SelectThePostModel();

  SelectThePostModel copyWith() {
    return SelectThePostModel();
  }

  @override
  List<Object?> get props => [];
}
