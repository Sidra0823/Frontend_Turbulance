part of 'select_the_post_bloc.dart';

class SelectThePostState extends Equatable {
  final SelectThePostModel? selectThePostModelObj;

  SelectThePostState({this.selectThePostModelObj});

  @override
  List<Object?> get props => [selectThePostModelObj];

  SelectThePostState copyWith({SelectThePostModel? selectThePostModelObj}) {
    return SelectThePostState(
      selectThePostModelObj: selectThePostModelObj ?? this.selectThePostModelObj,
    );
  }
}
