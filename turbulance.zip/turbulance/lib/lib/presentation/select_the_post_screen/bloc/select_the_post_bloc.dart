import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/select_the_post_model.dart';

part 'select_the_post_event.dart';
part 'select_the_post_state.dart';

class SelectThePostBloc extends Bloc<SelectThePostEvent, SelectThePostState> {
  SelectThePostBloc(SelectThePostState initialState) : super(initialState);

  @override
  Stream<SelectThePostState> mapEventToState(SelectThePostEvent event) async* {
    if (event is SelectThePostInitialEvent) {
      yield* _onInitialize();
    }
  }

  Stream<SelectThePostState> _onInitialize() async* {
    // Perform any initialization logic here
    yield SelectThePostState(selectThePostModelObj: SelectThePostModel());
  }
}
