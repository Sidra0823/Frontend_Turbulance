part of 'select_the_post_bloc.dart';

abstract class SelectThePostEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class SelectThePostInitialEvent extends SelectThePostEvent {
  @override
  List<Object?> get props => [];
}
