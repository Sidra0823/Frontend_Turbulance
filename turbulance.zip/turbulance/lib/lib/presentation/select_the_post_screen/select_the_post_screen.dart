import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import 'bloc/select_the_post_bloc.dart';
import 'models/select_the_post_model.dart';

class SelectThePostScreen extends StatelessWidget {
  const SelectThePostScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<SelectThePostBloc>(
      create: (context) => SelectThePostBloc(
        SelectThePostState(selectThePostModelObj: SelectThePostModel()),
      )..add(SelectThePostInitialEvent()),
      child: SelectThePostScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SelectThePostBloc, SelectThePostState>(
      builder: (context, state) {
        return Scaffold(
          appBar: _buildAppbar(context),
          body: SafeArea(
            child: Column(
              children: [
                _buildRowRecentsOne(context),
                _buildRowCameraOne(context),
                _buildRowPexelsPhoto(context),
                _buildRowPexelsPhoto1(context),
              ],
            ),
          ),
          bottomNavigationBar: _buildColumnPostOne(context),
        );
      },
    );
  }

  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 44.0,
      leadingWidth: 42.0,
      leading: AppbarLeadingImage(
        imagePath: 'assets/images/arrow_right.png',
        height: 30.0,
        width: 30.0,
      ),
      title: AppbarSubtitleOne(
        text: "New Post",
      ),
    );
  }

  Widget _buildRowRecentsOne(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 32.0, right: 30.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Expanded(
            child: Row(
              children: [
                Align(
                  child: Text(
                    "Recents",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.arrow_downward),
                  onPressed: () {},
                ),
                ElevatedButton(
                  onPressed: () {},
                  child: Text("Select Item"),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRowCameraOne(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(left: 28.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Text("Camera"),
              Text("WhatsApp Images"),
              Text("WhatsApp Video"),
              Text("Snapchat"),
              Padding(
                padding: EdgeInsets.only(left: 12.0, top: 22.0),
                child: Text("Photos"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRowPexelsPhoto(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Row(
        children: [
          SizedBox(
            width: 144.0,
            child: Column(
              children: [
                Container(
                  height: 200.0,
                  width: double.infinity,
                  decoration: BoxDecoration(color: Colors.grey),
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Image.asset('assets/images/pexels_photo.jpg'),
                      Align(
                        alignment: Alignment.topRight,
                        child: IconButton(
                          icon: Icon(Icons.check),
                          onPressed: () {},
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRowPexelsPhoto1(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 200.0,
              decoration: BoxDecoration(color: Colors.grey),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Image.asset('assets/images/pexels_photo1.jpg'),
                  Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      icon: Icon(Icons.check),
                      onPressed: () {},
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildColumnPostOne(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 12.0),
      padding: EdgeInsets.symmetric(horizontal: 24.0, vertical: 8.0),
      decoration: BoxDecoration(
        color: Colors.grey[800],
        borderRadius: BorderRadius.circular(24.0),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Post",
            style: TextStyle(color: Colors.white),
          ),
          Text(
            "Videos",
            style: TextStyle(color: Colors.white),
          ),
        ],
      ),
    );
  }
}
