import 'package:equatable/equatable.dart';
import '../models/approval_model.dart';

part 'approval_event.dart';
part 'approval_state.dart';

/// A Bloc that manages the state of Approval according to the event that is dispatched to it.
class ApprovalBloc extends Bloc<ApprovalEvent, ApprovalState> {
  ApprovalBloc(ApprovalState initialState) : super(initialState) {
    on<ApprovalInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      ApprovalInitialEvent event,
      Emitter<ApprovalState> emit,
      ) async {
    // Initialization logic here, if needed
  }
}
