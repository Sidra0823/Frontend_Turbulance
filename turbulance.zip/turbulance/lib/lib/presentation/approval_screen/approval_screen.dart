import 'package:flutter/material.dart';
import '../../theme/custom_button_style.dart';
import '../../widgets/custom_elevated_button.dart';
import 'bloc/approval_bloc.dart';
import 'models/approval_model.dart';

class ApprovalScreen extends StatelessWidget {
  const ApprovalScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<ApprovalBloc>(
      create: (context) => ApprovalBloc(
        ApprovalState(
          approvalModelObj: ApprovalModel(),
        ),
      )..add(ApprovalInitialEvent()),
      child: ApprovalScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ApprovalBloc, ApprovalState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          body: SafeArea(
            child: Container(
              height: 888.h,
              width: double.maxFinite,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Container(
                    height: 888.h,
                    child: Stack(
                      alignment: Alignment.bottomCenter,
                      children: [
                        Align(
                          alignment: Alignment.topCenter,
                          child: Container(
                            height: 648.h,
                            child: Stack(
                              alignment: Alignment.center,
                              children: [
                                Opacity(
                                  opacity: 0.29,
                                  child: CustomImageView(
                                    imagePath: ImageConstant.imgImg72233peg1,
                                    height: 648.h,
                                    width: double.maxFinite,
                                  ),
                                ),
                                _buildColumnAlertAnd(context),
                              ],
                            ),
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            onTapTxtReadTermsCo(context);
                          },
                          child: Padding(
                            padding: EdgeInsets.only(bottom: 228.h),
                            child: RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: "msg_read_terms_condition".tr,
                                    style: CustomTextStyles.titleSmallNunitoMedium,
                                  ),
                                  TextSpan(
                                    text: "msg_https_turbula".tr,
                                    style: CustomTextStyles.titleSmallNunitoLightblueA700,
                                  ),
                                ],
                              ),
                              textAlign: TextAlign.center,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildColumnAlertAnd(BuildContext context) {
    return Align(
      alignment: Alignment.bottomCenter,
      child: Container(
        width: double.maxFinite,
        margin: EdgeInsets.only(bottom: 60.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "msg_alert_and_confirm".tr,
              style: CustomTextStyles.titleLargeBlack,
            ),
            SizedBox(height: 74.h),
            SizedBox(
              width: 294.h,
              child: Text(
                "msg_by_creating_account".tr,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
                textAlign: TextAlign.center,
                style: CustomTextStyles.titleLargeInriaSans.copyWith(height: 1.50),
              ),
            ),
            SizedBox(height: 12.h),
            CustomImageView(
              imagePath: ImageConstant.imgDownload63,
              height: 18.h,
              width: 20.h,
            ),
            SizedBox(
              width: 312.h,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CustomElevatedButton(
                    height: 50.h,
                    width: 124.h,
                    text: "lbl_decline".tr,
                    buttonStyle: CustomButtonStyles.fillGray,
                    buttonTextStyle: CustomTextStyles.titleMediumBlack900,
                  ),
                  CustomElevatedButton(
                    height: 50.h,
                    width: 124.h,
                    text: "lbl_accept".tr,
                    buttonStyle: CustomButtonStyles.fillPrimary,
                    buttonTextStyle: CustomTextStyles.titleMediumSemiBold,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void onTapTxtReadTermsCo(BuildContext context) {
    // Implement navigation or functionality for the terms and conditions link
  }
}
