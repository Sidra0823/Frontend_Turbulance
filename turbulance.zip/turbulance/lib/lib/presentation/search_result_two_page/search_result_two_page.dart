import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'bloc/search_result_two_bloc.dart';
import 'models/search_result_two_model.dart';
import 'widgets/search_result_item_widget.dart';

class SearchResultTwoPage extends StatelessWidget {
  const SearchResultTwoPage({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => SearchResultTwoBloc(
        SearchResultTwoState(
          searchResultTwoModelObj: SearchResultTwoModel(),
        ),
      )..add(SearchResultTwoInitialEvent()),
      child: const SearchResultTwoPage(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<SearchResultTwoBloc, SearchResultTwoState>(
        builder: (context, state) {
          final items = state.searchResultTwoModelObj?.searchResultItemList ?? [];
          return ListView.builder(
            itemCount: items.length,
            itemBuilder: (context, index) {
              return SearchResultItemWidget(items[index]);
            },
          );
        },
      ),
    );
  }
}
