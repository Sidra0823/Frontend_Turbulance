import 'package:equatable/equatable.dart';
import 'search_result_item_model.dart';

/// This class defines the variables used in the [search_result_two_page].
class SearchResultTwoModel extends Equatable {
  SearchResultTwoModel({this.searchResultItemList = const []});

  final List<SearchResultItemModel> searchResultItemList;

  SearchResultTwoModel copyWith({List<SearchResultItemModel>? searchResultItemList}) {
    return SearchResultTwoModel(
      searchResultItemList: searchResultItemList ?? this.searchResultItemList,
    );
  }

  @override
  List<Object?> get props => [searchResultItemList];
}
