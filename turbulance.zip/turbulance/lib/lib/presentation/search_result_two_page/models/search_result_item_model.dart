import 'package:equatable/equatable.dart';

/// This class is used in the [search_result_item_widget] screen.
class SearchResultItemModel extends Equatable {
  SearchResultItemModel({
    this.kingofdevils,
    this.kingofdevils1,
    this.kingofdevils2,
    this.sonukumar,
    this.id,
  });

  final String? kingofdevils;
  final String? kingofdevils1;
  final String? kingofdevils2;
  final String? sonukumar;
  final String? id;

  SearchResultItemModel copyWith({
    String? kingofdevils,
    String? kingofdevils1,
    String? kingofdevils2,
    String? sonukumar,
    String? id,
  }) {
    return SearchResultItemModel(
      kingofdevils: kingofdevils ?? this.kingofdevils,
      kingofdevils1: kingofdevils1 ?? this.kingofdevils1,
      kingofdevils2: kingofdevils2 ?? this.kingofdevils2,
      sonukumar: sonukumar ?? this.sonukumar,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [kingofdevils, kingofdevils1, kingofdevils2, sonukumar, id];
}
