import 'package:flutter/material.dart';
import '../models/search_result_item_model.dart';

class SearchResultItemWidget extends StatelessWidget {
  const SearchResultItemWidget(this.searchResultItemModelObj, {Key? key}) : super(key: key);

  final SearchResultItemModel searchResultItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: Row(
        children: [
          Image.asset(searchResultItemModelObj.kingofdevils ?? '', height: 64, width: 64),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(searchResultItemModelObj.kingofdevils2 ?? '',
                  style: Theme.of(context).textTheme.bodyLarge),
              Text(searchResultItemModelObj.sonukumar ?? '',
                  style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
        ],
      ),
    );
  }
}
