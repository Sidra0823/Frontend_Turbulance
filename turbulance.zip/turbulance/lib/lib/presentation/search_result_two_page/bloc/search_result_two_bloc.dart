import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/search_result_item_model.dart';
import '../models/search_result_two_model.dart';

part 'search_result_two_event.dart';
part 'search_result_two_state.dart';

/// A bloc that manages the state of SearchResultTwo according to the event dispatched.
class SearchResultTwoBloc extends Bloc<SearchResultTwoEvent, SearchResultTwoState> {
  SearchResultTwoBloc(SearchResultTwoState initialState) : super(initialState) {
    on<SearchResultTwoInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      SearchResultTwoInitialEvent event, Emitter<SearchResultTwoState> emit) async {
    emit(state.copyWith(
      searchResultTwoModelObj: state.searchResultTwoModelObj?.copyWith(
        searchResultItemList: fillSearchResultItemList(),
      ),
    ));
  }

  List<SearchResultItemModel> fillSearchResultItemList() {
    return [
      SearchResultItemModel(
        kingofdevils: ImageConstant.imgUntitledDesign64x64,
        kingofdevils1: ImageConstant.imgUnnamed3,
        kingofdevils2: "King Of Devil's",
        sonukumar: "Sonu Kumar",
      ),
      SearchResultItemModel(
        kingofdevils: ImageConstant.imgUntitledDesign64x64,
        kingofdevils1: ImageConstant.imgDownload50,
        kingofdevils2: "Dangerous Girl",
        sonukumar: "Liza Srivastava",
      ),
      // Add more items as needed
    ];
  }
}
