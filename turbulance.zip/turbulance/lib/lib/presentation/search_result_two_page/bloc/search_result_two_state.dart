part of 'search_result_two_bloc.dart';

/// Represents the state of SearchResultTwo in the application.
class SearchResultTwoState extends Equatable {
  SearchResultTwoState({this.searchResultTwoModelObj});

  final SearchResultTwoModel? searchResultTwoModelObj;

  @override
  List<Object?> get props => [searchResultTwoModelObj];

  SearchResultTwoState copyWith({SearchResultTwoModel? searchResultTwoModelObj}) {
    return SearchResultTwoState(
      searchResultTwoModelObj: searchResultTwoModelObj ?? this.searchResultTwoModelObj,
    );
  }
}
