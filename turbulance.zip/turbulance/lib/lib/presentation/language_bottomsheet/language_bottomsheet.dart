import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/language_bloc.dart';
import '../models/language_model.dart';

class LanguageBottomsheet extends StatelessWidget {
  const LanguageBottomsheet({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<LanguageBloc>(
      create: (context) => LanguageBloc(
        LanguageState(languageModel: LanguageModel()),
      )..add(LanguageInitialEvent()),
      child: const LanguageBottomsheet(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          _buildCheckbox(
            context: context,
            label: "English (UK)",
            selector: (state) => state.englishUK,
            onChange: (value) {
              context.read<LanguageBloc>().add(ChangeCheckBoxEvent(value: value));
            },
          ),
          // Add more checkboxes using `_buildCheckbox`
        ],
      ),
    );
  }

  Widget _buildCheckbox({
    required BuildContext context,
    required String label,
    required bool Function(LanguageState) selector,
    required void Function(bool?) onChange,
  }) {
    return BlocSelector<LanguageBloc, LanguageState, bool>(
      selector: selector,
      builder: (context, value) {
        return CheckboxListTile(
          title: Text(label),
          value: value,
          onChanged: onChange,
        );
      },
    );
  }
}
