import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/language_model.dart';

part 'language_event.dart';
part 'language_state.dart';

/// A bloc that manages the state of a Language according to the events dispatched to it.
class LanguageBloc extends Bloc<LanguageEvent, LanguageState> {
  LanguageBloc(LanguageState initialState) : super(initialState) {
    on<LanguageInitialEvent>(_onInitialize);
    on<ChangeCheckBoxEvent>((event, emit) {
      emit(state.copyWith(englishUK: event.value));
    });
    on<ChangeCheckBox1Event>((event, emit) {
      emit(state.copyWith(englishUS: event.value));
    });
    on<ChangeCheckBox2Event>((event, emit) {
      emit(state.copyWith(afrikaans: event.value));
    });
    on<ChangeCheckBox3Event>((event, emit) {
      emit(state.copyWith(bahasaMelayu: event.value));
    });
    // Continue adding similar event handlers...
  }

  void _onInitialize(LanguageInitialEvent event, Emitter<LanguageState> emit) {
    emit(
      state.copyWith(
        englishUK: false,
        englishUS: false,
        afrikaans: false,
        bahasaMelayu: false,
        // Add other languages...
      ),
    );
  }
}
