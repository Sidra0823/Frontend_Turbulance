part of 'language_bloc.dart';

/// Represents the state of the Language widget.
class LanguageState extends Equatable {
  final bool englishUK;
  final bool englishUS;
  final bool afrikaans;
  final bool bahasaMelayu;
  final LanguageModel? languageModel;

  LanguageState({
    this.englishUK = false,
    this.englishUS = false,
    this.afrikaans = false,
    this.bahasaMelayu = false,
    this.languageModel,
  });

  LanguageState copyWith({
    bool? englishUK,
    bool? englishUS,
    bool? afrikaans,
    bool? bahasaMelayu,
    LanguageModel? languageModel,
  }) {
    return LanguageState(
      englishUK: englishUK ?? this.englishUK,
      englishUS: englishUS ?? this.englishUS,
      afrikaans: afrikaans ?? this.afrikaans,
      bahasaMelayu: bahasaMelayu ?? this.bahasaMelayu,
      languageModel: languageModel ?? this.languageModel,
    );
  }

  @override
  List<Object?> get props => [
    englishUK,
    englishUS,
    afrikaans,
    bahasaMelayu,
    languageModel,
  ];
}
