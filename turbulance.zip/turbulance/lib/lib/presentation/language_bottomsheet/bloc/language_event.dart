part of 'language_bloc.dart';

/// Abstract class for all events related to Language.
abstract class LanguageEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Initial event for setting default states.
class LanguageInitialEvent extends LanguageEvent {}

/// Event for changing a checkbox state.
class ChangeCheckBoxEvent extends LanguageEvent {
  final bool value;

  ChangeCheckBoxEvent({required this.value});

  @override
  List<Object?> get props => [value];
}

/// Add similar events for other checkboxes...
class ChangeCheckBox1Event extends LanguageEvent {
  final bool value;

  ChangeCheckBox1Event({required this.value});

  @override
  List<Object?> get props => [value];
}
