import 'package:equatable/equatable.dart';

/// Data model for language options.
class LanguageModel extends Equatable {
  @override
  List<Object?> get props => [];
}
