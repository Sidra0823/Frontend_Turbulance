import 'package:flutter/material.dart';
import '../../../widgets/custom_radio_button.dart';
import '../models/listemailemailc_item_model.dart';

class ListemailemailcItemWidget extends StatelessWidget {
  final ListemailemailcItemModel listemailemailcItemModelObj;
  final Function(String)? onTapRadioGroup;

  ListemailemailcItemWidget(
      this.listemailemailcItemModelObj, {
        Key? key,
        this.onTapRadioGroup,
      }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomRadioButton(
      text: "lbl_email_email_com".tr,
      value: "lbl_email_email_com".tr,
      groupValue: listemailemailcItemModelObj.radioGroup!,
      onChange: (value) {
        onTapRadioGroup?.call(value);
      },
    );
  }
}
