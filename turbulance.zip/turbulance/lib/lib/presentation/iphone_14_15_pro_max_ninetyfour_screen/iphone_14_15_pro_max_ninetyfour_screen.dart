import 'package:flutter/material.dart';
import 'bloc/iphone_14_15_pro_max_ninetyfour_bloc.dart';
import 'models/iphone_14_15_pro_max_ninetyfour_model.dart';

class Iphone1415ProMaxNinetyfourScreen extends StatelessWidget {
  const Iphone1415ProMaxNinetyfourScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxNinetyfourBloc>(
      create: (context) => Iphone1415ProMaxNinetyfourBloc(
        Iphone1415ProMaxNinetyfourState(
          iphone1415ProMaxNinetyfourModelObj: Iphone1415ProMaxNinetyfourModel(),
        ),
      )..add(Iphone1415ProMaxNinetyfourInitialEvent()),
      child: const Iphone1415ProMaxNinetyfourScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Add your widgets and layout here
          ],
        ),
      ),
    );
  }
}
