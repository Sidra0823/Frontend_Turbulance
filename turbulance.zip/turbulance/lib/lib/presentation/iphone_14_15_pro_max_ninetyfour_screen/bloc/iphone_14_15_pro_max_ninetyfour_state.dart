part of 'iphone_14_15_pro_max_ninetyfour_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetyfour in the application.
class Iphone1415ProMaxNinetyfourState extends Equatable {
  final Iphone1415ProMaxNinetyfourModel? iphone1415ProMaxNinetyfourModelObj;

  Iphone1415ProMaxNinetyfourState({this.iphone1415ProMaxNinetyfourModelObj});

  @override
  List<Object?> get props => [iphone1415ProMaxNinetyfourModelObj];

  Iphone1415ProMaxNinetyfourState copyWith({
    Iphone1415ProMaxNinetyfourModel? iphone1415ProMaxNinetyfourModelObj,
  }) {
    return Iphone1415ProMaxNinetyfourState(
      iphone1415ProMaxNinetyfourModelObj: iphone1415ProMaxNinetyfourModelObj ??
          this.iphone1415ProMaxNinetyfourModelObj,
    );
  }
}
