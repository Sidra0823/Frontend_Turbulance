part of 'iphone_14_15_pro_max_ninetyfour_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// Iphone1415ProMaxNinetyfour widget.
abstract class Iphone1415ProMaxNinetyfourEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Iphone1415ProMaxNinetyfour widget is first created.
class Iphone1415ProMaxNinetyfourInitialEvent extends Iphone1415ProMaxNinetyfourEvent {}
