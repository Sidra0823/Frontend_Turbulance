import 'package:equatable/equatable.dart';
import '../models/iphone_14_15_pro_max_ninetyfour_model.dart';
import '../models/listemailemailc_item_model.dart';

part 'iphone_14_15_pro_max_ninetyfour_event.dart';
part 'iphone_14_15_pro_max_ninetyfour_state.dart';

/// A bloc that manages the state of an Iphone1415ProMaxNinetyfour according to the event that is dispatched to it.
class Iphone1415ProMaxNinetyfourBloc
    extends Bloc<Iphone1415ProMaxNinetyfourEvent, Iphone1415ProMaxNinetyfourState> {
  Iphone1415ProMaxNinetyfourBloc(Iphone1415ProMaxNinetyfourState initialState)
      : super(initialState) {
    on<Iphone1415ProMaxNinetyfourInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      Iphone1415ProMaxNinetyfourInitialEvent event,
      Emitter<Iphone1415ProMaxNinetyfourState> emit,
      ) async {
    emit(
      state.copyWith(
        iphone1415ProMaxNinetyfourModelObj: state.iphone1415ProMaxNinetyfourModelObj?.copyWith(
          listemailemailcItemList: _fillListemailemailcItems(),
        ),
      ),
    );
  }

  List<ListemailemailcItemModel> _fillListemailemailcItems() {
    return List.generate(2, (index) => ListemailemailcItemModel());
  }
}
