import 'package:equatable/equatable.dart';

/// This class is used in the listemailemailc_item_widget screen.
class ListemailemailcItemModel extends Equatable {
  final String? radioGroup;
  final String? id;

  ListemailemailcItemModel({this.radioGroup, this.id});

  ListemailemailcItemModel copyWith({String? radioGroup, String? id}) {
    return ListemailemailcItemModel(
      radioGroup: radioGroup ?? this.radioGroup,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [radioGroup, id];
}
