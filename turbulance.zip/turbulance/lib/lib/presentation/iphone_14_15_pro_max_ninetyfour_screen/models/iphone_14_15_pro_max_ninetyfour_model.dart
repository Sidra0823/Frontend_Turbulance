import 'package:equatable/equatable.dart';
import 'listemailemailc_item_model.dart';

/// This class defines the variables used in the Iphone1415ProMaxNinetyfourScreen.
class Iphone1415ProMaxNinetyfourModel extends Equatable {
  final List<ListemailemailcItemModel> listemailemailcItemList;

  Iphone1415ProMaxNinetyfourModel({this.listemailemailcItemList = const []});

  Iphone1415ProMaxNinetyfourModel copyWith({
    List<ListemailemailcItemModel>? listemailemailcItemList,
  }) {
    return Iphone1415ProMaxNinetyfourModel(
      listemailemailcItemList: listemailemailcItemList ?? this.listemailemailcItemList,
    );
  }

  @override
  List<Object?> get props => [listemailemailcItemList];
}
