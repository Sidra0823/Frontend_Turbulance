import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_switch.dart';
import 'bloc/security_privacy_bloc.dart';
import 'models/security_privacy_model.dart';

class SecurityPrivacyScreen extends StatelessWidget {
  const SecurityPrivacyScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<SecurityPrivacyBloc>(
      create: (context) => SecurityPrivacyBloc(SecurityPrivacyState(
        securityPrivacyModelObj: SecurityPrivacyModel(),
      ))..add(SecurityPrivacyInitialEvent()),
      child: const SecurityPrivacyScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: buildAppbar(context),
      body: SafeArea(
        top: false,
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(left: 34.h, top: 30.h, right: 34.h),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CustomIconButton(
                    height: 44.h,
                    width: 44.h,
                    padding: EdgeInsets.all(2.h),
                    decoration: IconButtonStyleHelper.fillOnPrimary,
                    child: CustomImageView(imagePath: ImageConstant.imgLocation),
                  ),
                  SizedBox(width: 18.h),
                  Text(
                    "msg_security_privacy".tr,
                    style: theme.textTheme.headlineMedium,
                  ),
                  SizedBox(height: 46.h),
                  CustomImageView(
                    imagePath: ImageConstant.imgProfilePicture80x80,
                    height: 80.h,
                    width: 82.h,
                    radius: BorderRadius.circular(40.h),
                    margin: EdgeInsets.only(right: 100.h),
                  ),
                  SizedBox(height: 18.h),
                  Text(
                    "lbl_turbulence".tr,
                    style: theme.textTheme.headlineLarge,
                  ),
                  SizedBox(height: 18.h),
                  Text(
                    "lbl_account_privacy".tr,
                    style: CustomTextStyles.titleMediumBold,
                  ),
                  SizedBox(height: 80.h),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      "msg_private_account_allow".tr,
                      maxLines: 5,
                      overflow: TextOverflow.ellipsis,
                      style: CustomTextStyles.titleMediumBold.copyWith(height: 1.52),
                    ),
                  ),
                  SizedBox(height: 24.h),
                  BlocSelector<SecurityPrivacyBloc, SecurityPrivacyState, bool?>(
                    selector: (state) => state.isSelectedSwitch,
                    builder: (context, isSelectedSwitch) {
                      return CustomSwitch(
                        value: isSelectedSwitch ?? false,
                        onChange: (value) {
                          context.read<SecurityPrivacyBloc>().add(ChangeSwitchEvent(value: value));
                        },
                      );
                    },
                  ),
                  SizedBox(height: 66.h),
                  BlocSelector<SecurityPrivacyBloc, SecurityPrivacyState, bool?>(
                    selector: (state) => state.isSelectedSwitch1,
                    builder: (context, isSelectedSwitch1) {
                      return CustomSwitch(
                        value: isSelectedSwitch1 ?? false,
                        onChange: (value) {
                          context.read<SecurityPrivacyBloc>().add(ChangeSwitch1Event(value: value));
                        },
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget buildAppbar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowLeft(context);
        },
      ),
    );
  }

  void onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
