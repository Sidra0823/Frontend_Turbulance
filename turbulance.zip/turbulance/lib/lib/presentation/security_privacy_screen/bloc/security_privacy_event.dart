part of 'security_privacy_bloc.dart';

/// Abstract class for all events that can be dispatched from the SecurityPrivacy widget.
abstract class SecurityPrivacyEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the SecurityPrivacy widget is first created.
class SecurityPrivacyInitialEvent extends SecurityPrivacyEvent {
  @override
  List<Object?> get props => [];
}

/// Event for changing switch.
class ChangeSwitchEvent extends SecurityPrivacyEvent {
  final bool value;

  ChangeSwitchEvent({required this.value});

  @override
  List<Object?> get props => [value];
}

/// Event for changing switch.
class ChangeSwitch1Event extends SecurityPrivacyEvent {
  final bool value;

  ChangeSwitch1Event({required this.value});

  @override
  List<Object?> get props => [value];
}
