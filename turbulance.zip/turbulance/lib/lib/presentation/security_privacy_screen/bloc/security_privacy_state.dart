part of 'security_privacy_bloc.dart';

/// Represents the state of SecurityPrivacy in the application.
class SecurityPrivacyState extends Equatable {
  final bool isSelectedSwitch;
  final bool isSelectedSwitch1;
  final SecurityPrivacyModel? securityPrivacyModelObj;

  SecurityPrivacyState({
    this.isSelectedSwitch = false,
    this.isSelectedSwitch1 = false,
    this.securityPrivacyModelObj,
  });

  @override
  List<Object?> get props => [isSelectedSwitch, isSelectedSwitch1, securityPrivacyModelObj];

  SecurityPrivacyState copyWith({
    bool? isSelectedSwitch,
    bool? isSelectedSwitch1,
    SecurityPrivacyModel? securityPrivacyModelObj,
  }) {
    return SecurityPrivacyState(
      isSelectedSwitch: isSelectedSwitch ?? this.isSelectedSwitch,
      isSelectedSwitch1: isSelectedSwitch1 ?? this.isSelectedSwitch1,
      securityPrivacyModelObj: securityPrivacyModelObj ?? this.securityPrivacyModelObj,
    );
  }
}
