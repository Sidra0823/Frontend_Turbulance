import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/security_privacy_model.dart';

part 'security_privacy_event.dart';
part 'security_privacy_state.dart';

/// A bloc that manages the state of a SecurityPrivacy according to the event that is dispatched to it.
class SecurityPrivacyBloc extends Bloc<SecurityPrivacyEvent, SecurityPrivacyState> {
  SecurityPrivacyBloc(SecurityPrivacyState initialState) : super(initialState) {
    on<SecurityPrivacyInitialEvent>(_onInitialize);
    on<ChangeSwitchEvent>(_changeSwitch);
    on<ChangeSwitch1Event>(_changeSwitch1);
  }

  Future<void> _onInitialize(
      SecurityPrivacyInitialEvent event,
      Emitter<SecurityPrivacyState> emit,
      ) async {
    emit(state.copyWith(
      isSelectedSwitch: false,
      isSelectedSwitch1: false,
    ));
  }

  void _changeSwitch(
      ChangeSwitchEvent event,
      Emitter<SecurityPrivacyState> emit,
      ) {
    emit(state.copyWith(isSelectedSwitch: event.value));
  }

  void _changeSwitch1(
      ChangeSwitch1Event event,
      Emitter<SecurityPrivacyState> emit,
      ) {
    emit(state.copyWith(isSelectedSwitch1: event.value));
  }
}
