import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [SecurityPrivacyScreen],
/// and is typically used to hold data that is passed between different parts of the application.
class SecurityPrivacyModel extends Equatable {
  SecurityPrivacyModel();

  SecurityPrivacyModel copyWith() {
    return SecurityPrivacyModel();
  }

  @override
  List<Object?> get props => [];
}
