import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';

import '../models/iphone_14_15_pro_max_ninety_model.dart';

part 'iphone_14_15_pro_max_ninety_event.dart';
part 'iphone_14_15_pro_max_ninety_state.dart';

/// A bloc that manages the state of Iphone1415ProMaxNinety according to the event that is dispatched.
class Iphone1415ProMaxNinetyBloc
    extends Bloc<Iphone1415ProMaxNinetyEvent, Iphone1415ProMaxNinetyState> {
  Iphone1415ProMaxNinetyBloc(Iphone1415ProMaxNinetyState initialState)
      : super(initialState) {
    on<Iphone1415ProMaxNinetyInitialEvent>(_onInitialize);
    on<ChangePasswordVisibilityEvent>(_changePasswordVisibility);
  }

  Future<void> _onInitialize(
      Iphone1415ProMaxNinetyInitialEvent event,
      Emitter<Iphone1415ProMaxNinetyState> emit,
      ) async {
    emit(state.copyWith(
      emailController: TextEditingController(),
      passwordController: TextEditingController(),
      isShowPassword: true,
    ));
  }

  void _changePasswordVisibility(
      ChangePasswordVisibilityEvent event,
      Emitter<Iphone1415ProMaxNinetyState> emit,
      ) {
    emit(state.copyWith(isShowPassword: event.value));
  }
}
