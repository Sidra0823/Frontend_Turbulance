part of 'iphone_14_15_pro_max_ninety_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinety in the application.
class Iphone1415ProMaxNinetyState extends Equatable {
  final TextEditingController? emailController;
  final TextEditingController? passwordController;
  final bool isShowPassword;
  final Iphone1415ProMaxNinetyModel? iphone1415ProMaxNinetyModelObj;

  Iphone1415ProMaxNinetyState({
    this.emailController,
    this.passwordController,
    this.isShowPassword = true,
    this.iphone1415ProMaxNinetyModelObj,
  });

  @override
  List<Object?> get props => [
    emailController,
    passwordController,
    isShowPassword,
    iphone1415ProMaxNinetyModelObj,
  ];

  Iphone1415ProMaxNinetyState copyWith({
    TextEditingController? emailController,
    TextEditingController? passwordController,
    bool? isShowPassword,
    Iphone1415ProMaxNinetyModel? iphone1415ProMaxNinetyModelObj,
  }) {
    return Iphone1415ProMaxNinetyState(
      emailController: emailController ?? this.emailController,
      passwordController: passwordController ?? this.passwordController,
      isShowPassword: isShowPassword ?? this.isShowPassword,
      iphone1415ProMaxNinetyModelObj:
      iphone1415ProMaxNinetyModelObj ?? this.iphone1415ProMaxNinetyModelObj,
    );
  }
}
