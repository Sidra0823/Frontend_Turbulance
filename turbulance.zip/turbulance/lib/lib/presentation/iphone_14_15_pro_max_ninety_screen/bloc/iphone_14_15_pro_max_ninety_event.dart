part of 'iphone_14_15_pro_max_ninety_bloc.dart';

/// Abstract class for all events that can be dispatched from the Iphone1415ProMaxNinety widget.
abstract class Iphone1415ProMaxNinetyEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Iphone1415ProMaxNinety widget is first created.
class Iphone1415ProMaxNinetyInitialEvent extends Iphone1415ProMaxNinetyEvent {}

/// Event for changing password visibility.
class ChangePasswordVisibilityEvent extends Iphone1415ProMaxNinetyEvent {
  final bool value;

  ChangePasswordVisibilityEvent({required this.value});

  @override
  List<Object?> get props => [value];
}
