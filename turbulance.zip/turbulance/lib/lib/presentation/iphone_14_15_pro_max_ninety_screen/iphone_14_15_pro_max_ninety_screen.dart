import 'package:flutter/material.dart';

import '../../../core/app_export.dart';
import '../../../core/utils/validation_functions.dart';
import '../../widgets/custom_floating_text_field.dart';
import '../../widgets/custom_icon_button.dart';
import 'bloc/iphone_14_15_pro_max_ninety_bloc.dart';
import 'models/iphone_14_15_pro_max_ninety_model.dart';

class Iphone1415ProMaxNinetyScreen extends StatelessWidget {
  Iphone1415ProMaxNinetyScreen({Key? key}) : super(key: key);

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxNinetyBloc>(
      create: (context) => Iphone1415ProMaxNinetyBloc(
        Iphone1415ProMaxNinetyState(
          iphone1415ProMaxNinetyModelObj: Iphone1415ProMaxNinetyModel(),
        ),
      )..add(Iphone1415ProMaxNinetyInitialEvent()),
      child: Iphone1415ProMaxNinetyScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 54.h, vertical: 182.h),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                CustomIconButton(
                  height: 72.h,
                  width: 72.h,
                  decoration: IconButtonStyleHelper.outlineOnPrimaryTL16,
                  padding: EdgeInsets.all(14.h),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgFavoriteOnPrimary,
                  ),
                ),
                SizedBox(height: 14.h),
                RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: "msg_use_your_apple_id".tr,
                        style: CustomTextStyles.bodyLargeRoboto_1,
                      ),
                      TextSpan(
                        text: "lbl_turbulence".tr,
                        style: CustomTextStyles.bodyLargeRoboto_1,
                      ),
                    ],
                  ),
                  textAlign: TextAlign.left,
                ),
                SizedBox(height: 12.h),
                BlocSelector<Iphone1415ProMaxNinetyBloc,
                    Iphone1415ProMaxNinetyState, TextEditingController?>(
                  selector: (state) => state.emailController,
                  builder: (context, emailController) {
                    return CustomFloatingTextField(
                      controller: emailController,
                      labelText: "lbl_apple_id".tr,
                      labelStyle: CustomTextStyles.bodyLargeRoboto_2,
                      hintText: "lbl_apple_id".tr,
                      contentPadding: EdgeInsets.symmetric(
                        horizontal: 16.h,
                        vertical: 8.h,
                      ),
                      borderDecoration:
                      FloatingTextFormFieldStyleHelper.outlineOnPrimary,
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
