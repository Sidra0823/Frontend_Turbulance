import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_ninety_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class Iphone1415ProMaxNinetyModel extends Equatable {
  Iphone1415ProMaxNinetyModel();

  Iphone1415ProMaxNinetyModel copyWith() {
    return Iphone1415ProMaxNinetyModel();
  }

  @override
  List<Object?> get props => [];
}
