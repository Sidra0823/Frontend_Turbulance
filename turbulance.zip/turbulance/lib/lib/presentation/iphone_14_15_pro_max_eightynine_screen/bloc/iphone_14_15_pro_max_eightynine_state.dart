part of 'iphone_14_15_pro_max_122_bloc.dart';

/// Represents the state of Iphone1415ProMax122 in the application.
class Iphone1415ProMax122State extends Equatable {
  Iphone1415ProMax122State({this.iphone1415ProMax122ModelObj});

  final Iphone1415ProMax122Model? iphone1415ProMax122ModelObj;

  @override
  List<Object?> get props => [iphone1415ProMax122ModelObj];

  /// Returns a new state with a modified iphone1415ProMax122ModelObj
  Iphone1415ProMax122State copyWith({Iphone1415ProMax122Model? iphone1415ProMax122ModelObj}) {
    return Iphone1415ProMax122State(
      iphone1415ProMax122ModelObj: iphone1415ProMax122ModelObj ?? this.iphone1415ProMax122ModelObj,
    );
  }
}
