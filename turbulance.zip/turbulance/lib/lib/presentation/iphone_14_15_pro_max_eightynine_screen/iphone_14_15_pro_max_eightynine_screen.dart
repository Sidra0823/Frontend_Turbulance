import 'package:flutter/material.dart';
import '../../widgets/custom_icon_button.dart';
import '../../widgets/custom_text_form_field.dart';

class Iphone1415ProMaxEightynineScreen extends StatelessWidget {
  const Iphone1415ProMaxEightynineScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone1415ProMaxEightynineBloc>(
      create: (context) => Iphone1415ProMaxEightynineBloc(
        Iphone1415ProMaxEightynineState(
          iphone1415ProMaxEightynineModelObj: Iphone1415ProMaxEightynineModel(),
        ),
      )..add(Iphone1415ProMaxEightynineInitialEvent()),
      child: const Iphone1415ProMaxEightynineScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(top: 182.h),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              CustomIconButton(
                height: 72.h,
                width: 72.h,
                padding: EdgeInsets.all(14.h),
                decoration: IconButtonStyleHelper.outlineOnPrimaryTL16,
                child: CustomImageView(
                  imagePath: ImageConstant.imgFavoriteOnPrimary,
                ),
              ),
              SizedBox(height: 14.h),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: "msg_use_your_apple_id".tr,
                      style: CustomTextStyles.bodyLargeRoboto1,
                    ),
                    TextSpan(
                      text: "lbl_turbulence".tr,
                      style: CustomTextStyles.bodyLargeRoboto1,
                    ),
                  ],
                ),
                textAlign: TextAlign.left,
              ),
              SizedBox(height: 12.h),
              BlocSelector<Iphone1415ProMaxEightynineBloc,
                  Iphone1415ProMaxEightynineState, TextEditingController?>(
                selector: (state) => state.inputOneController,
                builder: (context, inputOneController) {
                  return CustomTextFormField(
                    width: 220.h,
                    controller: inputOneController,
                    hintText: "lbl_apple_id".tr,
                    hintStyle: CustomTextStyles.bodyLargeRoboto2,
                    textInputAction: TextInputAction.done,
                  );
                },
              ),
              SizedBox(height: 16.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "msg_forgotten_your_apple".tr,
                    style: CustomTextStyles.bodySmallRobotoOnPrimary12_1,
                  ),
                  SizedBox(width: 4.h),
                  CustomImageView(
                    imagePath: ImageConstant.imgArrowUpRight,
                    height: 14.h,
                    width: 14.h,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
