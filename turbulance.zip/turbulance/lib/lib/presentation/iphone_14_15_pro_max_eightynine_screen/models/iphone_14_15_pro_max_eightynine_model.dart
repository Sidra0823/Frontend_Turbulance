import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_122_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class Iphone1415ProMax122Model extends Equatable {
  // Constructor
  Iphone1415ProMax122Model();

  // A copyWith method allows you to clone the current model with optional changes
  Iphone1415ProMax122Model copyWith() {
    return Iphone1415ProMax122Model();
  }

  // Override the props for equatable comparison
  @override
  List<Object?> get props => [];
}
