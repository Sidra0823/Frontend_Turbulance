import 'package:flutter/material.dart';
import '../models/single_photo_item_model.dart'; // Fixed the import path

// ignore_for_file: must_be_immutable

class SinglePhotoItemWidget extends StatelessWidget {
  // Constructor with a required parameter for the SinglePhotoItemModel
  SinglePhotoItemWidget(this.singlePhotoItemModelObj, {Key? key}) : super(key: key);

  // Property for the SinglePhotoItemModel object
  final SinglePhotoItemModel singlePhotoItemModelObj;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 30.h, // Assuming 30.h is a valid value from your app's design system
      child: CustomImageView(
        imagePath: ImageConstant.imgCamera, // Assuming this is defined somewhere in your code
        height: 30.h, // Assuming 30.h is a valid value from your app's design system
        width: 30.h, // Assuming 30.h is a valid value from your app's design system
      ),
    );
  }
}