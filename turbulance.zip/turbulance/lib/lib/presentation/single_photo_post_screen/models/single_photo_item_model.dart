import 'package:equatable/equatable.dart';

/// This class is used in the [single_photo_item_widget] screen.
class SinglePhotoItemModel extends Equatable {
  // Constructor with optional 'id' parameter
  SinglePhotoItemModel({this.id});

  // Property for the photo item
  String? id;

  // copyWith method to create a new instance with updated values
  SinglePhotoItemModel copyWith({String? id}) {
    return SinglePhotoItemModel(
      id: id ?? this.id, // Use the provided id or retain the existing one
    );
  }

  @override
  List<Object?> get props => [id]; // Equatable property for comparison
}
