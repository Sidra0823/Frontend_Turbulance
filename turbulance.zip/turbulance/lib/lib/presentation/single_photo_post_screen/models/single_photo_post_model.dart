import 'package:equatable/equatable.dart';
import 'single_photo_item_model.dart';  // Fixed the import path

/// This class defines the variables used in the [single_photo_post_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class SinglePhotoPostModel extends Equatable {
  // Constructor with optional parameter 'singlePhotoItemList'
  SinglePhotoPostModel({this.singlePhotoItemList = const []});

  // List of SinglePhotoItemModel objects
  final List<SinglePhotoItemModel> singlePhotoItemList;

  // copyWith method to create a new instance with updated 'singlePhotoItemList'
  SinglePhotoPostModel copyWith({
    List<SinglePhotoItemModel>? singlePhotoItemList,
  }) {
    return SinglePhotoPostModel(
      singlePhotoItemList: singlePhotoItemList ?? this.singlePhotoItemList,
    );
  }

  @override
  List<Object?> get props => [singlePhotoItemList];  // Equatable property for comparison
}
