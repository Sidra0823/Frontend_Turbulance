import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../core/app_export.dart'; // Your core exports
import '../bloc/single_photo_post_bloc.dart'; // Correct path for the bloc
import '../models/single_photo_item_model.dart'; // Correct path for the model
import '../widgets/single_photo_item_widget.dart'; // Assuming you have the widget

class SinglePhotoPostScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Single Photo Post'),
        centerTitle: true,
      ),
      body: BlocProvider<SinglePhotoPostBloc>(
        create: (_) => SinglePhotoPostBloc(SinglePhotoPostState()),
        child: SinglePhotoPostBody(),
      ),
    );
  }
}

class SinglePhotoPostBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SinglePhotoPostBloc, SinglePhotoPostState>(
      builder: (context, state) {
        // Checking if the state has a valid SinglePhotoPostModel
        if (state.singlePhotoPostModelObj == null ||
            state.singlePhotoPostModelObj!.singlePhotoItemList.isEmpty) {
          return Center(child: Text('No items available.'));
        }

        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Display the pin input (if needed)
              _buildPinInput(state.pinViewController),

              // Display the list of SinglePhotoItemWidget
              Expanded(
                child: ListView.builder(
                  itemCount: state.singlePhotoPostModelObj!.singlePhotoItemList.length,
                  itemBuilder: (context, index) {
                    var item = state.singlePhotoPostModelObj!.singlePhotoItemList[index];
                    return SinglePhotoItemWidget(item);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildPinInput(TextEditingController? controller) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20.0),
      child: PinCodeTextField(
        controller: controller,
        appContext: context,
        length: 4,
        onChanged: (value) {},
        pinTheme: PinTheme(
          shape: PinCodeFieldShape.underline,
          borderRadius: BorderRadius.circular(5),
          fieldHeight: 40,
          fieldWidth: 40,
          activeColor: Colors.blue,
          inactiveColor: Colors.grey,
        ),
      ),
    );
  }
}
