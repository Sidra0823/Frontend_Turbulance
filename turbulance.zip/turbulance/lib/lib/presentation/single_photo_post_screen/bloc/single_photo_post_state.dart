part of 'single_photo_post_bloc.dart';

/// Represents the state of SinglePhotoPost in the application.

class SinglePhotoPostState extends Equatable {
  // Constructor for SinglePhotoPostState
  SinglePhotoPostState({
    this.pinViewController,
    this.singlePhotoPostModelObj,
  });

  // Properties for the state
  TextEditingController? pinViewController;
  SinglePhotoPostModel? singlePhotoPostModelObj;

  @override
  List<Object?> get props => [pinViewController, singlePhotoPostModelObj];

  /// Method to copy the state and make modifications to it
  SinglePhotoPostState copyWith({
    TextEditingController? pinViewController,
    SinglePhotoPostModel? singlePhotoPostModelObj,
  }) {
    return SinglePhotoPostState(
      pinViewController: pinViewController ?? this.pinViewController,
      singlePhotoPostModelObj: singlePhotoPostModelObj ?? this.singlePhotoPostModelObj,
    );
  }
}
