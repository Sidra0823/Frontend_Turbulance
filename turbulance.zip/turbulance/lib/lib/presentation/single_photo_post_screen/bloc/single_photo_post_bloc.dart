import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
// Assuming you're using pin_code_fields
import '../models/single_photo_item_model.dart'; // Correct import statement
import '../models/single_photo_post_model.dart'; // Correct import statement

part 'single_photo_post_event.dart';
part 'single_photo_post_state.dart';

/// A bloc that manages the state of a SinglePhotoPost according to the event that is dispatched to it.
class SinglePhotoPostBloc extends Bloc<SinglePhotoPostEvent, SinglePhotoPostState> {
  SinglePhotoPostBloc(SinglePhotoPostState initialState) : super(initialState) {
    on<SinglePhotoPostInitialEvent>(_onInitialize);
  }

  /// Handles the initialization event for SinglePhotoPost
  Future<void> _onInitialize(
      SinglePhotoPostInitialEvent event,
      Emitter<SinglePhotoPostState> emit,
      ) async {
    // Simulate some initialization or data loading process (e.g., initializing controllers, fetching data)
    emit(state.copyWith(
      pinViewController: TextEditingController(),
    ));

    // You can add logic to update your state with a list of SinglePhotoItemModel
    emit(state.copyWith(
      singlePhotoPostModelObj: state.singlePhotoPostModelObj?.copyWith(
        singlePhotoItemList: _fillSinglePhotoItemList(),
      ),
    ));
  }

  /// Fills the list with SinglePhotoItemModel objects
  List<SinglePhotoItemModel> _fillSinglePhotoItemList() {
    return List.generate(2, (index) => SinglePhotoItemModel());
  }
}
