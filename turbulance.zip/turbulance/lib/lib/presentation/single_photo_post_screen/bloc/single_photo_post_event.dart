part of 'single_photo_post_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// SinglePhotoPost widget.
///
/// Events must be immutable and implement the [Equatable] interface.
class SinglePhotoPostEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the SinglePhotoPost widget is first created.
class SinglePhotoPostInitialEvent extends SinglePhotoPostEvent {
  @override
  List<Object?> get props => [];
}
