import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';

import '../models/iphone_14_15_pro_max_ninetythree_model.dart';
import '../models/listfast_and_item_model.dart';

part 'iphone_14_15_pro_max_ninetythree_event.dart';
part 'iphone_14_15_pro_max_ninetythree_state.dart';

/// A bloc that manages the state of Iphone1415ProMaxNinetythree.
class Iphone1415ProMaxNinetythreeBloc extends Bloc<
    Iphone1415ProMaxNinetythreeEvent, Iphone1415ProMaxNinetythreeState> {
  Iphone1415ProMaxNinetythreeBloc(Iphone1415ProMaxNinetythreeState initialState)
      : super(initialState) {
    on<Iphone1415ProMaxNinetythreeInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      Iphone1415ProMaxNinetythreeInitialEvent event,
      Emitter<Iphone1415ProMaxNinetythreeState> emit,
      ) async {
    emit(
      state.copyWith(
        iphone1415ProMaxNinetythreeModelObj:
        state.iphone1415ProMaxNinetythreeModelObj?.copyWith(
          listFastAndItemList: _fillListFastAndItemList(),
        ),
      ),
    );
  }

  List<ListfastAndItemModel> _fillListFastAndItemList() {
    return [
      ListfastAndItemModel(
        fastAndEasy: ImageConstant.imgKeyIcon,
        fastAndEasy1: "Fast and easy",
        signIntoApps:
        "Sign in to apps and websites with the Apple ID you already have.",
      ),
      ListfastAndItemModel(
        fastAndEasy: ImageConstant.imgHandIcon,
        fastAndEasy1: "Respect for your privacy",
        signIntoApps:
        "Apps can only ask for your name and email. Apple will never track you.",
      ),
      ListfastAndItemModel(
        fastAndEasy: ImageConstant.imgSecurityIcon,
        fastAndEasy1: "Hide your email",
        signIntoApps:
        "Keep your email address private but still receive messages from the app.",
      ),
    ];
  }
}
