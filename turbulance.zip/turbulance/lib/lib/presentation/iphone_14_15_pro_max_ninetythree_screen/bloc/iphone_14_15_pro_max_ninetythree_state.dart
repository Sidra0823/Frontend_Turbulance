part of 'iphone_14_15_pro_max_ninetythree_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetythree.
class Iphone1415ProMaxNinetythreeState extends Equatable {
  Iphone1415ProMaxNinetythreeState({
    this.iphone1415ProMaxNinetythreeModelObj,
  });

  final Iphone1415ProMaxNinetythreeModel? iphone1415ProMaxNinetythreeModelObj;

  @override
  List<Object?> get props => [iphone1415ProMaxNinetythreeModelObj];

  Iphone1415ProMaxNinetythreeState copyWith({
    Iphone1415ProMaxNinetythreeModel? iphone1415ProMaxNinetythreeModelObj,
  }) {
    return Iphone1415ProMaxNinetythreeState(
      iphone1415ProMaxNinetythreeModelObj:
      iphone1415ProMaxNinetythreeModelObj ??
          this.iphone1415ProMaxNinetythreeModelObj,
    );
  }
}
