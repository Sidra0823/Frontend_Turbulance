part of 'iphone_14_15_pro_max_ninetythree_bloc.dart';

/// Abstract class for all events that can be dispatched.
abstract class Iphone1415ProMaxNinetythreeEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event dispatched on initialization.
class Iphone1415ProMaxNinetythreeInitialEvent
    extends Iphone1415ProMaxNinetythreeEvent {}
