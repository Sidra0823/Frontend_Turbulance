import 'package:equatable/equatable.dart';
import 'listfast_and_item_model.dart';

/// Model for Iphone1415ProMaxNinetythree screen.
class Iphone1415ProMaxNinetythreeModel extends Equatable {
  Iphone1415ProMaxNinetythreeModel({
    this.listFastAndItemList = const [],
  });

  final List<ListfastAndItemModel> listFastAndItemList;

  Iphone1415ProMaxNinetythreeModel copyWith({
    List<ListfastAndItemModel>? listFastAndItemList,
  }) {
    return Iphone1415ProMaxNinetythreeModel(
      listFastAndItemList: listFastAndItemList ?? this.listFastAndItemList,
    );
  }

  @override
  List<Object?> get props => [listFastAndItemList];
}
