import 'package:equatable/equatable.dart';

/// Model for individual items in the list.
class ListfastAndItemModel extends Equatable {
  ListfastAndItemModel({
    this.fastAndEasy,
    this.fastAndEasy1,
    this.signIntoApps,
    this.id,
  });

  final String? fastAndEasy;
  final String? fastAndEasy1;
  final String? signIntoApps;
  final String? id;

  ListfastAndItemModel copyWith({
    String? fastAndEasy,
    String? fastAndEasy1,
    String? signIntoApps,
    String? id,
  }) {
    return ListfastAndItemModel(
      fastAndEasy: fastAndEasy ?? this.fastAndEasy,
      fastAndEasy1: fastAndEasy1 ?? this.fastAndEasy1,
      signIntoApps: signIntoApps ?? this.signIntoApps,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [fastAndEasy, fastAndEasy1, signIntoApps, id];
}
