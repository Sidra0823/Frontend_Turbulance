import 'package:flutter/material.dart';
import '../../../core/app_export.dart';
import '../models/listfast_and_item_model.dart';

// ignore_for_file: must_be_immutable
class ListfastAndItemWidget extends StatelessWidget {
  final ListfastAndItemModel listfastAndItemModelObj;

  ListfastAndItemWidget(this.listfastAndItemModelObj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(right: 6.0),  // Adjusted for padding
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // CustomImageView widget to display the image
          CustomImageView(
            imagePath: listfastAndItemModelObj.fastAndEasy!,
            height: 56.0,  // Adjusted for height
            width: 56.0,  // Adjusted for width
            alignment: Alignment.center,
          ),
          SizedBox(width: 8.0),  // Space between image and text
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 4.0),  // Top padding for text
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title text
                  Text(
                    listfastAndItemModelObj.fastAndEasy1!,
                    style: CustomTextStyles.titleMediumRobotoSemiBold,
                  ),
                  SizedBox(height: 2.0),  // Space between title and description
                  // Description text
                  Text(
                    listfastAndItemModelObj.signIntoApps!,
                    style: CustomTextStyles.bodySmallRobotoOnPrimary12_1,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
