import 'package:flutter/material.dart';
import '../models/listfast_and_item_model.dart';

/// Widget for displaying individual items.
class ListfastAndItemWidget extends StatelessWidget {
  const ListfastAndItemWidget(
      this.listFastAndItemModelObj, {
        Key? key,
      }) : super(key: key);

  final ListfastAndItemModel listFastAndItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.asset(
            listFastAndItemModelObj.fastAndEasy!,
            height: 56,
            width: 56,
            alignment: Alignment.center,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    listFastAndItemModelObj.fastAndEasy1!,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    listFastAndItemModelObj.signIntoApps!,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
