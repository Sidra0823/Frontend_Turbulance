import 'package:flutter/material.dart';

import '../models/videos_post_item_model.dart';

// ignore_for_file: must_be_immutable
class VideosPostItemWidget extends StatelessWidget {
  VideosPostItemWidget(this.videosPostItemModelObj, {Key? key})
      : super(key: key);

  final VideosPostItemModel videosPostItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 124.h,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: videosPostItemModelObj.downloadfiftytw!,
            height: 124.h,
            width: 124.h,
            radius: BorderRadius.circular(14.h),
          ),
          Positioned(
            top: 6.h,
            right: 6.h,
            child: CustomImageView(
              imagePath: ImageConstant.imgCalendar,
              height: 30.h,
              width: 32.h,
            ),
          ),
        ],
      ),
    );
  }
}
