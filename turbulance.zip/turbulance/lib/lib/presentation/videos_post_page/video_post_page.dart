import 'package:flutter/material.dart';
import 'package:responsive_grid_list/responsive_grid_list.dart';
import 'bloc/videos_post_bloc.dart';
import 'models/videos_post_item_model.dart';
import 'models/videos_post_model.dart';
import 'widgets/videos_post_item_widget.dart';

// ignore_for_file: must_be_immutable
class VideosPostPage extends StatefulWidget {
  const VideosPostPage({Key? key}) : super(key: key);

  @override
  VideosPostPageState createState() => VideosPostPageState();

  static Widget builder(BuildContext context) {
    return BlocProvider<VideosPostBloc>(
      create: (context) => VideosPostBloc(
        VideosPostState(videosPostModelObj: VideosPostModel()),
      )..add(VideosPostInitialEvent()),
      child: VideosPostPage(),
    );
  }
}

class VideosPostPageState extends State<VideosPostPage>
    with AutomaticKeepAliveClientMixin<VideosPostPage> {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: _buildScrollView(context),
      ),
    );
  }

  /// Section Widget
  Widget _buildScrollView(BuildContext context) {
    return SingleChildScrollView(
      primary: true,
      child: Container(
        width: double.maxFinite,
        padding: EdgeInsets.symmetric(horizontal: 20.h, vertical: 8.h),
        child: Column(
          children: [
            SizedBox(height: 12.h),
            BlocSelector<VideosPostBloc, VideosPostState, VideosPostModel?>(
              selector: (state) => state.videosPostModelObj,
              builder: (context, videosPostModelObj) {
                return ResponsiveGridList(
                  minItemWidth: 100, // Example width; adjust based on UI requirements
                  minItemsPerRow: 3,
                  maxItemsPerRow: 3,
                  horizontalGridSpacing: 8.h,
                  verticalGridSpacing: 8.h,
                  children: List.generate(
                    videosPostModelObj?.videosPostItemList.length ?? 0,
                        (index) {
                      VideosPostItemModel model =
                          videosPostModelObj?.videosPostItemList[index] ??
                              VideosPostItemModel();
                      return VideosPostItemWidget(model);
                    },
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
