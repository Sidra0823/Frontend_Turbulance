import 'package:equatable/equatable.dart';

import 'videos_post_item_model.dart';

/// This class defines the variables used in the [videos_post_page],
/// and is typically used to hold data that is passed between different parts of the application.
// ignore_for_file: must_be_immutable
class VideosPostModel extends Equatable {
  VideosPostModel({this.videosPostItemList = const []});

  List<VideosPostItemModel> videosPostItemList;

  VideosPostModel copyWith({List<VideosPostItemModel>? videosPostItemList}) {
    return VideosPostModel(
      videosPostItemList: videosPostItemList ?? this.videosPostItemList,
    );
  }

  @override
  List<Object?> get props => [videosPostItemList];
}
