import 'package:equatable/equatable.dart';


/// This class is used in the [videos_post_item_widget] screen.
// ignore_for_file: must_be_immutable
class VideosPostItemModel extends Equatable {
  VideosPostItemModel({String? downloadfiftytw, String? id}) {
    this.downloadfiftytw = downloadfiftytw ?? ImageConstant.imgDownload52;
    this.id = id ?? "";
  }

  String? downloadfiftytw;
  String? id;

  VideosPostItemModel copyWith({
    String? downloadfiftytw,
    String? id,
  }) {
    return VideosPostItemModel(
      downloadfiftytw: downloadfiftytw ?? this.downloadfiftytw,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [downloadfiftytw, id];
}
