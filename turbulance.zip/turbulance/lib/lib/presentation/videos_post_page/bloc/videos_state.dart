part of 'videos_post_bloc.dart';

/// Represents the state of VideosPost in the application.
// ignore_for_file: must_be_immutable
class VideosPostState extends Equatable {
  VideosPostState({this.videosPostModelObj});

  VideosPostModel? videosPostModelObj;

  @override
  List<Object?> get props => [videosPostModelObj];

  VideosPostState copyWith({VideosPostModel? videosPostModelObj}) {
    return VideosPostState(
      videosPostModelObj: videosPostModelObj ?? this.videosPostModelObj,
    );
  }
}
