import 'package:equatable/equatable.dart';
import '../models/videos_post_item_model.dart';

part 'videos_post_event.dart';
part 'videos_post_state.dart';

/// A bloc that manages the state of a VideosPost according to the event that is dispatched to it.
class VideosPostBloc extends Bloc<VideosPostEvent, VideosPostState> {
  VideosPostBloc(VideosPostState initialState) : super(initialState) {
    on<VideosPostInitialEvent>(_onInitialize);
  }

  /// Handles the initialization event.
  Future<void> _onInitialize(
      VideosPostInitialEvent event,
      Emitter<VideosPostState> emit,
      ) async {
    emit(
      state.copyWith(
        videosPostModelObj: state.videosPostModelObj?.copyWith(
          videosPostItemList: fillVideosPostItemList(),
        ),
      ),
    );
  }

  /// Generates a list of [VideosPostItemModel] for initial state.
  List<VideosPostItemModel> fillVideosPostItemList() {
    return [
      VideosPostItemModel(imagePath: ImageConstant.imgDownload52),
      VideosPostItemModel(imagePath: ImageConstant.imgDownload53),
      VideosPostItemModel(imagePath: ImageConstant.imgDownload54),
      VideosPostItemModel(imagePath: ImageConstant.imgDownload56),
      VideosPostItemModel(imagePath: ImageConstant.imgImage25),
      VideosPostItemModel(imagePath: ImageConstant.imgDownload58),
      VideosPostItemModel(imagePath: ImageConstant.imgDownload59),
      VideosPostItemModel(imagePath: ImageConstant.imgDownload68),
      VideosPostItemModel(imagePath: ImageConstant.imgImage25),
    ];
  }
}
