part of 'videos_post_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// VideosPost widget.
///
/// Events must be immutable and implement the [Equatable] interface.
abstract class VideosPostEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the VideosPost widget is first created.
class VideosPostInitialEvent extends VideosPostEvent {
  @override
  List<Object?> get props => [];
}
