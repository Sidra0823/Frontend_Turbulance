import 'package:flutter/material.dart';
import '../../widgets/app_bar/appbar_leading_image_one.dart';
import '../../widgets/app_bar/appbar_subtitle_two.dart';
import '../../widgets/app_bar/appbar_trailing_button.dart';
import '../../widgets/app_bar/appbar_trailing_button_one.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_text_form_field.dart';
import 'bloc/live_video_bloc.dart';
import 'models/live_video_model.dart';
import 'models/live_video_one_item_model.dart';
import 'widgets/live_video_one_item_widget.dart';

class LiveVideoScreen extends StatelessWidget {
  const LiveVideoScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<LiveVideoBloc>(
      create: (context) => LiveVideoBloc(
        LiveVideoState(liveVideoModelObj: LiveVideoModel()),
      )..add(LiveVideoInitialEvent()),
      child: const LiveVideoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      extendBodyBehindAppBar: true,
      backgroundColor: appTheme.black900,
      appBar: _buildAppBar(context),
      body: Container(
        width: double.maxFinite,
        height: SizeUtils.height,
        decoration: AppDecoration.fillBlack9002,
        child: SafeArea(
          child: SingleChildScrollView(
            child: Container(
              padding: EdgeInsets.only(left: 8.h, right: 8.h, bottom: 22.h),
              child: Column(
                children: [
                  SizedBox(height: 410.h),
                  _buildStackLunaOne(context),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 62.h,
      leadingWidth: 73.h,
      leading: AppbarLeadingImageOne(
        imagePath: ImageConstant.imgProfilePicture,
        height: 50.h,
        width: 50.h,
        margin: EdgeInsets.only(left: 23.h, top: 5.h, bottom: 6.h),
      ),
      title: AppbarSubtitleTwo(
        text: "lbl_turbulance".tr,
        margin: EdgeInsets.only(left: 14.h),
      ),
      actions: [
        Padding(
          padding: EdgeInsets.only(right: 15.h),
          child: Column(
            children: [
              AppbarTrailingButton(),
              AppbarTrailingButtonOne(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildStackLunaOne(BuildContext context) {
    return Container(
      height: 352.h,
      width: double.maxFinite,
      margin: EdgeInsets.only(left: 12.h),
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Padding(
              padding: EdgeInsets.only(left: 4.h),
              child: BlocSelector<LiveVideoBloc, LiveVideoState, LiveVideoModel?>(
                selector: (state) => state.liveVideoModelObj,
                builder: (context, liveVideoModelObj) {
                  return ListView.separated(
                    padding: EdgeInsets.zero,
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    separatorBuilder: (context, index) => SizedBox(height: 18.h),
                    itemCount: liveVideoModelObj?.liveVideoOneItemList.length ?? 0,
                    itemBuilder: (context, index) {
                      final model = liveVideoModelObj?.liveVideoOneItemList[index] ?? LiveVideoOneItemModel();
                      return LiveVideoOneItemWidget(model);
                    },
                  );
                },
              ),
            ),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgTelevision,
            height: 30.h,
            width: 32.h,
            margin: EdgeInsets.only(right: 36.h, bottom: 42.h),
          ),
          CustomImageView(
            imagePath: ImageConstant.imgAirplane,
            height: 48.h,
            width: 42.h,
            margin: EdgeInsets.only(right: 14.h),
          ),
          BlocSelector<LiveVideoBloc, LiveVideoState, TextEditingController?>(
            selector: (state) => state.commentController,
            builder: (context, commentController) {
              return CustomTextFormField(
                width: 328.h,
                controller: commentController,
                hintText: "lbl_comment".tr,
                hintStyle: CustomTextStyles.titleLargeExtraBold,
                textInputAction: TextInputAction.done,
                alignment: Alignment.bottomLeft,
                suffix: Container(
                  margin: EdgeInsets.fromLTRB(12.h, 8.h, 14.h, 8.h),
                  child: CustomImageView(
                    imagePath: ImageConstant.imgNotification,
                    height: 22.h,
                    width: 22.h,
                    fit: BoxFit.contain,
                  ),
                ),
                suffixConstraints: BoxConstraints(maxHeight: 44.h),
                contentPadding: EdgeInsets.fromLTRB(18.h, 8.h, 14.h, 8.h),
                borderDecoration: TextFormFieldStyleHelper.outlineOnPrimaryTL10,
                filled: false,
              );
            },
          ),
        ],
      ),
    );
  }
}
