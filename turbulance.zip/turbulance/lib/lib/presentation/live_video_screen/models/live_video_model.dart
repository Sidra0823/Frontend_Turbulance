import 'package:equatable/equatable.dart';
import 'live_video_one_item_model.dart';

/// This class defines the variables used in the [live_video_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class LiveVideoModel extends Equatable {
  LiveVideoModel({this.liveVideoOneItemList = const []});

  final List<LiveVideoOneItemModel> liveVideoOneItemList;

  LiveVideoModel copyWith({
    List<LiveVideoOneItemModel>? liveVideoOneItemList,
  }) {
    return LiveVideoModel(
      liveVideoOneItemList: liveVideoOneItemList ?? this.liveVideoOneItemList,
    );
  }

  @override
  List<Object?> get props => [liveVideoOneItemList];
}
