import 'package:equatable/equatable.dart';

/// This class is used in the [live_video_one_item_widget] screen.
class LiveVideoOneItemModel extends Equatable {
  LiveVideoOneItemModel({
    this.lunaTwo,
    this.hello,
    this.id = "",
  });

  final String? lunaTwo;
  final String? hello;
  final String? id;

  LiveVideoOneItemModel copyWith({
    String? lunaTwo,
    String? hello,
    String? id,
  }) {
    return LiveVideoOneItemModel(
      lunaTwo: lunaTwo ?? this.lunaTwo,
      hello: hello ?? this.hello,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [lunaTwo, hello, id];
}
