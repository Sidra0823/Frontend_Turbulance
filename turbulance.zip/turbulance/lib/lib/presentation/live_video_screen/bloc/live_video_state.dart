part of 'live_video_bloc.dart';

/// Represents the state of LiveVideo in the application.
class LiveVideoState extends Equatable {
  LiveVideoState({this.commentController, this.liveVideoModelObj});

  final TextEditingController? commentController;
  final LiveVideoModel? liveVideoModelObj;

  @override
  List<Object?> get props => [commentController, liveVideoModelObj];

  LiveVideoState copyWith({
    TextEditingController? commentController,
    LiveVideoModel? liveVideoModelObj,
  }) {
    return LiveVideoState(
      commentController: commentController ?? this.commentController,
      liveVideoModelObj: liveVideoModelObj ?? this.liveVideoModelObj,
    );
  }
}
