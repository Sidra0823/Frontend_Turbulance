import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:equatable/equatable.dart';
import '../models/live_video_model.dart';
import '../models/live_video_one_item_model.dart';

part 'live_video_event.dart';
part 'live_video_state.dart';

/// A bloc that manages the state of a LiveVideo according to the event that is dispatched to it.
class LiveVideoBloc extends Bloc<LiveVideoEvent, LiveVideoState> {
  LiveVideoBloc(LiveVideoState initialState) : super(initialState) {
    on<LiveVideoInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      LiveVideoInitialEvent event,
      Emitter<LiveVideoState> emit,
      ) async {
    emit(
      state.copyWith(
        commentController: TextEditingController(),
        liveVideoModelObj: state.liveVideoModelObj?.copyWith(
          liveVideoOneItemList: fillLiveVideoOneItemList(),
        ),
      ),
    );
  }

  List<LiveVideoOneItemModel> fillLiveVideoOneItemList() {
    return [
      LiveVideoOneItemModel(lunaTwo: "Luna", hello: "Hello..."),
      LiveVideoOneItemModel(lunaTwo: "Claire", hello: "Hello..."),
      LiveVideoOneItemModel(lunaTwo: "Johnny", hello: "Hello..."),
      LiveVideoOneItemModel(lunaTwo: "Maria", hello: "Hello..."),
      LiveVideoOneItemModel(lunaTwo: "Lana", hello: "Hello..."),
      LiveVideoOneItemModel(),
      LiveVideoOneItemModel(),
      LiveVideoOneItemModel(),
      LiveVideoOneItemModel(),
      LiveVideoOneItemModel(),
    ];
  }
}
