import 'package:flutter/material.dart';
import '../models/live_video_one_item_model.dart';

class LiveVideoOneItemWidget extends StatelessWidget {
  final LiveVideoOneItemModel liveVideoOneItemModelObj;

  const LiveVideoOneItemWidget(this.liveVideoOneItemModelObj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Row(
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgLock,
            width: 44.h,
            height: 44.h,
          ),
          Padding(
            padding: EdgeInsets.only(left: 8.h),
            child: Column(
              children: [
                Text(
                  liveVideoOneItemModelObj.lunaTwo!,
                  style: CustomTextStyles.titleMediumBold_1,
                ),
                Text(
                  liveVideoOneItemModelObj.hello!,
                  style: CustomTextStyles.titleSmallNunito,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
