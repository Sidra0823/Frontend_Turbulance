import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_14_15_pro_max_ninetyeight_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class Iphone1415ProMaxNinetyeightModel extends Equatable {
  Iphone1415ProMaxNinetyeightModel();

  Iphone1415ProMaxNinetyeightModel copyWith() {
    return Iphone1415ProMaxNinetyeightModel();
  }

  @override
  List<Object?> get props => [];
}
