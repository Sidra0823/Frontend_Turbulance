import 'package:flutter/material.dart';
import 'bloc/iphone_14_15_pro_max_ninetyeight_bloc.dart';
import 'models/iphone_14_15_pro_max_ninetyeight_model.dart';

class Iphone1415ProMaxNinetyeightScreen extends StatelessWidget {
  const Iphone1415ProMaxNinetyeightScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider(
      create: (context) => Iphone1415ProMaxNinetyeightBloc(
        Iphone1415ProMaxNinetyeightState(
          iphone1415ProMaxNinetyeightModelObj: Iphone1415ProMaxNinetyeightModel(),
        ),
      )..add(Iphone1415ProMaxNinetyeightInitialEvent()),
      child: const Iphone1415ProMaxNinetyeightScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<Iphone1415ProMaxNinetyeightBloc, Iphone1415ProMaxNinetyeightState>(
      builder: (context, state) {
        return Scaffold(
          backgroundColor: appTheme.black900,
          body: SafeArea(
            child: SizedBox(
              height: double.infinity,
              width: double.infinity,
              child: Center(
                child: Text(
                  "Iphone1415ProMaxNinetyeight Screen",
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
