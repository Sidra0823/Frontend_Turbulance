import 'package:equatable/equatable.dart';
import '../models/iphone_14_15_pro_max_ninetyeight_model.dart';

part 'iphone_14_15_pro_max_ninetyeight_event.dart';
part 'iphone_14_15_pro_max_ninetyeight_state.dart';

/// A bloc that manages the state of Iphone1415ProMaxNinetyeight according to the event that is dispatched to it.
class Iphone1415ProMaxNinetyeightBloc extends Bloc<Iphone1415ProMaxNinetyeightEvent, Iphone1415ProMaxNinetyeightState> {
  Iphone1415ProMaxNinetyeightBloc(Iphone1415ProMaxNinetyeightState initialState) : super(initialState) {
    on<Iphone1415ProMaxNinetyeightInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(
      Iphone1415ProMaxNinetyeightInitialEvent event,
      Emitter<Iphone1415ProMaxNinetyeightState> emit,
      ) async {
    // Initialization logic
  }
}
