part of 'iphone_14_15_pro_max_ninetyeight_bloc.dart';

/// Abstract class for all events that can be dispatched from the Iphone1415ProMaxNinetyeight widget.
abstract class Iphone1415ProMaxNinetyeightEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the Iphone1415ProMaxNinetyeight widget is first created.
class Iphone1415ProMaxNinetyeightInitialEvent extends Iphone1415ProMaxNinetyeightEvent {
  @override
  List<Object?> get props => [];
}
