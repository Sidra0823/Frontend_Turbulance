part of 'iphone_14_15_pro_max_ninetyeight_bloc.dart';

/// Represents the state of Iphone1415ProMaxNinetyeight in the application.
class Iphone1415ProMaxNinetyeightState extends Equatable {
  final Iphone1415ProMaxNinetyeightModel? iphone1415ProMaxNinetyeightModelObj;

  Iphone1415ProMaxNinetyeightState({this.iphone1415ProMaxNinetyeightModelObj});

  @override
  List<Object?> get props => [iphone1415ProMaxNinetyeightModelObj];

  Iphone1415ProMaxNinetyeightState copyWith({
    Iphone1415ProMaxNinetyeightModel? iphone1415ProMaxNinetyeightModelObj,
  }) {
    return Iphone1415ProMaxNinetyeightState(
      iphone1415ProMaxNinetyeightModelObj: iphone1415ProMaxNinetyeightModelObj ?? this.iphone1415ProMaxNinetyeightModelObj,
    );
  }
}
