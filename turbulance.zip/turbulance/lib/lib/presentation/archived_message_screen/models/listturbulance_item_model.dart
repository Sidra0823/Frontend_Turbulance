import 'package:equatable/equatable.dart';


/// This class is used in the [listturbulance_item_widget] screen.

// ignore_for_file: must_be_immutable
class ListTurbulanceItemModel extends Equatable {
  ListTurbulanceItemModel({
    this.turbulanceOne,
    this.turbulanceTwo,
    this.thankYouFor,
    this.time,
    this.group206,
    this.id,
  }) {
    turbulanceOne ??= ImageConstant.imgDownload471;
    turbulanceTwo ??= "Turbulance";
    thankYouFor ??= "Thank you for sharing";
    time ??= "3:03pm";
    group206 ??= "1";
    id ??= "";
  }

  String? turbulanceOne;
  String? turbulanceTwo;
  String? thankYouFor;
  String? time;
  String? group206;
  String? id;

  ListTurbulanceItemModel copyWith({
    String? turbulanceOne,
    String? turbulanceTwo,
    String? thankYouFor,
    String? time,
    String? group206,
    String? id,
  }) {
    return ListTurbulanceItemModel(
      turbulanceOne: turbulanceOne ?? this.turbulanceOne,
      turbulanceTwo: turbulanceTwo ?? this.turbulanceTwo,
      thankYouFor: thankYouFor ?? this.thankYouFor,
      time: time ?? this.time,
      group206: group206 ?? this.group206,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [
    turbulanceOne,
    turbulanceTwo,
    thankYouFor,
    time,
    group206,
    id,
  ];
}
