import 'package:equatable/equatable.dart';

import 'listturbulance_item_model.dart';

/// This class defines the variables used in the [archived_message_screen],
/// and is typically used to hold data that is passed between different parts of the application.

// ignore_for_file: must_be_immutable
class ArchivedMessageModel extends Equatable {
  ArchivedMessageModel({this.listTurbulanceItemList = const []});

  final List<ListTurbulanceItemModel> listTurbulanceItemList;

  ArchivedMessageModel copyWith({
    List<ListTurbulanceItemModel>? listTurbulanceItemList,
  }) {
    return ArchivedMessageModel(
      listTurbulanceItemList: listTurbulanceItemList ?? this.listTurbulanceItemList,
    );
  }

  @override
  List<Object?> get props => [listTurbulanceItemList];
}
