import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_search_view.dart';
import 'bloc/archived_message_bloc.dart';
import 'models/archived_message_model.dart';
import 'models/listturbulance_item_model.dart';
import 'widgets/listturbulance_item_widget.dart';

class ArchivedMessageScreen extends StatelessWidget {
  const ArchivedMessageScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<ArchivedMessageBloc>(
      create: (context) => ArchivedMessageBloc(ArchivedMessageState(
        archivedMessageModelObj: ArchivedMessageModel(),
      ))..add(ArchivedMessageInitialEvent()),
      child: const ArchivedMessageScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      appBar: _buildAppBar(context),
      body: SafeArea(
        top: false,
        child: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SizedBox(
              width: double.maxFinite,
              child: Column(
                children: [
                  SizedBox(height: 2.h),
                  Padding(
                    padding: EdgeInsets.only(left: 28.h, right: 22.h),
                    child: BlocSelector<ArchivedMessageBloc, ArchivedMessageState, TextEditingController?>(
                      selector: (state) => state.searchController,
                      builder: (context, searchController) {
                        return CustomSearchView(
                          controller: searchController,
                          hintText: "lbl_search".tr,
                          contentPadding: EdgeInsets.fromLTRB(22.h, 6.h, 12.h, 6.h),
                        );
                      },
                    ),
                  ),
                  SizedBox(height: 20.h),
                  _buildListTurbulance(context),
                  SizedBox(height: 64.h),
                  _buildStackThunderLog(context),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  /// Section Widget - App Bar
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () => onTapArrowLeft(context),
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "lbl_archived".tr,
      ),
    );
  }

  /// Section Widget - List of Turbulance Items
  Widget _buildListTurbulance(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(left: 48.h, right: 42.h),
      child: BlocSelector<ArchivedMessageBloc, ArchivedMessageState, ArchivedMessageModel?>(
        selector: (state) => state.archivedMessageModelObj,
        builder: (context, archivedMessageModelObj) {
          return ListView.separated(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            separatorBuilder: (context, index) {
              return SizedBox(height: 30.h);
            },
            itemCount: archivedMessageModelObj?.listTurbulanceItemList.length ?? 0,
            itemBuilder: (context, index) {
              final ListTurbulanceItemModel model = archivedMessageModelObj?.listTurbulanceItemList[index] ?? ListTurbulanceItemModel();
              return ListTurbulanceItemWidget(model);
            },
          );
        },
      ),
    );
  }

  /// Section Widget - Stack with Thunder Logo
  Widget _buildStackThunderLog(BuildContext context) {
    return SizedBox(
      height: 78.h,
      width: double.maxFinite,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgThunderLogo2,
            height: 78.h,
            width: double.maxFinite,
            radius: BorderRadius.vertical(top: Radius.circular(14.h)),
          ),
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: 34.h),
                width: double.maxFinite,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    CustomImageView(
                      imagePath: ImageConstant.imgHomeOnPrimary,
                      height: 30.h,
                      width: 32.h,
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgCalendar,
                      height: 30.h,
                      width: 32.h,
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgClose,
                      height: 30.h,
                      width: 30.h,
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgClosePrimary,
                      height: 30.h,
                      width: 32.h,
                    ),
                    CustomImageView(
                      imagePath: ImageConstant.imgTockOnPrimary,
                      height: 30.h,
                      width: 32.h,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Navigate to the previous screen
  void onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
