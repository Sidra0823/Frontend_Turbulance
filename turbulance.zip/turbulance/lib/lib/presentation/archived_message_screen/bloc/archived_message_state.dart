part of 'archived_message_bloc.dart';

/// Represents the state of ArchivedMessage in the application.
// ignore_for_file: must_be_immutable

class ArchivedMessageState extends Equatable {
  ArchivedMessageState({
    this.searchController,
    this.pinViewController,
    this.archivedMessageModelObj,
  });

  TextEditingController? searchController;
  TextEditingController? pinViewController;
  ArchivedMessageModel? archivedMessageModelObj;

  @override
  List<Object?> get props => [
    searchController,
    pinViewController,
    archivedMessageModelObj,
  ];

  ArchivedMessageState copyWith({
    TextEditingController? searchController,
    TextEditingController? pinViewController,
    ArchivedMessageModel? archivedMessageModelObj,
  }) {
    return ArchivedMessageState(
      searchController: searchController ?? this.searchController,
      pinViewController: pinViewController ?? this.pinViewController,
      archivedMessageModelObj:
      archivedMessageModelObj ?? this.archivedMessageModelObj,
    );
  }
}
