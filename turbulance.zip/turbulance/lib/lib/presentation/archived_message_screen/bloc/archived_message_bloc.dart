import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';

import '../models/archived_message_model.dart';
import '../models/list_turbulance_item_model.dart';

part 'archived_message_event.dart';
part 'archived_message_state.dart';

/// A bloc that manages the state of an ArchivedMessage according to the event that is dispatched to it.
class ArchivedMessageBloc extends Bloc<ArchivedMessageEvent, ArchivedMessageState> {
  ArchivedMessageBloc(ArchivedMessageState initialState) : super(initialState) {
    on<ArchivedMessageInitialEvent>(_onInitialize);
  }

  void _onInitialize(
      ArchivedMessageInitialEvent event,
      Emitter<ArchivedMessageState> emit,
      ) async {
    emit(
      state.copyWith(
        searchController: TextEditingController(),
        pinViewController: TextEditingController(),
      ),
    );

    emit(
      state.copyWith(
        archivedMessageModelObj: state.archivedMessageModelObj?.copyWith(
          listTurbulanceItemList: _fillListTurbulanceItems(),
        ),
      ),
    );
  }

  List<ListTurbulanceItemModel> _fillListTurbulanceItems() {
    return [
      ListTurbulanceItemModel(
        turbulanceOne: ImageConstant.imgDownload471,
        turbulanceTwo: "Turbulance",
        thankYouFor: "Thank you for sharing",
        time: "3:03pm",
        group206: "1",
      ),
      ListTurbulanceItemModel(
        turbulanceOne: ImageConstant.imgDownload4730x30,
        thankYouFor: "Thank you for sharing",
        time: "3:03pm",
        group206: "1",
      ),
      ListTurbulanceItemModel(
        turbulanceOne: ImageConstant.imgDownload4730x30,
        thankYouFor: "Thank you for sharing",
      ),
      // Add more items as needed
    ];
  }
}
