part of 'archived_message_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// ArchivedMessage widget.
///
/// Events must be immutable and implement the [Equatable] interface.
abstract class ArchivedMessageEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the ArchivedMessage widget is first created.
class ArchivedMessageInitialEvent extends ArchivedMessageEvent {}
