import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../models/listturbulance_item_model.dart';

// ignore_for_file: must_be_immutable
class ListTurbulanceItemWidget extends StatelessWidget {
  final ListTurbulanceItemModel listTurbulanceItemModelObj;

  // Constructor with key and the model object
  ListTurbulanceItemWidget(this.listTurbulanceItemModelObj, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Align(
          alignment: Alignment.topCenter,
          child: SizedBox(
            height: 40.h,
            width: 42.h,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomImageView(
                  imagePath: listTurbulanceItemModelObj.turbulanceOne!,
                  height: 48.h,
                  width: 42.h,
                  radius: BorderRadius.circular(10.h),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    height: 10.h,
                    width: 10.h,
                    decoration: BoxDecoration(
                      color: appTheme.green60001,
                      borderRadius: BorderRadius.circular(5.h),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        Expanded(
          child: Padding(
            padding: EdgeInsets.only(left: 10.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: double.maxFinite,
                  child: Row(
                    children: [
                      Text(
                        listTurbulanceItemModelObj.turbulanceTwo!,
                        style: theme.textTheme.titleMedium,
                      ),
                      Expanded(
                        child: PinCodeTextField(
                          appContext: context,
                          controller: pinViewController,
                          length: 1,
                          obscureText: true,
                          obscuringCharacter: '',
                          keyboardType: TextInputType.number,
                          autoDismissKeyboard: true,
                          showCursor: false,
                          inputFormatters: [
                            FilteringTextInputFormatter.digitsOnly,
                          ],
                          enableActiveFill: true,
                          onChanged: (value) {
                            pinViewController?.text = value;
                          },
                          pinTheme: PinTheme(
                            fieldHeight: 14.h,
                            fieldWidth: 8.h,
                            shape: PinCodeFieldShape.circle,
                            selectedFillColor: appTheme.gray50001,
                            selectedColor: appTheme.gray50001,
                            activeFillColor: appTheme.gray50001,
                            activeColor: appTheme.gray50001,
                            inactiveFillColor: appTheme.gray50001,
                            inactiveColor: appTheme.gray50001,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  listTurbulanceItemModelObj.thankYouFor!,
                  style: CustomTextStyles.titleSmallNunitoGray50002,
                ),
                Container(
                  width: 90.h,
                  margin: EdgeInsets.only(left: 4.h),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        listTurbulanceItemModelObj.time!,
                        style: CustomTextStyles.labelMediumNunitoGray50003,
                      ),
                      SizedBox(height: 4.h),
                      Container(
                        width: 20.h,
                        height: 20.h,
                        alignment: Alignment.center,
                        decoration: AppDecoration.fillRedA.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorder5,
                        ),
                        child: Text(
                          listTurbulanceItemModelObj.group206!,
                          textAlign: TextAlign.center,
                          style: CustomTextStyles.labelLargeOnPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
