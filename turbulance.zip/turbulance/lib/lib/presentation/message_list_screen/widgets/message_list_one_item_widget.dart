import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import '../models/message_list_item_model.dart';

class MessageListItemWidget extends StatelessWidget {
  MessageListItemWidget(this.messageListItemModelObj, {Key? key}) : super(key: key);

  final MessageListItemModel messageListItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Row(
            children: [
              SizedBox(
                height: 40.h,
                width: 42.h,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CustomImageView(
                      imagePath: messageListItemModelObj.turbulanceOne!,
                      height: 40.h,
                      width: 40.h,
                      radius: BorderRadius.circular(10.h),
                    ),
                    Align(
                      alignment: Alignment.topRight,
                      child: Container(
                        height: 10.h,
                        width: 10.h,
                        decoration: BoxDecoration(
                          color: appTheme.green60001,
                          borderRadius: BorderRadius.circular(5.h),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(width: 10.h),
              Expanded(
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        messageListItemModelObj.turbulanceTwo!,
                        style: theme.textTheme.titleMedium,
                      ),
                      PinCodeTextField(
                        appContext: context,
                        controller: pinViewController,
                        length: 1,
                        obscureText: true,
                        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                        pinTheme: PinTheme(
                          fieldHeight: 14.h,
                          fieldWidth: 8.h,
                          shape: PinCodeFieldShape.circle,
                          selectedFillColor: appTheme.gray50001,
                        ),
                        onChanged: (value) {
                          pinViewController?.text = value;
                        },
                      ),
                      SizedBox(height: 2.h),
                      Text(
                        messageListItemModelObj.thankyouFor!,
                        style: CustomTextStyles.titleSmallNunitoGray50002,
                      ),
                      SizedBox(width: 88.h),
                      Container(
                        width: 20.h,
                        height: 20.h,
                        alignment: Alignment.center,
                        decoration: AppDecoration.fillRedA.copyWith(
                          borderRadius: BorderRadiusStyle.roundedBorders,
                        ),
                        child: Text(
                          messageListItemModelObj.group159!,
                          textAlign: TextAlign.center,
                          style: CustomTextStyles.labelLargeOnPrimary,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
