import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../create_group_page/create_group_page.dart';
import 'bloc/message_list_bloc.dart';
import 'models/message_list_model.dart';

class MessageListScreen extends StatefulWidget {
  const MessageListScreen({Key? key}) : super(key: key);

  @override
  MessageListScreenState createState() => MessageListScreenState();

  static Widget builder(BuildContext context) {
    return BlocProvider<MessageListBloc>(
      create: (context) => MessageListBloc(
        MessageListState(messageListModelObj: MessageListModel()),
      )..add(MessageListInitialEvent()),
      child: MessageListScreen(),
    );
  }
}

class MessageListScreenState extends State<MessageListScreen>
    with TickerProviderStateMixin {
  late TabController tabViewController;

  @override
  void initState() {
    super.initState();
    tabViewController = TabController(length: 2, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      resizeToAvoidBottomInset: false,
      appBar: _buildAppBar(context),
      body: SafeArea(
        top: false,
        child: SizedBox(
          width: double.maxFinite,
          child: Column(
            children: [
              SizedBox(height: 30.h),
              Container(
                margin: EdgeInsets.only(left: 50.h, right: 54.h),
                width: double.maxFinite,
                child: TabBar(
                  controller: tabViewController,
                  labelPadding: EdgeInsets.zero,
                  labelColor: theme.colorScheme.onPrimary,
                  labelStyle: TextStyle(
                    fontSize: 20.sp,
                    fontFamily: 'Nunito',
                    fontWeight: FontWeight.w900,
                  ),
                  unselectedLabelColor: appTheme.gray50001,
                  indicator: BoxDecoration(),
                  tabs: [
                    Tab(text: "Tab 1"),
                    Tab(text: "Tab 2"),
                  ],
                ),
              ),
              Expanded(
                child: TabBarView(
                  controller: tabViewController,
                  children: [
                    ScrollviewTabPage(),
                    ScrollviewTabPage(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
      height: 120.h,
      title: AppbarTitle(
        text: "Message List",
        fontStyle: AppStyle.textStylePoppinsBold22,
      ),
      actions: [
        IconButton(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => CreateGroupPage()),
          ),
          icon: Icon(Icons.add),
        ),
      ],
    );
  }
}
