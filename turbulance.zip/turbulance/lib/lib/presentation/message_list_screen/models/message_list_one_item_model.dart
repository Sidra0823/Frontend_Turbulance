import 'package:equatable/equatable.dart';

class MessageListItemModel extends Equatable {
  MessageListItemModel({
    this.turbulanceOne,
    this.turbulanceTwo,
    this.thankyouFor,
    this.time,
    this.group159,
    this.id,
  });

  String? turbulanceOne;
  String? turbulanceTwo;
  String? thankyouFor;
  String? time;
  String? group159;
  String? id;

  MessageListItemModel copyWith({
    String? turbulanceOne,
    String? turbulanceTwo,
    String? thankyouFor,
    String? time,
    String? group159,
    String? id,
  }) {
    return MessageListItemModel(
      turbulanceOne: turbulanceOne ?? this.turbulanceOne,
      turbulanceTwo: turbulanceTwo ?? this.turbulanceTwo,
      thankyouFor: thankyouFor ?? this.thankyouFor,
      time: time ?? this.time,
      group159: group159 ?? this.group159,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [turbulanceOne, turbulanceTwo, thankyouFor, time, group159, id];
}
