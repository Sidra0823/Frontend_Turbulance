import 'package:equatable/equatable.dart';

class MessageListModel extends Equatable {
  MessageListModel();

  MessageListModel copyWith() {
    return MessageListModel();
  }

  @override
  List<Object?> get props => [];
}
