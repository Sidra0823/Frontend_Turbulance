import 'package:equatable/equatable.dart';
import 'message_list_item_model.dart';

class ScrollviewTabModel extends Equatable {
  ScrollviewTabModel({this.messageListItemList = const []});

  List<MessageListItemModel> messageListItemList;

  ScrollviewTabModel copyWith({
    List<MessageListItemModel>? messageListItemList,
  }) {
    return ScrollviewTabModel(
      messageListItemList: messageListItemList ?? this.messageListItemList,
    );
  }

  @override
  List<Object?> get props => [messageListItemList];
}
