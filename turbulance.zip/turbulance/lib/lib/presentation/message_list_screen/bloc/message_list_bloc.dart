import 'package:flutter/material.dart';
import 'package:equatable/equatable.dart';
import '../models/message_list_item_model.dart';
import '../models/message_list_model.dart';
import '../models/scrollview_tab_model.dart';

part 'message_list_event.dart';
part 'message_list_state.dart';

class MessageListBloc extends Bloc<MessageListEvent, MessageListState> {
  MessageListBloc(MessageListState initialState) : super(initialState) {
    on<MessageListInitialEvent>(_onInitialize);
  }

  _onInitialize(
      MessageListInitialEvent event,
      Emitter<MessageListState> emit,
      ) async {
    emit(
      state.copyWith(
        downloadOneController: TextEditingController(),
        searchController: TextEditingController(),
        pinViewController: TextEditingController(),
      ),
    );

    emit(
      state.copyWith(
        scrollviewTabModelObj: state.scrollviewTabModelObj?.copyWith(
          messageListItemList: fillMessageListItemList(),
        ),
      ),
    );
  }

  List<MessageListItemModel> fillMessageListItemList() {
    return [
      MessageListItemModel(
        turbulanceOne: ImageConstant.imgDownload471,
        turbulanceTwo: "Turbulance",
        thankyoufor: "Thank you for sharing",
        time: "3:03pm",
        group159: "1",
      ),
      MessageListItemModel(
        turbulanceOne: ImageConstant.imgDownload4730x30,
        thankyoufor: "Thank you for sharing",
        time: "3:03pm",
        group159: "1",
      ),
      MessageListItemModel(
        turbulanceOne: ImageConstant.imgDownload4730x30,
        thankyoufor: "Thank you for sharing",
      ),
      MessageListItemModel(
        turbulanceOne: ImageConstant.imgDownload4730x30,
        thankyoufor: "Thank you for sharing",
      ),
      MessageListItemModel(
        turbulanceOne: ImageConstant.imgDownload4730x30,
        thankyoufor: "Thank you for sharing",
        time: "3:03pm",
        group159: "1",
      ),
      MessageListItemModel(),
      MessageListItemModel(),
    ];
  }
}
