part of 'message_list_bloc.dart';

class MessageListState extends Equatable {
  MessageListState({
    this.downloadOneController,
    this.searchController,
    this.pinViewController,
    this.scrollviewTabModelObj,
    this.messageListModelObj,
  });

  TextEditingController? downloadOneController;
  TextEditingController? searchController;
  TextEditingController? pinViewController;
  MessageListModel? messageListModelObj;
  ScrollviewTabModel? scrollviewTabModelObj;

  @override
  List<Object?> get props => [
    downloadOneController,
    searchController,
    pinViewController,
    scrollviewTabModelObj,
    messageListModelObj,
  ];

  MessageListState copyWith({
    TextEditingController? downloadOneController,
    TextEditingController? searchController,
    TextEditingController? pinViewController,
    ScrollviewTabModel? scrollviewTabModelObj,
    MessageListModel? messageListModelObj,
  }) {
    return MessageListState(
      downloadOneController: downloadOneController ?? this.downloadOneController,
      searchController: searchController ?? this.searchController,
      pinViewController: pinViewController ?? this.pinViewController,
      scrollviewTabModelObj: scrollviewTabModelObj ?? this.scrollviewTabModelObj,
      messageListModelObj: messageListModelObj ?? this.messageListModelObj,
    );
  }
}
