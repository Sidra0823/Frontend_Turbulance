part of 'message_list_bloc.dart';

class MessageListEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

class MessageListInitialEvent extends MessageListEvent {
  @override
  List<Object?> get props => [];
}
