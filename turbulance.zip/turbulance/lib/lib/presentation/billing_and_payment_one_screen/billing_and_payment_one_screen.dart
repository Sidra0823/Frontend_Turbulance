import 'package:flutter/material.dart';
import 'package:responsive_grid_list/responsive_grid_list.dart';

import '../../theme/custom_button_style.dart';
import '../../widgets/app_bar/appbar_leading_image.dart';
import '../../widgets/app_bar/appbar_title.dart';
import '../../widgets/app_bar/custom_app_bar.dart';
import '../../widgets/custom_elevated_button.dart';
import '../../widgets/custom_icon_button.dart';

import 'bloc/billing_and_payment_one_bloc.dart';
import 'models/billing_and_payment_one_model.dart';
import 'models/gridgoogle_pay_item_model.dart';
import 'models/listaxis_bank_item_model.dart';
import 'widgets/gridgoogle_pay_item_widget.dart';
import 'widgets/listaxis_bank_item_widget.dart';

class BillingAndPaymentOneScreen extends StatelessWidget {
  const BillingAndPaymentOneScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<BillingAndPaymentOneBloc>(
      create: (context) => BillingAndPaymentOneBloc(
        BillingAndPaymentOneState(
          billingAndPaymentOneModelobj: BillingAndPaymentOneModel(),
        ),
      )..add(BillingAndPaymentOneInitialEvent()),
      child: BillingAndPaymentOneScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: appTheme.black900,
      appBar: _buildAppbar(context),
      body: SafeArea(
        top: false,
        child: Container(
          width: double.maxFinite,
          padding: EdgeInsets.only(
            left: 40.h,
            top: 22.h,
            right: 40.h,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            children: [
              _buildRowTotalAmount(context),
              SizedBox(height: 28.h),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "msg_credit_debit_cards".tr,
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 12.h),
              _buildColumnAxisBank(context),
              SizedBox(height: 34.h),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "lbl_upi".tr,
                  style: theme.textTheme.titleLarge,
                ),
              ),
              SizedBox(height: 14.h),
              _buildColumnGoogle(context),
              SizedBox(height: 142.h),
              CustomElevatedButton(
                height: 50.h,
                width: 150.h,
                text: "lbl_continue_to_pay".tr,
                buttonStyle: CustomButtonStyles.fillDeepPurpleEa,
                buttonTextStyle: CustomTextStyles.titleSmallNunito15,
                onPressed: () {
                  // Add payment action here
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppbar(BuildContext context) {
    return CustomAppBar(
      height: 54.h,
      leadingWidth: 70.h,
      leading: AppbarLeadingImage(
        imagePath: ImageConstant.imgArrowLeft,
        margin: EdgeInsets.only(left: 30.h),
        onTap: () {
          onTapArrowLeft(context);
        },
      ),
      centerTitle: true,
      title: AppbarTitle(
        text: "lbl_payment_options".tr,
      ),
    );
  }

  Widget _buildRowTotalAmount(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 8.h,
        vertical: 10.h,
      ),
      decoration: AppDecoration.fillGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder8,
      ),
      width: double.maxFinite,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 6.h),
            child: Text(
              "lbl_total_amount".tr,
              style: theme.textTheme.titleLarge,
            ),
          ),
          Text(
            "lbl_847_82".tr,
            style: theme.textTheme.titleLarge,
          ),
        ],
      ),
    );
  }

  Widget _buildColumnAxisBank(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.all(14.h),
      decoration: AppDecoration.NEUTRAL400.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(right: 22.h),
            child: BlocSelector<BillingAndPaymentOneBloc, BillingAndPaymentOneState, BillingAndPaymentOneModel?>(
              selector: (state) => state.billingAndPaymentOneModelobj,
              builder: (context, billingAndPaymentOneModelobj) {
                return ListView.separated(
                  padding: EdgeInsets.zero,
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  separatorBuilder: (context, index) {
                    return SizedBox(
                      height: 8.h,
                    );
                  },
                  itemCount: billingAndPaymentOneModelobj?.listaxisBankItemList.length ?? 0,
                  itemBuilder: (context, index) {
                    ListaxisBankItemModel model =
                        billingAndPaymentOneModelobj?.listaxisBankItemList[index] ?? ListaxisBankItemModel();
                    return ListaxisBankItemWidget(model);
                  },
                );
              },
            ),
          ),
          SizedBox(height: 12.h),
          Container(
            width: double.maxFinite,
            margin: EdgeInsets.symmetric(horizontal: 8.h),
            child: _buildRowAddNewUPIId(context, addNewUPIIdOne: "lbl_add_new_card".tr),
          ),
        ],
      ),
    );
  }

  Widget _buildColumnGoogle(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: EdgeInsets.all(14.h),
      decoration: AppDecoration.NEUTRAL400.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorder16,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.only(right: 22.h),
            child: BlocSelector<BillingAndPaymentOneBloc, BillingAndPaymentOneState, BillingAndPaymentOneModel?>(
              selector: (state) => state.billingAndPaymentOneModelobj,
              builder: (context, billingAndPaymentOneModelobj) {
                return ResponsiveGridList(
                  minItemWidth: 1,
                  minItemsPerRow: 2,
                  maxItemsPerRow: 2,
                  horizontalGridSpacing: 150.h,
                  verticalGridSpacing: 150.h,
                  children: List.generate(
                    billingAndPaymentOneModelobj?.gridgooglePayItemList.length ?? 0,
                        (index) {
                      GridgooglePayItemModel model =
                          billingAndPaymentOneModelobj?.gridgooglePayItemList[index] ?? GridgooglePayItemModel();
                      return GridgooglePayItemWidget(model);
                    },
                  ),
                );
              },
            ),
          ),
          SizedBox(height: 12.h),
          Container(
            width: double.maxFinite,
            margin: EdgeInsets.symmetric(horizontal: 8.h),
            child: _buildRowAddNewUPIId(context, addNewUPIIdOne: "lbl_add_new_upi_id".tr),
          ),
        ],
      ),
    );
  }

  Widget _buildRowAddNewUPIId(BuildContext context, {required String addNewUPIIdOne}) {
    return Row(
      children: [
        CustomIconButton(
          height: 24.h,
          width: 24.h,
          decoration: IconButtonStyleHelper.none,
          child: CustomImageView(
            imagePath: ImageConstant.imgFrame34913,
          ),
        ),
        Padding(
          padding: EdgeInsets.only(left: 12.h),
          child: Text(
            addNewUPIIdOne,
            style: theme.textTheme.bodyMedium.copyWith(
              color: theme.colorScheme.onPrimary,
            ),
          ),
        ),
      ],
    );
  }

  void onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
