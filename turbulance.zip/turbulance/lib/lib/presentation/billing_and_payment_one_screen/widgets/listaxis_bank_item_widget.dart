import 'package:flutter/material.dart';
import '../models/listaxis_bank_item_model.dart';

// ignore_for_file: must_be_immutable

class ListaxisBankItemWidget extends StatelessWidget {
  final ListaxisBankItemModel listaxisBankItemModelobj;

  // Constructor to accept ListaxisBankItemModel object
  ListaxisBankItemWidget({
    Key? key,
    required this.listaxisBankItemModelobj,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 14.h,
        vertical: 6.h,
      ),
      decoration: AppDecoration.outlineGray.copyWith(
        borderRadius: BorderRadiusStyle.roundedBorders,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CustomImageView(
            imagePath: ImageConstant.imgUserYellowBee, // Corrected the imagePath constant name
            height: 20.h,
            width: 34.h,
          ),
          Padding(
            padding: EdgeInsets.only(left: 8.h),
            child: Text(
              listaxisBankItemModelobj.axisbank!,
              style: CustomTextStyles.bodySmallIBMPlexSansOnPrimary,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(left: 8.h),
            child: Text(
              listaxisBankItemModelobj.eightthousandth!,
              style: CustomTextStyles.bodySmallIBMPlexSansOnPrimary,
            ),
          ),
          Spacer(),
          SizedBox(
            height: 20.h,
            width: 22.h,
            child: Stack(
              alignment: Alignment.center,
              children: [
                CustomImageView(
                  imagePath: ImageConstant.imgCarbonRadioButtonChecked, // Corrected imagePath constant name
                  height: 20.h,
                  width: 20.h,
                ),
                CustomImageView(
                  imagePath: ImageConstant.imgCheckmark,
                  height: 12.h,
                  width: 14.h,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
