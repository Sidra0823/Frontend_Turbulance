import 'package:flutter/material.dart';

import '../models/gridgoogle_pay_item_model.dart';

// ignore_for_file: must_be_immutable

class GridgooglePayItemWidget extends StatelessWidget {
  final GridgooglePayItemModel gridgooglePayItemModelobj;

  // Constructor to accept GridgooglePayItemModel object
  GridgooglePayItemWidget({
    Key? key,
    required this.gridgooglePayItemModelobj,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        CustomImageView(
          imagePath: ImageConstant.imgImage3, // Corrected the imagePath constant name
          height: 20.h,
          width: 22.h,
        ),
        SizedBox(width: 8.h),
        Text(
          gridgooglePayItemModelobj.googlepay!,
          style: CustomTextStyles.bodySmallIBMPlexSansOnPrimary,
        ),
      ],
    );
  }
}
