import 'package:equatable/equatable.dart';
import '../models/billing_and_payment_one_model.dart';
import '../models/grid_google_pay_item_model.dart';
import '../models/list_axis_bank_item_model.dart';

part 'billing_and_payment_one_event.dart';
part 'billing_and_payment_one_state.dart';

/// A bloc that manages the state of Billing and Payment One according to the event that is dispatched to it.
class BillingAndPaymentOneBloc extends Bloc<BillingAndPaymentOneEvent, BillingAndPaymentOneState> {
  BillingAndPaymentOneBloc(BillingAndPaymentOneState initialState) : super(initialState) {
    on<BillingAndPaymentOneInitialEvent>(_onInitialize);
  }

  Future<void> _onInitialize(BillingAndPaymentOneInitialEvent event, Emitter<BillingAndPaymentOneState> emit) async {
    emit(
      state.copyWith(
        billingAndPaymentOneModelObj: state.billingAndPaymentOneModelObj?.copyWith(
          gridGooglePayItemList: _fillGridGooglePayItemList(),
          listAxisBankItemList: _fillListAxisBankItemList(),
        ),
      ),
    );
  }

  // Helper method to populate GridGooglePayItemList
  List<GridGooglePayItemModel> _fillGridGooglePayItemList() {
    return [
      GridGooglePayItemModel(googlePay: "Google Pay"),
      GridGooglePayItemModel(),
      GridGooglePayItemModel(),
    ];
  }

  // Helper method to populate ListAxisBankItemList
  List<ListAxisBankItemModel> _fillListAxisBankItemList() {
    return [
      ListAxisBankItemModel(axisBank: "Axis Bank", amount: "**8395"),
      ListAxisBankItemModel(),
    ];
  }
}
