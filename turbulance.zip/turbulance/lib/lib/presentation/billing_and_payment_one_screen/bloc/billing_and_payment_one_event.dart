part of 'billing_and_payment_one_bloc.dart';

/// Abstract class for all events that can be dispatched from the
/// BillingAndPaymentOne widget.
///
/// Events must be immutable and implement the [Equatable] interface.
abstract class BillingAndPaymentOneEvent extends Equatable {
  @override
  List<Object?> get props => [];
}

/// Event that is dispatched when the BillingAndPaymentOne widget is first created.
class BillingAndPaymentOneInitialEvent extends BillingAndPaymentOneEvent {
  @override
  List<Object?> get props => [];
}
