part of 'billing_and_payment_one_bloc.dart';

/// Represents the state of BillingAndPaymentOne in the application.
class BillingAndPaymentOneState extends Equatable {
  BillingAndPaymentOneState({this.billingAndPaymentOneModelobj});

  BillingAndPaymentOneModel? billingAndPaymentOneModelobj;

  @override
  List<Object?> get props => [billingAndPaymentOneModelobj];

  BillingAndPaymentOneState copyWith({
    BillingAndPaymentOneModel? billingAndPaymentOneModelobj,
  }) {
    return BillingAndPaymentOneState(
      billingAndPaymentOneModelobj:
      billingAndPaymentOneModelobj ?? this.billingAndPaymentOneModelobj,
    );
  }
}
