import 'package:equatable/equatable.dart';

/// This class is used in the [gridgoogle_pay_item_widget] screen.

/// ignore_for_file: must_be_immutable
class GridgooglePayItemModel extends Equatable {
  // Constructor with optional named parameters for googlepay and id
  GridgooglePayItemModel({
    this.googlepay = "Google Pay",
    this.id = "",
  });

  // Properties for googlepay and id
  String? googlepay;
  String? id;

  // CopyWith method to allow creating a copy of the model with updated values
  GridgooglePayItemModel copyWith({
    String? googlepay,
    String? id,
  }) {
    return GridgooglePayItemModel(
      googlepay: googlepay ?? this.googlepay,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [googlepay, id];
}
