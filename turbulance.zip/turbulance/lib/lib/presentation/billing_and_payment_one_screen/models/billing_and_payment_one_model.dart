import 'package:equatable/equatable.dart';
import 'gridgoogle_pay_item_model.dart';
import 'listaxis_bank_item_model.dart';

/// This class defines the variables used in the [BillingAndPaymentOneScreen]
/// and is typically used to hold data that is passed between different parts of the application.

// ignore_for_file: must_be_immutable
class BillingAndPaymentOneModel extends Equatable {
  // Constructor to initialize the lists with default values if not provided
  BillingAndPaymentOneModel({
    this.listaxisBankItemList = const [],
    this.gridgooglePayItemList = const [],
  });

  // List of AxisBankItemModel
  List<ListaxisBankItemModel> listaxisBankItemList;

  // List of GridGooglePayItemModel
  List<GridgooglePayItemModel> gridgooglePayItemList;

  // CopyWith method to allow creating a copy of the model with updated values
  BillingAndPaymentOneModel copyWith({
    List<ListaxisBankItemModel>? listaxisBankItemList,
    List<GridgooglePayItemModel>? gridgooglePayItemList,
  }) {
    return BillingAndPaymentOneModel(
      listaxisBankItemList: listaxisBankItemList ?? this.listaxisBankItemList,
      gridgooglePayItemList: gridgooglePayItemList ?? this.gridgooglePayItemList,
    );
  }

  @override
  List<Object?> get props => [listaxisBankItemList, gridgooglePayItemList];
}
