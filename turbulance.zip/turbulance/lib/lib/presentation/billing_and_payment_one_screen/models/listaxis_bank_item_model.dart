import 'package:equatable/equatable.dart';

/// This class is used in the [listaxis_bank_item_widget] screen.

/// ignore_for_file: must_be_immutable
class ListaxisBankItemModel extends Equatable {
  // Constructor with optional named parameters for axisbank, eightthousandth, and id
  ListaxisBankItemModel({
    this.axisbank = "Axis Bank", // Default value set to "Axis Bank"
    this.eightthousandth = "**8395", // Default value set to "**8395"
    this.id = "", // Default value set to an empty string
  });

  // Properties for axisbank, eightthousandth, and id
  String? axisbank;
  String? eightthousandth;
  String? id;

  // CopyWith method to allow creating a copy of the model with updated values
  ListaxisBankItemModel copyWith({
    String? axisbank,
    String? eightthousandth,
    String? id,
  }) {
    return ListaxisBankItemModel(
      axisbank: axisbank ?? this.axisbank,
      eightthousandth: eightthousandth ?? this.eightthousandth,
      id: id ?? this.id,
    );
  }

  @override
  List<Object?> get props => [axisbank, eightthousandth, id];
}
